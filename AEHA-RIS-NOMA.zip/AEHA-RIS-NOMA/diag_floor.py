"""Where do QoS-floor violations come from?  (P8-style policy, one seed)."""

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import aeha_core as core  # noqa: E402
from headroom import collect, eff_gains, anchor_phases, simplex_grid, metrics, nomarates  # noqa: E402
import headroom  # noqa: E402

mode = sys.argv[1] if len(sys.argv) > 1 else "margin"
val = float(sys.argv[2]) if len(sys.argv) > 2 else 1.0
seeds = [int(x) for x in sys.argv[3].split(",")] if len(sys.argv) > 3 else [11, 22, 33]
margin = val if mode == "margin" else 0.0
headroom.OBJECTIVE, headroom.MARGIN = "constrained", margin
cfg = core.rx.Config(**core.rx.PROFILES["quick"])
W = simplex_grid(cfg.n_users, 5, positive=False)


CM = None


def floor(g):
    if mode == "margin":
        return core.qos_floor_power(g, cfg, val)
    if mode == "conf":
        return core.conformal_floor_power(g, cfg, val, CM)
    return core.chance_floor_power(g, cfg, val)


rows, per_seed = [], []
for seed in seeds:
    if mode == "conf":
        CM = core.ConformalGainModel(cfg, seed=seed)  # training-seed stream only
    snaps, _ = collect(cfg, seed + 100_000, cfg.eval_steps)
    sr, q, jn = [], [], []
    for s in snaps:
        best = None
        for site in range(cfg.n_sites):
            th = anchor_phases(s["casc_est"][site], s["d_est"], W)
            g_e = eff_gains(s["d_est"], s["casc_est"][site], th)
            for i in range(len(W)):
                p = floor(g_e[i])
                # select on estimated sum-rate; violations judged at plain r_min on est CSI
                sc = float(metrics(nomarates(g_e[i], g_e[i], p, cfg), cfg)["score"])
                if best is None or sc > best[0]:
                    best = (sc, site, th[i], p, g_e[i])
        _, site, th, p, ge = best
        gt = eff_gains(s["d_true"], s["casc"][site], th[None])[0]
        r_true = nomarates(gt, ge, p, cfg)  # est order
        r_est = nomarates(ge, ge, p, cfg)
        order = np.argsort(ge)
        mt = metrics(r_true, cfg)
        sr.append(float(mt["sum_rate"]))
        q.append(float(mt["qos"]))
        jn.append(float(mt["fairness"]))
        rows.append(dict(
            viol=int((r_true < cfg.min_rate_mbps).sum()),
            dropped=int((p == 0).sum()),
            order_wrong=int(not np.array_equal(np.argsort(ge), np.argsort(gt))),
            min_est_rate=float(r_est.min()),
            weakest_est_gain=float(ge.min()),
            weakest_gain_rel_err=float(abs(gt[order[0]] - ge[order[0]]) / max(ge[order[0]], 1e-12)),
            viol_rank=[int(k) for k in np.flatnonzero(r_true < cfg.min_rate_mbps)],
        ))
    per_seed.append((np.mean(sr), 100 * np.mean(q), np.mean(jn)))
ps = np.array(per_seed)
print(f"{mode} {val}: per-seed mean sum-rate {ps[:, 0].mean():.3f}, QoS {ps[:, 1].mean():.2f}%, Jain {ps[:, 2].mean():.3f}"
      f"  (seeds {seeds})")
v = np.array([r["viol"] for r in rows])
dr = np.array([r["dropped"] for r in rows])
ow = np.array([r["order_wrong"] for r in rows])
rel = np.array([r["weakest_gain_rel_err"] for r in rows])
print(f"margin {margin}: steps {len(rows)}, steps with violation {np.mean(v > 0)*100:.2f}%")
print(f"  violations from dropped users: {dr[v > 0].sum()} of {v.sum()}")
print(f"  order wrong: overall {ow.mean()*100:.1f}%, among violating steps {ow[v > 0].mean()*100:.1f}%")
print(f"  weakest-user gain rel. error: median overall {np.median(rel):.3f}, violating {np.median(rel[v > 0]):.3f}")
ranks = np.concatenate([r["viol_rank"] for r in rows if r["viol_rank"]] or [np.array([])])
print(f"  violated SIC rank (0 = weakest): counts {np.bincount(ranks.astype(int), minlength=cfg.n_users).tolist()}")
