# Final 10-seed comparison (quick evaluation protocol + 200-geometry metric).
# Suite A: published Hybrid-SAC with its original settings (gamma 0.99, 3000 steps).
# Suite B: everything else at gamma 0, 8000 training steps.
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$env:KMP_DUPLICATE_LIB_OK = "TRUE"
$seeds = 11, 22, 33, 44, 55, 66, 77, 88, 99, 110
$methodsB = "Decoupled-MRR,Fixed-site,Agg-target,Agg-conf-d0.01,Hybrid-SAC-Lagr," +
            "AEHA-res-fixed-delta,AEHA-main-no-pointer,AEHA-fixed-delta,AEHA-main-margin-floor,AEHA-res"

foreach ($batch in @($seeds[0..4], $seeds[5..9])) {
    $jobs = foreach ($s in $batch) {
        Start-Job -ArgumentList $s, $methodsB, $PSScriptRoot -ScriptBlock {
            param($s, $m, $root)
            Set-Location $root
            $env:KMP_DUPLICATE_LIB_OK = "TRUE"
            python aeha.py --profile quick --gamma 0 --train-steps 8000 --seeds $s --methods $m --outdir "results_final/B_seed$s" 2>&1 | Out-String
            python aeha.py --profile quick --seeds $s --methods "Hybrid-SAC" --outdir "results_final/A_seed$s" 2>&1 | Out-String
        }
    }
    $jobs | Wait-Job | Out-Null
    foreach ($j in $jobs) { Receive-Job $j | Select-String -Pattern '^seed|Error|error' }
}
$dirs = ($seeds | ForEach-Object { "results_final/B_seed$_,results_final/A_seed$_" }) -join ","
python aeha.py --merge $dirs --outdir results_final/merged
