# Full comparison for the AEHA paper: every method in every scenario.
#  Stage 1  published Hybrid-SAC + DDPG-Hybrid at the main profile (10 seeds)      -> results_final/P_seed*
#           per-size retraining of ALL methods (L, K, N; 5 seeds)                   -> results_scen/<tag>_{B,P}_seed*
#  Stage 2  test-time scenario suite, all methods (10 seeds)                         -> results_scen_eval/
#  Stage 3  merges
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$env:KMP_DUPLICATE_LIB_OK = "TRUE"
$MAXJOBS = 6

function Run-Queue($cmds) {
    $pending = [System.Collections.Queue]::new()
    foreach ($c in $cmds) { $pending.Enqueue($c) }
    $running = @()
    while ($pending.Count -gt 0 -or $running.Count -gt 0) {
        while ($pending.Count -gt 0 -and ($running | Where-Object { $_.State -eq 'Running' }).Count -lt $MAXJOBS) {
            $c = $pending.Dequeue()
            $running += Start-Job -ArgumentList $c, $PSScriptRoot -ScriptBlock {
                param($c, $root) Set-Location $root; $env:KMP_DUPLICATE_LIB_OK = "TRUE"
                "CMD: $c"; Invoke-Expression $c 2>&1 | Out-String
            }
        }
        $done = $running | Where-Object { $_.State -ne 'Running' }
        foreach ($j in $done) {
            Receive-Job $j | Select-String -Pattern '^CMD:|Error|Traceback' | ForEach-Object { $_.Line }
            Remove-Job $j
        }
        $running = @($running | Where-Object { $_.State -eq 'Running' })
        Start-Sleep -Seconds 5
    }
}

$S10 = 11, 22, 33, 44, 55, 66, 77, 88, 99, 110
$S5 = 11, 22, 33, 44, 55
$B = "Decoupled-MRR,Fixed-site,Agg-target,Agg-conf-d0.01,Hybrid-SAC-Lagr,AEHA-res-fixed-delta"
$P = "Hybrid-SAC,DDPG-Hybrid"
$tags = @{ "L20" = "--n-sites 20"; "L50" = "--n-sites 50"; "K20" = "--n-vehicles 20"; "K50" = "--n-vehicles 50";
           "N32" = "--n-ris 32"; "N128" = "--n-ris 128" }

# ---- Stage 1
$cmds = @()
$cmds += $S10 | ForEach-Object { "python aeha.py --profile quick --seeds $_ --methods $P --outdir results_final/P_seed$_" }
foreach ($t in "L50", "L20", "K50", "K20", "N128", "N32") {   # slowest first
    foreach ($s in $S5) {
        $cmds += "python aeha.py --profile quick --gamma 0 --train-steps 8000 $($tags[$t]) --seeds $s --methods $B --outdir results_scen/${t}_B_seed$s"
        $cmds += "python aeha.py --profile quick $($tags[$t]) --seeds $s --methods $P --outdir results_scen/${t}_P_seed$s"
    }
}
Run-Queue $cmds
python aeha.py --merge (($S10 | ForEach-Object { "results_final/B_seed$_,results_final/P_seed$_" }) -join ",") --outdir results_final/merged_all
foreach ($t in $tags.Keys) {
    python aeha.py --merge (($S5 | ForEach-Object { "results_scen/${t}_B_seed$_,results_scen/${t}_P_seed$_" }) -join ",") --outdir "results_scen/${t}_merged"
}

# ---- Stage 2
$pairs = @("11,22", "33,44", "55,66", "77,88", "99,110")
Run-Queue ($pairs | ForEach-Object { "python scenarios.py --seeds $_ --out results_scen_eval/s" + $_.Replace(",", "_") })
python scenarios.py --summarize (($pairs | ForEach-Object { "results_scen_eval/s" + $_.Replace(",", "_") }) -join ",")
"FULL RUN DONE"
