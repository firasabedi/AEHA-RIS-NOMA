# Re-evaluate every conformal-floor result after the calibration-seed fix (2026-10-12).
# Old raw files are kept as metrics_raw_pre_calibfix.csv / results_*_pre_calibfix.
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$env:KMP_DUPLICATE_LIB_OK = "TRUE"

function Run-Parallel($cmds) {
    $jobs = foreach ($c in $cmds) {
        Start-Job -ArgumentList $c, $PSScriptRoot -ScriptBlock {
            param($c, $root) Set-Location $root; $env:KMP_DUPLICATE_LIB_OK = "TRUE"
            Invoke-Expression $c 2>&1 | Out-String
        }
    }
    $jobs | Wait-Job | Out-Null
    foreach ($j in $jobs) { Receive-Job $j | Select-String -Pattern 'Error|error|Traceback' }
}

# 1. Final 10-seed comparison + L-scaling + rho0/rho-aware training dirs
$final = 11, 22, 33, 44, 55, 66, 77, 88, 99, 110 | ForEach-Object { "results_final/B_seed$_" }
$lsc = foreach ($L in 20, 50) { 11, 22, 33, 44, 55 | ForEach-Object { "results_phase3_L/L${L}_B_seed$_" } }
$other = (11, 22, 33, 44, 55 | ForEach-Object { "results_rho0/seed$_" }) + (11, 22, 33, 44, 55 | ForEach-Object { "results_rho_aware/seed$_" })
$all = $final + $lsc + $other
$cmds = for ($i = 0; $i -lt $all.Count; $i += 3) { "python reeval_conformal.py " + (($all[$i..([math]::Min($i + 2, $all.Count - 1))]) -join " ") }
Run-Parallel $cmds
python aeha.py --merge (($final | ForEach-Object { $_ }) + (11, 22, 33, 44, 55, 66, 77, 88, 99, 110 | ForEach-Object { "results_final/A_seed$_" }) -join ",") --outdir results_final/merged
python final_stats.py
foreach ($L in 20, 50) {
    $dirs = (11, 22, 33, 44, 55 | ForEach-Object { "results_phase3_L/L${L}_B_seed$_,results_phase3_L/L${L}_A_seed$_" }) -join ","
    python aeha.py --merge $dirs --outdir "results_phase3_L/L${L}_merged"
}
python aeha.py --merge ((11, 22, 33, 44, 55 | ForEach-Object { "results_rho0/seed$_" }) -join ",") --outdir results_rho0/merged

# 2. Phase 3 test-time suite (all settings) and the rho sweep
if (Test-Path results_phase3) { Rename-Item results_phase3 results_phase3_pre_calibfix }
if (Test-Path results_rho_aware/eval) { Rename-Item results_rho_aware/eval eval_pre_calibfix }
$pairs = @("11,22", "33,44", "55,66", "77,88", "99,110")
$cmds = ($pairs | ForEach-Object { "python phase3.py --seeds $_ --out results_phase3/s" + $_.Replace(",", "_") }) +
        (11, 22, 33, 44, 55 | ForEach-Object { "python rho_eval.py --seeds $_ --out results_rho_aware/eval_s$_" })
Run-Parallel $cmds
python phase3.py --summarize (($pairs | ForEach-Object { "results_phase3/s" + $_.Replace(",", "_") }) -join ",")
python rho_eval.py --merge ((11, 22, 33, 44, 55 | ForEach-Object { "results_rho_aware/eval_s$_" }) -join ",") --out results_rho_aware/eval
python make_figures.py
"REEVAL DONE"
