"""Render the TikZ figures of the manuscript to standalone PNG files.

Reads the tikzpicture environments from the TikZ source files in
manuscript/figs/tikz/ (or, on the first run, from sn-article.tex), compiles
each with the standalone class, and converts it to a 600-dpi PNG in
manuscript/figs/.
"""
import re
import subprocess
from pathlib import Path

here = Path(__file__).resolve().parent
man = here / "manuscript"
src_dir = man / "figs" / "tikz"
src_dir.mkdir(parents=True, exist_ok=True)

NAMES = ["fig_system_scenario", "fig_aeha_pipeline", "fig_cloud_edge"]  # order of appearance
PREAMBLE = r"""\documentclass[border=4pt]{standalone}
\usepackage{amsmath,amssymb}
\usepackage{tikz}
\usetikzlibrary{arrows.meta,positioning,fit,calc}
\begin{document}
"""

# first run: extract the pictures from the manuscript
if not all((src_dir / f"{n}_body.tex").exists() for n in NAMES):
    tex = (man / "sn-article.tex").read_text(encoding="utf-8")
    pics = re.findall(r"\\begin\{tikzpicture\}.*?\\end\{tikzpicture\}", tex, re.S)
    assert len(pics) == len(NAMES), f"found {len(pics)} tikzpictures"
    for n, body in zip(NAMES, pics):
        (src_dir / f"{n}_body.tex").write_text(body + "\n", encoding="utf-8")

for n in NAMES:
    body = (src_dir / f"{n}_body.tex").read_text(encoding="utf-8")
    (src_dir / f"{n}.tex").write_text(PREAMBLE + body + "\\end{document}\n", encoding="utf-8")
    subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", f"{n}.tex"],
                   cwd=src_dir, check=True, stdout=subprocess.DEVNULL)
    subprocess.run(["pdftoppm", "-r", "600", "-png", "-singlefile", f"{n}.pdf",
                    str(man / "figs" / n)], cwd=src_dir, check=True)
    print("wrote", man / "figs" / f"{n}.png")
