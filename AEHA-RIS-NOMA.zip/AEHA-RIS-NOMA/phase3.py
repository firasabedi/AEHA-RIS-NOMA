"""Phase 3, part 1: test-time generalization, impairments and fairness.

No retraining: the AEHA main policy (AEHA-res-fixed-delta) and the published
Hybrid-SAC actor from ``results_final`` are evaluated under shifted settings.
The conformal gain model is re-fitted for each test configuration (offline
calibration of the deployment's estimator statistics, never the evaluation
streams).  Every setting is scored on the manuscript protocol and on the
200-geometry metric.

Usage:  python phase3.py --seeds 11,22 --out results_phase3/s11_22
        python phase3.py --summarize results_phase3/s11_22,...
"""

from __future__ import annotations

import argparse
import math
import time
from dataclasses import replace
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from scipy import stats

import aeha
import aeha_core as core
from aeha_core import rx

HERE = Path(__file__).resolve().parent
FINAL = HERE / "results_final"
MAIN = "AEHA-res-fixed-delta"


def load_aeha(cfg, seed):
    agent = aeha.AEHASAC(cfg, aeha.AEHA_VARIANTS[MAIN])
    agent.actor.load_state_dict(torch.load(FINAL / f"B_seed{seed}" / "models" / f"{MAIN}_seed{seed}.pt"))
    agent.actor.eval()
    agent.cmodel = core.ConformalGainModel(cfg, seed)
    return agent


def load_hybrid_sac(cfg, seed):
    env = rx.RISNOMAEnv(cfg, seed)
    agent = rx.HybridSAC(env, cfg)
    agent.actor.load_state_dict(torch.load(FINAL / f"A_seed{seed}" / "models" / f"Hybrid-SAC_seed{seed}.pt"))
    agent.actor.eval()
    return agent


# setting name -> (group, config overrides, test-time knobs)
SETTINGS = {
    "base": ("base", {}, {}),
    "N=32": ("elements", dict(n_ris=32), {}),
    "N=128": ("elements", dict(n_ris=128), {}),
    "K=20": ("vehicle_pool", dict(n_vehicles=20), {}),
    "K=50": ("vehicle_pool", dict(n_vehicles=50), {}),
    "L=20 zero-shot": ("sites", dict(n_sites=20), {}),
    "L=50 zero-shot": ("sites", dict(n_sites=50), {}),
    "2-bit": ("quantization", {}, dict(phase_bits=2)),
    "1-bit": ("quantization", {}, dict(phase_bits=1)),
    "rho=0": ("residual_sic", dict(residual_sic=0.0), {}),
    "rho=0.15": ("residual_sic", dict(residual_sic=0.15), {}),
    "csi=0.02": ("csi_error", dict(csi_error_var=0.02), {}),
    "csi=0.10": ("csi_error", dict(csi_error_var=0.10), {}),
    "phi=0.5": ("fairness", {}, dict(phi=0.5)),
    "phi=1": ("fairness", {}, dict(phi=1.0)),
    "phi=2": ("fairness", {}, dict(phi=2.0)),
    "phi=4": ("fairness", {}, dict(phi=4.0)),
}
# Published Hybrid-SAC has a fixed input size: only settings that keep L, N, K.
SAC_OK = {"base", "2-bit", "1-bit", "rho=0", "rho=0.15", "csi=0.02", "csi=0.10"}


def policies(cfg, seed, name, knobs):
    bits, phi = knobs.get("phase_bits"), knobs.get("phi", 0.0)
    pols = {"Decoupled-MRR": aeha.heuristic_policy("decoupled"), "Agg-target": aeha.agg_target_policy}
    cm = core.ConformalGainModel(cfg, seed)
    pols["Agg-conf-d0.01"] = aeha.agg_floor_policy(0.01, "conformal", cm, phase_bits=bits, phi=phi)
    agent = load_aeha(cfg, seed)
    agent.phi = phi
    pols["AEHA"] = aeha.aeha_policy(agent)
    if bits is not None:
        agent_q = load_aeha(cfg, seed)
        agent_q.decode_phase_bits = bits
        pols["AEHA (quant-aware)"] = aeha.aeha_policy(agent_q)
    if name in SAC_OK:
        pols["Hybrid-SAC"] = aeha.sac_policy(load_hybrid_sac(cfg, seed))
    return pols


def run(seeds, out: Path):
    out.mkdir(parents=True, exist_ok=True)
    base = rx.Config(**rx.PROFILES["quick"])
    rows = []
    for seed in seeds:
        for name, (group, over, knobs) in SETTINGS.items():
            cfg = replace(base, **over)
            t0 = time.time()
            for method, pol in policies(cfg, seed, name, knobs).items():
                m = aeha.evaluate(cfg, seed, pol, phase_bits=knobs.get("phase_bits"))
                g = aeha.evaluate_geometries(cfg, seed, pol) if knobs.get("phase_bits") is None else \
                    _geo_quant(cfg, seed, pol, knobs["phase_bits"])
                rows.append(dict(seed=seed, group=group, setting=name, method=method, **m, **g))
            print(f"seed {seed} {name:16s} done in {time.time() - t0:5.1f}s", flush=True)
        pd.DataFrame(rows).to_csv(out / "phase3_raw.csv", index=False)


def _geo_quant(cfg, seed, pol, bits, n_envs=200, steps=20):
    c = replace(cfg, eval_steps=steps)
    ms = [aeha.evaluate(c, seed, pol, phase_bits=bits, env_seed=seed + 200_000 + 1000 * k) for k in range(n_envs)]
    return dict(sum_rate_geo=float(np.mean([m["sum_rate_mean"] for m in ms])),
                qos_geo=float(np.mean([m["qos_percent"] for m in ms])),
                fairness_geo=float(np.mean([m["fairness"] for m in ms])))


def summarize(dirs, out: Path):
    raw = pd.concat([pd.read_csv(HERE / d / "phase3_raw.csv") for d in dirs], ignore_index=True)
    out.mkdir(parents=True, exist_ok=True)
    raw.to_csv(out / "phase3_raw.csv", index=False)
    keys = ["sum_rate_geo", "qos_geo", "fairness_geo", "sum_rate_mean", "qos_percent", "inference_ms_median"]
    summ, paired = [], []
    for (setting, method), g in raw.groupby(["setting", "method"], sort=False):
        row = dict(group=g.group.iloc[0], setting=setting, method=method, n=len(g))
        for k in keys:
            row[k], row[k + "_ci95"] = aeha.mean_ci(g[k])
        row["seeds_qos_geo_ge_99"] = int((g.qos_geo >= 99.0).sum())
        summ.append(row)
    for setting, gs in raw.groupby("setting", sort=False):
        ref = gs[gs.method == "Decoupled-MRR"].set_index("seed")
        for method in gs.method.unique():
            if method == "Decoupled-MRR":
                continue
            cur = gs[gs.method == method].set_index("seed")
            for k in ("sum_rate_geo", "qos_geo", "fairness_geo"):
                d = (cur[k] - ref[k]).dropna().values
                mu, ci = aeha.mean_ci(d)
                p = float(stats.ttest_1samp(d, 0.0).pvalue) if len(d) > 1 and np.any(d != d[0]) else float("nan")
                paired.append(dict(setting=setting, method=method, metric=k, diff_vs_MRR=mu, ci95=ci, p=p))
    pd.DataFrame(summ).to_csv(out / "phase3_summary.csv", index=False)
    pd.DataFrame(paired).to_csv(out / "phase3_paired_vs_MRR.csv", index=False)
    pd.set_option("display.width", 220)
    s = pd.DataFrame(summ)
    print(s[["setting", "method", "n", "sum_rate_geo", "qos_geo", "fairness_geo", "seeds_qos_geo_ge_99",
             "inference_ms_median"]].round(3).to_string(index=False))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", default="11")
    ap.add_argument("--out", default="results_phase3/tmp")
    ap.add_argument("--summarize", default=None)
    a = ap.parse_args()
    if a.summarize:
        summarize(a.summarize.split(","), HERE / "results_phase3" / "merged")
    else:
        run([int(s) for s in a.seeds.split(",")], HERE / a.out)


if __name__ == "__main__":
    main()
