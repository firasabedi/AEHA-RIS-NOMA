"""Evaluate the rho-aware AEHA policy across residual-SIC levels.

Compared with: Decoupled-MRR, the non-learned layer (Agg-conf-d0.01), and the
two specialists trained at a single rho (0.08: results_final; 0.0:
results_rho0).  Training rho values: 0, .02, .04, .08, .15; held-out: .01,
.06, .11.  Both metrics (manuscript stream and 200-geometry).
"""

from __future__ import annotations

import argparse
from dataclasses import replace
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from scipy import stats

import aeha
import aeha_core as core
from aeha_core import rx

HERE = Path(__file__).resolve().parent
RHOS = [0.0, 0.01, 0.02, 0.04, 0.06, 0.08, 0.11, 0.15]
TRAIN_RHOS = {0.0, 0.02, 0.04, 0.08, 0.15}
MODELS = {
    "AEHA rho-aware": ("AEHA-rho-aware", "results_rho_aware/seed{s}/models/AEHA-rho-aware_seed{s}.pt"),
    "AEHA spec. rho=0.08": ("AEHA-res-fixed-delta", "results_final/B_seed{s}/models/AEHA-res-fixed-delta_seed{s}.pt"),
    "AEHA spec. rho=0": ("AEHA-res-fixed-delta", "results_rho0/seed{s}/models/AEHA-res-fixed-delta_seed{s}.pt"),
}


def load(cfg, seed, variant, path):
    agent = aeha.AEHASAC(cfg, aeha.AEHA_VARIANTS[variant])
    agent.actor.load_state_dict(torch.load(HERE / path.format(s=seed)))
    agent.actor.eval()
    agent.cmodel = core.ConformalGainModel(cfg, seed)
    return agent


def run(seeds, out: Path):
    base = rx.Config(**rx.PROFILES["quick"])
    rows = []
    for seed in seeds:
        for rho in RHOS:
            cfg = replace(base, residual_sic=rho)
            pols = {"Decoupled-MRR": aeha.heuristic_policy("decoupled"),
                    "Agg-conf-d0.01": aeha.agg_floor_policy(0.01, "conformal", core.ConformalGainModel(cfg, seed))}
            for name, (variant, path) in MODELS.items():
                pols[name] = aeha.aeha_policy(load(cfg, seed, variant, path))
            for name, pol in pols.items():
                m = aeha.evaluate(cfg, seed, pol)
                m.update(aeha.evaluate_geometries(cfg, seed, pol))
                rows.append(dict(seed=seed, rho=rho, trained_rho=rho in TRAIN_RHOS, method=name, **m))
            print(f"seed {seed} rho {rho:.2f} done", flush=True)
    out.mkdir(parents=True, exist_ok=True)
    raw = pd.DataFrame(rows)
    raw.to_csv(out / "rho_raw.csv", index=False)
    summarize(raw, out)


def summarize(raw, out: Path):
    out.mkdir(parents=True, exist_ok=True)
    raw.to_csv(out / "rho_raw.csv", index=False)
    summ = []
    for (rho, meth), g in raw.groupby(["rho", "method"], sort=False):
        row = dict(rho=rho, method=meth, n=len(g))
        for k in ("sum_rate_geo", "qos_geo", "fairness_geo"):
            row[k], row[k + "_ci95"] = aeha.mean_ci(g[k])
        row["seeds_qos_ge_99"] = int((g.qos_geo >= 99).sum())
        mrr = raw[(raw.rho == rho) & (raw.method == "Decoupled-MRR")].set_index("seed")
        d = g.set_index("seed").sum_rate_geo - mrr.sum_rate_geo
        row["d_sum_vs_MRR"] = d.mean()
        row["p_vs_MRR"] = float(stats.ttest_1samp(d, 0).pvalue) if meth != "Decoupled-MRR" else np.nan
        summ.append(row)
    s = pd.DataFrame(summ)
    s.to_csv(out / "rho_summary.csv", index=False)
    pd.set_option("display.width", 220)
    print(s.round(3).to_string(index=False))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", default="11,22,33,44,55")
    ap.add_argument("--out", default="results_rho_aware/eval")
    ap.add_argument("--merge", default=None, help="comma-separated dirs with rho_raw.csv to merge into --out")
    a = ap.parse_args()
    if a.merge:
        summarize(pd.concat([pd.read_csv(HERE / d / "rho_raw.csv") for d in a.merge.split(",")], ignore_index=True),
                  HERE / a.out)
        return
    run([int(s) for s in a.seeds.split(",")], HERE / a.out)


if __name__ == "__main__":
    main()
