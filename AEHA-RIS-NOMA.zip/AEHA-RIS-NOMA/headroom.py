﻿"""Phase 1 go/no-go: how much headroom exists above Decoupled-MRR?

Evaluates, on the *unmodified* clean-room simulator, a ladder of policies that
use only estimated CSI to choose actions and are scored on true channels with
the simulator's own SIC/rate model:

  P0  Decoupled-MRR            (reproduces the archived baseline)
  P1  Fixed-site               (reproduces the archived baseline)
  P2  Aggregate-target anchor  (env's weighted target phase, heuristic power)
  P3  Static best-w anchor     (one w chosen on a calibration stream)
  P4  Per-step anchor search   (site + w grid, heuristic power)
  P5  MRR phase + power search (power headroom alone)
  P6  Per-step full anchor     (site + w grid + power grid)  <- AEHA target
  P7  Gradient refinement      (per-element phases + power, from P6) <- residual headroom
  G6  P6 selected with true CSI (genie reference, not implementable)

Channels evolve independently of actions, so every policy sees the identical
channel stream that ``evaluate_policy`` uses (env seed = seed + 100000).
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from dataclasses import replace
from pathlib import Path

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import numpy as np
import torch

REPO = Path(__file__).resolve().parent / "simulator"  # bundled copy (released package)
if not (REPO / "ris_noma_experiments.py").exists():
    REPO = (
        Path(__file__).resolve().parents[1]
        / "Hybrid-SAC-RIS-NOMA-Code-main"
        / "Hybrid-SAC-RIS-NOMA-Code-main"
        / "Hybrid-SAC-RIS-NOMA-Code"
        / "Hybrid-SAC-RIS-NOMA-Code"
    )
sys.path.insert(0, str(REPO))
import ris_noma_experiments as rx  # noqa: E402


# --------------------------------------------------------------------------
# Vectorised replica of RISNOMAEnv.evaluate_action's rate model
# --------------------------------------------------------------------------
def nomarates(g_true, g_est, p, cfg, rho=None, payload=None):
    """Rates under estimated SIC order and min-over-decoders feasibility.

    g_true, g_est, p broadcast to (..., K).  Returns rates (..., K) in the
    estimated weak->strong order (order does not matter for the metrics).
    """
    rho = cfg.residual_sic if rho is None else rho
    payload = cfg.payload_fraction if payload is None else payload
    shape = np.broadcast_shapes(np.shape(g_true), np.shape(g_est), np.shape(p))
    g_true = np.broadcast_to(g_true, shape)
    g_est = np.broadcast_to(g_est, shape)
    p = np.broadcast_to(p, shape)
    order = np.argsort(g_est, axis=-1)
    gs = np.take_along_axis(g_true, order, axis=-1)
    ps = np.take_along_axis(p, order, axis=-1)
    K = shape[-1]
    out = []
    for r in range(K):
        unc = ps[..., r + 1 :].sum(-1)
        canc = ps[..., :r].sum(-1)
        dec = gs[..., r:]
        sinr = (dec * ps[..., r : r + 1] / (dec * (unc + rho * canc)[..., None] + cfg.noise_power)).min(-1)
        out.append(payload * cfg.bandwidth_mhz * np.log2(1.0 + sinr))
    return np.stack(out, -1)


def metrics(rates, cfg):
    s = rates.sum(-1)
    denom = rates.shape[-1] * (rates**2).sum(-1)
    jain = np.where(denom > 0, s**2 / np.where(denom > 0, denom, 1.0), 0.0)
    viol = (rates < cfg.min_rate_mbps).sum(-1)
    qos = 1.0 - viol / rates.shape[-1]
    reward = cfg.reward_rate * s + cfg.reward_fair * jain - cfg.reward_qos * viol
    # Selection score.  "reward" is the manuscript's scalarised reward;
    # "constrained" maximises sum-rate subject to every user meeting r_min
    # (lexicographic: fewer violations always wins).
    # MARGIN tightens r_min for *selection only* (robustness to CSI error);
    # reported QoS always uses the plain r_min.
    viol_sel = (rates < cfg.min_rate_mbps * (1.0 + MARGIN)).sum(-1)
    score = reward if OBJECTIVE == "reward" else s - CONSTRAINT_PENALTY * viol_sel
    return dict(sum_rate=s, fairness=jain, qos=qos, reward=reward, score=score)


OBJECTIVE = "reward"
MARGIN = 0.0
CONSTRAINT_PENALTY = 1_000.0


def simplex_grid(K, steps, positive):
    pts = []
    lo = 1 if positive else 0

    def rec(prefix, remaining, slots):
        if slots == 1:
            if remaining >= lo:
                pts.append(prefix + [remaining])
            return
        for v in range(lo, remaining + 1):
            rec(prefix + [v], remaining - v, slots - 1)

    rec([], steps, K)
    return np.asarray(pts, dtype=np.float64) / steps


def heuristic_power(d_est, cfg):
    direct = np.maximum(np.abs(d_est), 0.05)
    alloc = 1.0 / direct
    logits = np.clip(np.log(alloc / alloc.sum() + 1e-9), -1.0, 1.0)
    logits -= logits.max()
    p = np.exp(logits)
    return cfg.p_max * p / p.sum()


def anchor_phases(casc_l, d_est, W):
    """theta_n = -arg(sum_k w_k g_{k,n} conj(h_{d,k})); casc_l (K,N), W (M,K)."""
    agg = np.einsum("mk,kn->mn", W, casc_l * np.conj(d_est)[:, None])
    return np.mod(-np.angle(agg), 2.0 * math.pi)


def eff_gains(d, casc_l, theta):
    """|h_d + sum_n g_n e^{j theta_n}|^2 for theta (M,N) -> (M,K)."""
    refl = np.einsum("kn,mn->mk", casc_l, np.exp(1j * theta))
    return np.abs(d[None, :] + refl) ** 2


# --------------------------------------------------------------------------
# Channel stream collection (also records the archived heuristics exactly)
# --------------------------------------------------------------------------
def collect(cfg, env_seed, steps):
    env = rx.RISNOMAEnv(cfg, env_seed)
    env.reset()
    snaps, ref = [], {"P0": [], "P1": []}
    for _ in range(steps):
        ch = env._channels
        snaps.append(
            dict(
                d_true=ch["direct_true"].astype(np.complex128),
                d_est=ch["direct_est"].astype(np.complex128),
                casc=ch["cascaded"].astype(np.complex128),
                casc_est=ch["casc_est"].astype(np.complex128),
                target_phase=ch["target_phase"].astype(np.float64),
                site_score=ch["site_score"].astype(np.float64),
            )
        )
        for key, name in (("P1", "fixed_site"), ("P0", "decoupled")):
            site, act = env.heuristic_action(name)
            info = env.evaluate_action(site, act)
            ref[key].append((info["sum_rate"], info["fairness"], info["qos"], info["reward"], site, act))
        site, act = env.heuristic_action("decoupled")
        _, _, done, _ = env.step(site, act)
        if done:
            env.reset()
    return snaps, ref


# --------------------------------------------------------------------------
# Policies
# --------------------------------------------------------------------------
def eval_fixed(snap, cfg, site, theta, p):
    g_t = eff_gains(snap["d_true"], snap["casc"][site], theta[None])[0]
    g_e = eff_gains(snap["d_est"], snap["casc_est"][site], theta[None])[0]
    return metrics(nomarates(g_t, g_e, p, cfg), cfg)


def search(snap, cfg, W, P, select_true=False):
    """Exhaustive search over (site, w in W, p in P) using estimated CSI.

    Returns dict with true metrics of the chosen action, plus the choice.
    """
    best = None
    for site in range(cfg.n_sites):
        theta = anchor_phases(snap["casc_est"][site], snap["d_est"], W)  # (M,N)
        g_e = eff_gains(snap["d_est"], snap["casc_est"][site], theta)  # (M,K)
        g_t = eff_gains(snap["d_true"], snap["casc"][site], theta)
        sel_g = g_t if select_true else g_e
        r_sel = nomarates(sel_g[:, None, :], g_e[:, None, :], P[None, :, :], cfg)
        rew = metrics(r_sel, cfg)["score"]  # (M,P)
        i, j = np.unravel_index(np.argmax(rew), rew.shape)
        if best is None or rew[i, j] > best[0]:
            best = (rew[i, j], site, theta[i], P[j], W[i])
    _, site, theta, p, w = best
    m = eval_fixed(snap, cfg, site, theta, p)
    return m, dict(site=site, theta=theta, p=p, w=w, est_reward=best[0])


def grad_refine(snaps, choices, cfg, iters=300, lr=0.05):
    """Per-element phase + power refinement on estimated CSI, batched over steps.

    Initialised at the P6 choice for every site; keeps a result only if its
    hard estimated reward improves on the P6 initialisation (monotone guard).
    """
    T, K = len(snaps), cfg.n_users
    best_rew = np.array([c["est_reward"] for c in choices])
    out_theta = [c["theta"] for c in choices]
    out_p = [c["p"] for c in choices]
    out_site = [c["site"] for c in choices]
    d_est = torch.tensor(np.stack([s["d_est"] for s in snaps]))
    W = simplex_grid(K, 10, positive=False)
    for site in range(cfg.n_sites):
        ce = torch.tensor(np.stack([s["casc_est"][site] for s in snaps]))  # (T,K,N)
        # init: best anchor for this site under the chosen power
        th0, lp0 = [], []
        for t, s in enumerate(snaps):
            theta = anchor_phases(s["casc_est"][site], s["d_est"], W)
            g_e = eff_gains(s["d_est"], s["casc_est"][site], theta)
            rew = metrics(nomarates(g_e, g_e, choices[t]["p"][None], cfg), cfg)["score"]
            th0.append(theta[np.argmax(rew)])
            lp0.append(np.log(choices[t]["p"] + 1e-9))
        theta = torch.tensor(np.stack(th0), requires_grad=True)
        logit = torch.tensor(np.stack(lp0), requires_grad=True)
        opt = torch.optim.Adam([theta, logit], lr=lr)
        for _ in range(iters):
            h = d_est + torch.einsum("tkn,tn->tk", ce, torch.exp(1j * theta.to(torch.complex128)))
            g = h.abs() ** 2
            p = cfg.p_max * torch.softmax(logit, -1)
            order = torch.argsort(g.detach(), -1)
            gs, ps = torch.gather(g, 1, order), torch.gather(p, 1, order)
            rates = []
            for r in range(K):
                unc = ps[:, r + 1 :].sum(-1)
                canc = ps[:, :r].sum(-1)
                dec = gs[:, r:]
                sinr = (dec * ps[:, r : r + 1] / (dec * (unc + cfg.residual_sic * canc)[:, None] + cfg.noise_power)).min(-1).values
                rates.append(cfg.payload_fraction * cfg.bandwidth_mhz * torch.log2(1 + sinr))
            rates = torch.stack(rates, -1)
            s_ = rates.sum(-1)
            jain = s_**2 / (K * (rates**2).sum(-1) + 1e-12)
            soft_viol = torch.sigmoid((cfg.min_rate_mbps - rates) / 0.05).sum(-1)
            if OBJECTIVE == "reward":
                loss = -(cfg.reward_rate * s_ + cfg.reward_fair * jain - cfg.reward_qos * soft_viol).mean()
            else:
                loss = -(s_ - 50.0 * soft_viol).mean()
            opt.zero_grad()
            loss.backward()
            opt.step()
        th = np.mod(theta.detach().numpy(), 2 * math.pi)
        pp = (cfg.p_max * torch.softmax(logit.detach(), -1)).numpy()
        for t, s in enumerate(snaps):
            g_e = eff_gains(s["d_est"], s["casc_est"][site], th[t][None])[0]
            rew = metrics(nomarates(g_e, g_e, pp[t], cfg), cfg)["score"]
            if rew > best_rew[t]:
                best_rew[t], out_theta[t], out_p[t], out_site[t] = rew, th[t], pp[t], site
    return [eval_fixed(s, cfg, out_site[t], out_theta[t], out_p[t]) for t, s in enumerate(snaps)]


# --------------------------------------------------------------------------
def summarise(per_step):
    keys = ("sum_rate", "fairness", "qos", "reward")
    arr = {k: np.array([float(m[k]) for m in per_step]) for k in keys}
    return dict(
        sum_rate_mean=arr["sum_rate"].mean(),
        fairness=arr["fairness"].mean(),
        qos_percent=100 * arr["qos"].mean(),
        reward=arr["reward"].mean(),
    )


def run_seed(cfg, seed, calib_steps, w_steps, p_steps, do_grad):
    t0 = time.time()
    K = cfg.n_users
    W = simplex_grid(K, w_steps, positive=False)
    P = simplex_grid(K, p_steps, positive=True) * cfg.p_max
    snaps, ref = collect(cfg, seed + 100_000, cfg.eval_steps)
    res = {}

    # P0/P1 straight from the simulator + replica consistency check.
    for key in ("P0", "P1"):
        res[key] = dict(
            sum_rate_mean=np.mean([r[0] for r in ref[key]]),
            fairness=np.mean([r[1] for r in ref[key]]),
            qos_percent=100 * np.mean([r[2] for r in ref[key]]),
            reward=np.mean([r[3] for r in ref[key]]),
        )
    max_err = 0.0
    for s, r in zip(snaps, ref["P0"]):
        site, act = r[4], r[5]
        theta = math.pi * (act[: cfg.n_ris].astype(np.float64) + 1.0)
        lg = act[cfg.n_ris :].astype(np.float64)
        lg = lg - lg.max()
        p = cfg.p_max * np.exp(lg) / np.exp(lg).sum()
        max_err = max(max_err, abs(float(eval_fixed(s, cfg, site, theta, p)["sum_rate"]) - r[0]))
    res["replica_max_abs_err"] = max_err

    # P2: env's aggregate target + site_score argmax + heuristic power.
    p2 = []
    for s in snaps:
        site = int(np.argmax(s["site_score"]))
        p2.append(eval_fixed(s, cfg, site, s["target_phase"][site], heuristic_power(s["d_est"], cfg)))
    res["P2"] = summarise(p2)

    # P3: one static w chosen on a separate calibration stream (env seed = seed).
    csnaps, _ = collect(replace(cfg, eval_steps=calib_steps), seed, calib_steps)
    score = np.zeros(len(W))
    for s in csnaps:
        ph = heuristic_power(s["d_est"], cfg)
        per_site = []
        for site in range(cfg.n_sites):
            th = anchor_phases(s["casc_est"][site], s["d_est"], W)
            g_e = eff_gains(s["d_est"], s["casc_est"][site], th)
            per_site.append(metrics(nomarates(g_e, g_e, ph[None], cfg), cfg)["score"])
        score += np.max(np.stack(per_site), axis=0)
    w_star = W[np.argmax(score)]
    res["P3"] = summarise([search(s, cfg, w_star[None], heuristic_power(s["d_est"], cfg)[None])[0] for s in snaps])
    res["P3_w"] = w_star.tolist()

    # P4: per-step anchor search, heuristic power.
    res["P4"] = summarise([search(s, cfg, W, heuristic_power(s["d_est"], cfg)[None])[0] for s in snaps])

    # P5: MRR site/phase, power grid.
    p5 = []
    for s, r in zip(snaps, ref["P0"]):
        site, act = r[4], r[5]
        theta = math.pi * (act[: cfg.n_ris].astype(np.float64) + 1.0)
        g_e = eff_gains(s["d_est"], s["casc_est"][site], theta[None])[0]
        rew = metrics(nomarates(g_e[None], g_e[None], P, cfg), cfg)["score"]
        p5.append(eval_fixed(s, cfg, site, theta, P[np.argmax(rew)]))
    res["P5"] = summarise(p5)

    # P6: full anchor family; G6: same family selected with true CSI.
    p6, choices = zip(*[search(s, cfg, W, P) for s in snaps])
    res["P6"] = summarise(p6)
    ratios = np.array([c["p"].max() / c["p"].min() for c in choices])
    res["P6_power_ratio_gt_e2_percent"] = 100 * float(np.mean(ratios > math.e**2))
    res["P6_w_is_vertex_percent"] = 100 * float(np.mean([np.isclose(c["w"].max(), 1.0) for c in choices]))
    res["G6"] = summarise([search(s, cfg, W, P, select_true=True)[0] for s in snaps])

    # P8: per-step (site, w) search with the closed-form QoS-floor power layer
    # at the same selection margin (validates the AEHA power layer vs the grid).
    from aeha_core import qos_floor_power

    W8 = simplex_grid(K, 5, positive=False)
    p8 = []
    for s in snaps:
        best = None
        for site in range(cfg.n_sites):
            th = anchor_phases(s["casc_est"][site], s["d_est"], W8)
            g_e = eff_gains(s["d_est"], s["casc_est"][site], th)
            for i in range(len(W8)):
                p = qos_floor_power(g_e[i], cfg, MARGIN)
                sc = float(metrics(nomarates(g_e[i], g_e[i], p, cfg), cfg)["score"])
                if best is None or sc > best[0]:
                    best = (sc, site, th[i], p)
        p8.append(eval_fixed(s, cfg, best[1], best[2], best[3]))
    res["P8"] = summarise(p8)

    if do_grad:
        res["P7"] = summarise(grad_refine(snaps, list(choices), cfg))
    res["seconds"] = time.time() - t0
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default="paper")
    ap.add_argument("--seeds", default="11,22,33,44,55")
    ap.add_argument("--n-sites", type=int, default=None)
    ap.add_argument("--calib-steps", type=int, default=500)
    ap.add_argument("--w-steps", type=int, default=10)
    ap.add_argument("--p-steps", type=int, default=20)
    ap.add_argument("--no-grad", action="store_true")
    ap.add_argument("--out", default=str(Path(__file__).resolve().parent / "results_headroom"))
    ap.add_argument("--objective", choices=("reward", "constrained"), default="constrained")
    ap.add_argument("--margin", type=float, default=0.0)
    a = ap.parse_args()
    global OBJECTIVE, MARGIN
    OBJECTIVE = a.objective
    MARGIN = a.margin

    cfg = rx.Config(**rx.PROFILES[a.profile])
    if a.n_sites:
        cfg = replace(cfg, n_sites=a.n_sites)
    rx.seed_everything(0)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    seeds = [int(x) for x in a.seeds.split(",")]
    all_res = {}
    for seed in seeds:
        all_res[seed] = run_seed(cfg, seed, a.calib_steps, a.w_steps, a.p_steps, not a.no_grad)
        print(f"seed {seed} done in {all_res[seed]['seconds']:.0f}s "
              f"(replica err {all_res[seed]['replica_max_abs_err']:.2e})", flush=True)

    # Aggregate: mean +/- t-CI across seeds, and paired difference vs P0.
    from scipy import stats

    policies = [k for k in ("P0", "P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "G6") if k in all_res[seeds[0]]]
    rows = []
    for pol in policies:
        row = {"policy": pol}
        for m in ("sum_rate_mean", "fairness", "qos_percent", "reward"):
            v = np.array([all_res[s][pol][m] for s in seeds])
            d = v - np.array([all_res[s]["P0"][m] for s in seeds])
            crit = stats.t.ppf(0.975, len(seeds) - 1)
            row[m] = v.mean()
            row[m + "_ci95"] = crit * v.std(ddof=1) / math.sqrt(len(seeds))
            row[m + "_vsP0"] = d.mean()
            row[m + "_vsP0_ci95"] = crit * d.std(ddof=1) / math.sqrt(len(seeds))
        rows.append(row)
    import pandas as pd

    tag = f"L{cfg.n_sites}_{a.profile}_{a.objective}" + (f"_m{a.margin:g}" if a.margin else "")
    pd.DataFrame(rows).to_csv(out / f"headroom_{tag}.csv", index=False)
    (out / f"headroom_{tag}_raw.json").write_text(json.dumps(all_res, indent=2, default=float), encoding="utf-8")
    pd.set_option("display.width", 200)
    cols = ["policy", "sum_rate_mean", "sum_rate_mean_vsP0", "sum_rate_mean_vsP0_ci95",
            "fairness", "qos_percent", "qos_percent_vsP0", "qos_percent_vsP0_ci95", "reward", "reward_vsP0_ci95"]
    print(pd.DataFrame(rows)[cols].round(3).to_string(index=False))
    for s in seeds:
        r = all_res[s]
        print(f"seed {s}: w*={np.round(r['P3_w'], 2)}  P6 power-ratio>e^2: {r['P6_power_ratio_gt_e2_percent']:.1f}%  "
              f"P6 w at vertex: {r['P6_w_is_vertex_percent']:.1f}%")


if __name__ == "__main__":
    main()
