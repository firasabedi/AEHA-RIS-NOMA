"""All manuscript figures for the AEHA paper (static, print, light mode).

One colour per method across every figure (reference categorical palette,
slots 1-8 in validated order); AEHA variants use a darker step of AEHA's blue
ramp.  Markers + dashes give a colour-independent channel for greyscale print.
QoS is plotted as rate-target violations (100 - QoS, % of user-intervals) on a
log axis, so methods near the 1% target and methods far from it are both legible.
"""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.ticker import FuncFormatter  # noqa: E402
from scipy import stats  # noqa: E402

HERE = Path(__file__).resolve().parent
OUT = HERE / "manuscript" / "figs"
OUT.mkdir(parents=True, exist_ok=True)
INK, INK2, GRID, AXIS = "#0b0b0b", "#52514e", "#e1e0d9", "#c3c2b7"
SEEDS10 = (11, 22, 33, 44, 55, 66, 77, 88, 99, 110)
SEEDS5 = (11, 22, 33, 44, 55)

ORDER = ["AEHA", "Hybrid-SAC", "DDPG-Hybrid", "Hybrid-SAC (constrained)", "Physics layer", "Weighted target",
         "Decoupled-MRR", "Fixed-site"]
STYLE = {  # colour, marker, dash
    "AEHA": ("#2a78d6", "o", "solid"),
    "Hybrid-SAC": ("#eb6834", "^", (0, (4, 1.5))),
    "DDPG-Hybrid": ("#1baf7a", "v", (0, (1.5, 1.2))),
    "Hybrid-SAC (constrained)": ("#eda100", "<", (0, (5, 1.5, 1, 1.5))),
    "Physics layer": ("#e87ba4", "D", (0, (3, 1.5))),
    "Weighted target": ("#008300", "P", (0, (1, 1))),
    "Decoupled-MRR": ("#6250d6", "s", (0, (6, 2))),
    "Fixed-site": ("#e34948", "X", (0, (2, 2))),
    "AEHA (quant-aware)": ("#184f95", "o", (0, (1, 1))),
    "AEHA (rho-aware)": ("#184f95", "o", (0, (1, 1))),
    "AEHA (zero-shot)": ("#184f95", "o", (0, (1, 1))),
}
INTERNAL = {"AEHA-res-fixed-delta": "AEHA", "Agg-conf-d0.01": "Physics layer", "Agg-target": "Weighted target",
            "Hybrid-SAC-Lagr": "Hybrid-SAC (constrained)"}
VLAB = "Rate-target violations (%)"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8.5, "axes.edgecolor": AXIS, "axes.linewidth": 0.8,
    "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "axes.titlesize": 9, "axes.titlecolor": INK,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True,
    "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False, "savefig.dpi": 300,
    "savefig.bbox": "tight",
})


def save(fig, name):
    for ext in ("pdf", "png"):
        fig.savefig(OUT / f"{name}.{ext}")
    plt.close(fig)


def ci(v):
    v = np.asarray(v, float)
    v = v[np.isfinite(v)]
    return float(stats.t.ppf(0.975, len(v) - 1) * v.std(ddof=1) / np.sqrt(len(v))) if len(v) > 1 else 0.0


def prep(raw):
    raw = raw.copy()
    raw["method"] = raw["method"].map(lambda m: INTERNAL.get(m, m))
    raw["viol_geo"] = 100.0 - raw["qos_geo"]
    return raw


def logviol(ax, axis="y"):
    (ax.set_yscale if axis == "y" else ax.set_xscale)("log")
    fmt = FuncFormatter(lambda v, _: f"{v:g}")
    (ax.yaxis if axis == "y" else ax.xaxis).set_major_formatter(fmt)
    (ax.axhline if axis == "y" else ax.axvline)(1.0, color=INK2, linestyle=(0, (3, 2)), linewidth=0.9, zorder=1)


def legend_below(fig, axes, ncol=4, y=-0.02):
    h, lab = [], []
    for ax in np.atleast_1d(axes):
        for hh, ll in zip(*ax.get_legend_handles_labels()):
            if ll not in lab:
                h.append(hh)
                lab.append(ll)
    fig.legend(h, lab, loc="upper center", ncol=ncol, fontsize=7.2, bbox_to_anchor=(0.5, y))


def line(ax, x, y, e, name, label=None):
    c, m, ls = STYLE[name]
    ax.errorbar(x, y, yerr=e, color=c, marker=m, linestyle=ls, linewidth=2.0 if name == "AEHA" else 1.3,
                markersize=5, markeredgecolor="white", markeredgewidth=0.7, capsize=2, elinewidth=0.8,
                label=label or name, zorder=3 if name.startswith("AEHA") else 2)


# ------------------------------------------------------------------ data
main = prep(pd.read_csv(HERE / "results_final" / "merged_all" / "metrics_raw.csv"))
scen = prep(pd.read_csv(HERE / "results_scen_eval" / "merged" / "scen_raw.csv"))


def manifest_logs(d):
    return json.loads((d / "run_manifest.json").read_text(encoding="utf-8"))["training_logs"]


def conv_step(curve, every=100):
    if not curve or len(curve) < 5:
        return np.nan
    final = np.mean(curve[-5:])
    for i in range(len(curve) - 4):
        if np.mean(curve[i:i + 5]) >= 0.95 * final:
            return (i + 5) * every
    return len(curve) * every


# Convergence at L=3 from the saved training curves (B runs predate the column).
conv3 = []
for s in SEEDS5:
    for d in ("B", "P"):
        for lg in manifest_logs(HERE / "results_final" / f"{d}_seed{s}"):
            name = INTERNAL.get(lg["method"], lg["method"])
            if "sum_rate_curve" in lg and name in ORDER:
                conv3.append(dict(method=name, seed=s, convergence_steps=conv_step(lg["sum_rate_curve"])))
conv3 = pd.DataFrame(conv3)

# ------------------------------------------------------------------ Fig: main comparison
fig, axes = plt.subplots(1, 3, figsize=(7.4, 2.9), sharey=True, gridspec_kw=dict(wspace=0.12))
y = np.arange(len(ORDER))[::-1]
g = main[main.method.isin(ORDER)].groupby("method")
for ax, (col, lab) in zip(axes, [("sum_rate_geo", "Net sum-rate (Mbps)"), ("viol_geo", VLAB),
                                 ("fairness_geo", "Jain fairness")]):
    m, e = g[col].mean(), g[col].apply(ci)
    vals, errs = np.array([m[k] for k in ORDER]), np.array([e[k] for k in ORDER])
    left = 0.1 if col == "viol_geo" else 0
    ax.barh(y, vals - left, left=left, height=0.66, color=[STYLE[k][0] for k in ORDER], edgecolor="white", linewidth=1)
    ax.errorbar(vals, y, xerr=errs, fmt="none", ecolor=INK, elinewidth=0.8, capsize=2)
    for yi, v, er in zip(y, vals, errs):
        ax.annotate(f"{v:.3f}" if col == "fairness_geo" else f"{v:.2f}", (v + er, yi), xytext=(2, 0),
                    textcoords="offset points", va="center", fontsize=6.3, color=INK2,
                    bbox=dict(boxstyle="square,pad=0.08", facecolor="white", edgecolor="none"))
    if col == "viol_geo":
        logviol(ax, "x")
        ax.set_xlim(0.1, 60)
    elif col == "sum_rate_geo":
        ax.set_xlim(0, 27)
    else:
        ax.set_xlim(0, 0.88)
        ax.set_xticks([0, 0.2, 0.4, 0.6, 0.8])
    ax.set_xlabel(lab)
    ax.grid(axis="y", visible=False)
    ax.tick_params(axis="y", length=0)
axes[0].set_yticks(y, ORDER, fontsize=7.3)
save(fig, "fig_main_comparison")

# ------------------------------------------------------------------ Fig: training convergence
curves = {}
for s in SEEDS10:
    for d in ("B", "P"):
        for lg in manifest_logs(HERE / "results_final" / f"{d}_seed{s}"):
            name = INTERNAL.get(lg["method"], lg["method"])
            if name in ("AEHA", "Hybrid-SAC", "DDPG-Hybrid", "Hybrid-SAC (constrained)") and "sum_rate_curve" in lg:
                curves.setdefault(name, []).append(lg["sum_rate_curve"])
fig, ax = plt.subplots(figsize=(4.8, 2.9))
for name in ("AEHA", "Hybrid-SAC (constrained)", "Hybrid-SAC", "DDPG-Hybrid"):
    arr = np.array(curves[name])
    sm = pd.DataFrame(arr.T).rolling(5, min_periods=1).mean().values.T  # 500-step smoothing
    x = (np.arange(sm.shape[1]) + 1) * 100
    mu = sm.mean(0)
    half = stats.t.ppf(0.975, sm.shape[0] - 1) * sm.std(0, ddof=1) / np.sqrt(sm.shape[0])
    c, mk, ls = STYLE[name]
    ax.plot(x, mu, color=c, linestyle=ls, linewidth=2.0 if name == "AEHA" else 1.4, label=name)
    ax.fill_between(x, mu - half, mu + half, color=c, alpha=0.15, linewidth=0)
mrr = main[main.method == "Decoupled-MRR"].sum_rate_mean.mean()
ax.axhline(mrr, color=STYLE["Decoupled-MRR"][0], linestyle=STYLE["Decoupled-MRR"][2], linewidth=1.0)
ax.text(7950, mrr - 0.15, "Decoupled-MRR (evaluation)", ha="right", va="top", fontsize=6.8, color=INK2,
        bbox=dict(boxstyle="square,pad=0.1", facecolor="white", edgecolor="none"))
ax.set_xlabel("Training step")
ax.set_ylabel("Training sum-rate (Mbps)")
ax.legend(fontsize=7, loc="upper left", ncol=2)
ax.set_ylim(16.5, 25.5)
save(fig, "fig_convergence")

ALL8 = ORDER


# ------------------------------------------------------------------ grouped bars
def grouped(settings, labels, methods, fname):
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 2.9), gridspec_kw=dict(wspace=0.22))
    w = 0.84 / len(methods)
    for ax, (col, lab) in zip(axes, (("sum_rate_geo", "Net sum-rate (Mbps)"), ("viol_geo", VLAB))):
        for i, mth in enumerate(methods):
            vals, errs = [], []
            for st in settings:
                gg = scen[(scen.setting == st) & (scen.method == mth)][col]
                vals.append(gg.mean() if len(gg) else np.nan)
                errs.append(ci(gg) if len(gg) > 1 else 0)
            x = np.arange(len(settings)) + (i - (len(methods) - 1) / 2) * w
            base = 0.1 if col == "viol_geo" else 0
            ax.bar(x, np.array(vals) - base, bottom=base, width=w * 0.92, color=STYLE[mth][0], edgecolor="white",
                   linewidth=0.5, label=mth, hatch="////" if "quant-aware" in mth else None)
            ax.errorbar(x, vals, yerr=errs, fmt="none", ecolor=INK, elinewidth=0.6, capsize=1)
        if col == "viol_geo":
            logviol(ax)
            ax.set_ylim(0.1, 60)
        ax.set_xticks(np.arange(len(settings)), labels, fontsize=7.6)
        ax.set_ylabel(lab)
        ax.grid(axis="x", visible=False)
    legend_below(fig, axes, ncol=5, y=-0.03)
    save(fig, fname)


grouped(["base", "2-bit", "1-bit"], ["continuous", "2-bit", "1-bit"],
        ["AEHA", "AEHA (quant-aware)"] + ALL8[1:], "fig_quantization")
grouped(["ideal", "pilot-only", "base"],
        ["ideal\n(no pilot, $\\rho=0$)", "pilot only\n($\\rho=0$)", "pilot + residual\nSIC ($\\rho=0.08$)"],
        ALL8, "fig_impairments")


# ------------------------------------------------------------------ line sweeps
def sweep(xmap, methods, fname, xlabel, xticks=None):
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 2.9), gridspec_kw=dict(wspace=0.24))
    for ax, (col, lab) in zip(axes, (("sum_rate_geo", "Net sum-rate (Mbps)"), ("viol_geo", VLAB))):
        for mth in methods:
            xs, ys, es = [], [], []
            for st, xv in xmap.items():
                gg = scen[(scen.setting == st) & (scen.method == mth)][col]
                if len(gg):
                    xs.append(xv)
                    ys.append(gg.mean())
                    es.append(ci(gg))
            if xs:
                line(ax, xs, ys, es, mth)
        if col == "viol_geo":
            logviol(ax)
            ax.set_ylim(0.2, 60)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(lab)
        if xticks:
            ax.set_xticks(xticks)
    legend_below(fig, axes, ncol=5, y=-0.02)
    save(fig, fname)


rho_map = {"rho=0": 0, "rho=0.01": 0.01, "rho=0.02": 0.02, "rho=0.04": 0.04, "rho=0.06": 0.06, "base": 0.08,
           "rho=0.11": 0.11, "rho=0.15": 0.15}
sweep(rho_map, ["AEHA", "AEHA (rho-aware)"] + ALL8[1:], "fig_rho_sweep", r"Residual-SIC factor $\rho$",
      xticks=[0, 0.02, 0.04, 0.06, 0.08, 0.11, 0.15])
sweep({"csi=0.02": 0.02, "base": 0.05, "csi=0.1": 0.10}, ALL8, "fig_csi", r"CSI-error variance $\sigma_e^2$",
      xticks=[0.02, 0.05, 0.10])

# ------------------------------------------------------------------ size scaling
SETNAME = {"L20": "L=20", "L50": "L=50", "K20": "K=20", "K50": "K=50", "N32": "N=32", "N128": "N=128"}


def size_fig(tags, xs, fname, xlabel, extra=False):
    rows = []
    for tag, xv in zip(tags, xs):
        if tag is None:
            d = main[main.seed.isin(SEEDS5)].copy()
            if "convergence_steps" in d:
                d = d.drop(columns="convergence_steps")
            d = d.merge(conv3, on=["method", "seed"], how="left")
        else:
            d = prep(pd.read_csv(HERE / "results_scen" / f"{tag}_merged" / "metrics_raw.csv"))
        d["x"] = xv
        rows.append(d)
    d = pd.concat(rows, ignore_index=True)
    zs = scen[(scen.method == "AEHA") & (scen.seed.isin(SEEDS5))]
    panels = [("sum_rate_geo", "Net sum-rate (Mbps)"), ("viol_geo", VLAB)]
    if extra:
        panels += [("convergence_steps", "Convergence step"), ("decision_median", "Decision time, median (ms)")]
    nrow = len(panels) // 2
    fig, axes = plt.subplots(nrow, 2, figsize=(7.4, 2.8 * nrow), gridspec_kw=dict(wspace=0.24, hspace=0.42))
    axes = np.atleast_2d(axes)
    timing = pd.read_csv(HERE / "results_timing_all.csv") if extra else None
    for ax, (col, lab) in zip(axes.ravel(), panels):
        for mth in ALL8:
            if col == "decision_median":
                tt = timing[timing.method == mth].sort_values("L")
                line(ax, tt.L.values, tt[col].values, None, mth)
                continue
            gg = d[d.method == mth]
            if col not in gg or gg[col].isna().all():
                continue
            mu = gg.groupby("x")[col].mean()
            er = gg.groupby("x")[col].apply(ci)
            line(ax, mu.index.values, mu.values, er.values, mth)
        if col in ("sum_rate_geo", "viol_geo"):
            zx, zy, ze = [], [], []
            for tagname, xv in zip(tags, xs):
                st = "base" if tagname is None else SETNAME[tagname]
                gg = zs[zs.setting == st][col]
                if len(gg):
                    zx.append(xv)
                    zy.append(gg.mean())
                    ze.append(ci(gg))
            line(ax, zx, zy, ze, "AEHA (zero-shot)", label="AEHA (zero-shot from $L$=3, $N_r$=64, $K$=10)")
        if col == "viol_geo":
            logviol(ax)
        if col == "decision_median":
            ax.axhline(1.0, color=INK2, linestyle=(0, (3, 2)), linewidth=0.9)
            ax.text(xs[-1], 1.04, "1 ms", ha="right", va="bottom", fontsize=6.8, color=INK2)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(lab)
        ax.set_xticks(xs)
    legend_below(fig, axes.ravel(), ncol=5, y=0.01 if nrow > 1 else -0.02)
    save(fig, fname)


size_fig([None, "L20", "L50"], [3, 20, 50], "fig_sites", "Candidate RIS sites $L$", extra=True)
size_fig([None, "K20", "K50"], [10, 20, 50], "fig_vehicles", "Vehicle pool $K$")
size_fig(["N32", None, "N128"], [32, 64, 128], "fig_elements", "RIS elements $N_r$")

# ------------------------------------------------------------------ fairness trade-off
fig, ax = plt.subplots(figsize=(4.8, 3.2))
phis = ["base", "phi=0.5", "phi=1", "phi=2", "phi=4"]
for mth in ("AEHA", "Physics layer"):
    xs = [scen[(scen.setting == st) & (scen.method == mth)].fairness_geo.mean() for st in phis]
    ys = [scen[(scen.setting == st) & (scen.method == mth)].sum_rate_geo.mean() for st in phis]
    c, mk, ls = STYLE[mth]
    ax.plot(xs, ys, color=c, marker=mk, linestyle=ls, linewidth=2.0 if mth == "AEHA" else 1.3, markersize=5.5,
            markeredgecolor="white", markeredgewidth=0.7, label=mth + r" ($\varphi$ = 0 ... 4)", zorder=3)
    if mth == "AEHA":
        for phi, x_, y_ in zip([0, 0.5, 1, 2, 4], xs, ys):
            ax.annotate(rf"$\varphi={phi:g}$", (x_, y_), xytext=(5, 3), textcoords="offset points", fontsize=6.6,
                        color=INK2)
for mth in ALL8[1:]:
    if mth == "Physics layer":
        continue
    gg = scen[(scen.setting == "base") & (scen.method == mth)]
    c, mk, _ = STYLE[mth]
    ax.plot(gg.fairness_geo.mean(), gg.sum_rate_geo.mean(), marker=mk, color=c, markersize=6.5, linestyle="none",
            markeredgecolor="white", markeredgewidth=0.7, label=mth)
ax.set_xlabel("Jain fairness index")
ax.set_ylabel("Net sum-rate (Mbps)")
ax.legend(fontsize=6.6, loc="upper right")
save(fig, "fig_fairness_tradeoff")

# ------------------------------------------------------------------ timing (clean single-process)
t = pd.read_csv(HERE / "results_timing_all.csv")
fig, axes = plt.subplots(1, 2, figsize=(7.4, 2.8), gridspec_kw=dict(wspace=0.24))
for ax, (col, lab) in zip(axes, (("decision_median", "Decision time, median (ms)"),
                                 ("loop_median", "Software-loop time, median (ms)"))):
    for mth in ALL8:
        gg = t[t.method == mth].sort_values("L")
        line(ax, gg.L.values, gg[col].values, None, mth)
    ax.axhline(1.0, color=INK2, linestyle=(0, (3, 2)), linewidth=0.9)
    ax.text(50, 1.04, "1 ms interval", ha="right", va="bottom", fontsize=6.8, color=INK2)
    ax.set_xlabel("Candidate RIS sites $L$")
    ax.set_ylabel(lab)
    ax.set_xticks([3, 20, 50])
legend_below(fig, axes, ncol=4, y=-0.02)
save(fig, "fig_timing")
print("figures written to", OUT)
