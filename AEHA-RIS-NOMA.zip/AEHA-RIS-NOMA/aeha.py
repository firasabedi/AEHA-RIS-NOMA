"""AEHA-SAC: Anchored Equivariant Hybrid Actor for joint RIS site/phase and
NOMA power control, trained with a Lagrangian QoS constraint.

Uses the unmodified clean-room simulator (``ris_noma_experiments.py``).
The only component that differs from the published Hybrid-SAC is the actor
(and the matching site-equivariant critic input); the physics layers live in
``aeha_core.py``.

Action of the AEHA actor
    site  l ~ pointer over shared per-site embeddings (Gumbel-softmax)
    w     = softmax(3 * a_w)                 -- anchor user weights (K)
    m     = m_max * (a_m + 1) / 2            -- CSI-robustness margin
    phases, powers = decode(l, w, m)         -- closed-form anchor + QoS floor

Training objective (both AEHA and the constrained Hybrid-SAC comparator)
    r = sum_rate - lambda * #violations, lambda from a PI controller on the
    deterministic policy's violation rate on a held-out validation stream
    (``DualController``; per-step dual ascent kept as mode "step")
Rewards are recomputed from stored (sum_rate, violations) with the current
lambda at every update, so the replay never holds stale penalties.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Callable, Dict, List, Optional

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal
from scipy import stats

import aeha_core as core
from aeha_core import rx

DEVICE, DTYPE = rx.DEVICE, rx.DTYPE
SCORE_IDX = None  # index of the site-score feature inside a token (set in token layout)


@dataclass(frozen=True)
class AEHAOptions:
    learn_site: bool = True
    learn_w: bool = True
    learn_m: bool = True  # learn the robustness knob (delta or margin) per state
    power_mode: str = "conformal"  # "conformal" | "floor" | "softmax"
    fixed_delta: float = 0.01
    delta_min: float = 0.002
    delta_max: float = 0.2
    fixed_m: float = 1.0
    m_max: float = 3.0
    w_scale: float = 3.0
    # Residual parameterisation around the non-learned layer (Agg-conf):
    # site logits = kappa * site_score + residual, w = softmax(log w_agg + w_scale a),
    # delta = delta0 * span**a; heads zero-initialised so the initial
    # deterministic actor equals the non-learned layer exactly.
    residual: bool = False
    delta0: float = 0.01
    delta_span: float = 10.0
    site_kappa: float = 10.0
    actor_delay: int = 0  # critic-only updates before the actor starts moving
    # rho-aware: residual-SIC level as an input feature; rho_train lists the
    # values sampled per episode (training env, power layer and features all
    # use the episode's rho); validation cycles through the same values.
    rho_aware: bool = False
    rho_train: tuple = ()


@dataclass(frozen=True)
class LagrangeOptions:
    eps: float = 0.01  # tolerated fraction of violated users
    mode: str = "pid-val"  # "pid-val" (validated PI controller) | "step" (per-step dual ascent)
    lam0: float = 2.0
    eta: float = 0.05  # "step" mode only
    lam_max: float = 200.0
    # "pid-val": every val_every steps the *deterministic* policy runs val_steps
    # on a fixed validation stream (env seed + 50000; disjoint from training and
    # evaluation); lambda = clip(lam0 + kp*e + ki*I), e = viol_frac - eps,
    # I = max(0, I + e)  (integral with anti-windup at zero).
    # A single 200-step stream is one vehicle geometry and proved unrepresentative
    # (val 0.3% vs eval 3.5% violations); validate over val_envs independent
    # geometries instead.
    # Geometry changes only every 100 steps (mobility period) and at episode
    # resets, so many short streams beat few long ones (check_validation.py).
    val_every: int = 500
    val_steps: int = 20
    val_envs: int = 25
    # Gains sized so lambda can exceed the observed marginal trade-off
    # (~16 Mbps per avoided violation) within the 16 checks of an 8000-step run;
    # kp=200/ki=50 left lambda at 11-23 with violations still at 2-3%.
    kp: float = 600.0
    ki: float = 300.0


class DualController:
    def __init__(self, lo: LagrangeOptions, n_users: int, rho_values=()):
        self.lo, self.K = lo, n_users
        self.lam, self.integral, self.history = lo.lam0, 0.0, []
        self.rho_values = tuple(rho_values)  # rho-aware: validation geometries cycle through these

    def on_step(self, viol):
        if self.lo.mode == "step":
            self.lam = float(np.clip(self.lam + self.lo.eta * (viol / self.K - self.lo.eps), 0.0, self.lo.lam_max))

    def on_validation(self, viol_frac, step):
        e = viol_frac - self.lo.eps
        self.integral = max(0.0, self.integral + e)
        self.lam = float(np.clip(self.lo.lam0 + self.lo.kp * e + self.lo.ki * self.integral, 0.0, self.lo.lam_max))
        self.history.append(dict(step=step, val_viol_frac=viol_frac, lam=self.lam))

    def maybe_validate(self, step, cfg, seed, policy):
        lo = self.lo
        if lo.mode != "pid-val" or (step + 1) % lo.val_every != 0:
            return
        vcfg = replace(cfg, eval_steps=lo.val_steps)

        def cfg_k(k):
            if not self.rho_values:
                return vcfg
            return replace(vcfg, residual_sic=self.rho_values[k % len(self.rho_values)])

        viol = np.mean([1.0 - evaluate(cfg_k(k), seed, policy, env_seed=seed + 50_000 + 1000 * k)["qos_percent"] / 100.0
                        for k in range(lo.val_envs)])
        self.on_validation(float(viol), step + 1)


# --------------------------------------------------------------------------
# Networks
# --------------------------------------------------------------------------
class SiteEncoder(nn.Module):
    """Shared MLP over [site token, global features] -> per-site embedding."""

    def __init__(self, site_dim, glob_dim, n_sites, hidden):
        super().__init__()
        self.site_dim, self.n_sites = site_dim, n_sites
        self.net = nn.Sequential(nn.Linear(site_dim + glob_dim, hidden), nn.ReLU(), nn.Linear(hidden, hidden), nn.ReLU())

    def split(self, state):
        L, sd = self.n_sites, self.site_dim
        tokens = state[:, : L * sd].view(-1, L, sd)
        glob = state[:, L * sd :]
        return tokens, glob

    def forward(self, state):
        tokens, glob = self.split(state)
        x = torch.cat([tokens, glob[:, None, :].expand(-1, tokens.shape[1], -1)], dim=-1)
        return self.net(x), tokens


class AEHAActor(nn.Module):
    def __init__(self, site_dim, glob_dim, n_sites, n_cont, hidden, opts: AEHAOptions, score_idx: int):
        super().__init__()
        self.opts, self.score_idx = opts, score_idx
        self.enc = SiteEncoder(site_dim, glob_dim, n_sites, hidden)
        self.site_head = nn.Linear(hidden, 1)
        self.body = nn.Sequential(nn.Linear(2 * hidden, hidden), nn.ReLU())
        self.mean_head = nn.Linear(hidden, n_cont)
        self.logstd_head = nn.Linear(hidden, n_cont)
        if opts.residual:
            for head in (self.site_head, self.mean_head):
                nn.init.zeros_(head.weight)
                nn.init.zeros_(head.bias)
            nn.init.zeros_(self.logstd_head.weight)
            nn.init.constant_(self.logstd_head.bias, -1.0)

    def sample(self, state, tau=0.8, deterministic=False):
        e, tokens = self.enc(state)
        logits = self.site_head(e).squeeze(-1)  # (B, L)
        if self.opts.residual:
            logits = logits + self.opts.site_kappa * tokens[:, :, self.score_idx]
        if not self.opts.learn_site:
            site = F.one_hot(tokens[:, :, self.score_idx].argmax(-1), logits.shape[-1]).to(DTYPE)
            logp_site = torch.zeros(state.shape[0], 1, dtype=DTYPE, device=state.device)
        else:
            if deterministic:
                site = F.one_hot(logits.argmax(-1), logits.shape[-1]).to(DTYPE)
            else:
                site = F.gumbel_softmax(logits, tau=tau, hard=True)
            logp_site = (site * F.log_softmax(logits, -1)).sum(-1, keepdim=True)
        # Site-first: the continuous heads see the *chosen* site's embedding.
        chosen = (site[..., None] * e).sum(1)
        z = self.body(torch.cat([chosen, e.mean(1)], -1))
        mean, logstd = self.mean_head(z), self.logstd_head(z).clamp(-5.0, 1.0)
        normal = Normal(mean, logstd.exp())
        pre = mean if deterministic else normal.rsample()
        a = torch.tanh(pre)
        logp = (normal.log_prob(pre) - torch.log(1.0 - a.pow(2) + 1e-6)).sum(-1, keepdim=True)
        return site, a, logp_site + logp


    @torch.inference_mode()
    def act_deterministic(self, state):
        """Lean execution path: same output as sample(..., deterministic=True)
        (site argmax, tanh of the Gaussian mean) without building the
        distribution or log-probabilities.  state: (1, D)."""
        e, tokens = self.enc(state)
        if not self.opts.learn_site:
            idx = int(tokens[0, :, self.score_idx].argmax())
        else:
            logits = self.site_head(e).squeeze(-1)
            if self.opts.residual:
                logits = logits + self.opts.site_kappa * tokens[:, :, self.score_idx]
            idx = int(logits[0].argmax())
        z = self.body(torch.cat([e[:, idx], e.mean(1)], -1))
        return idx, torch.tanh(self.mean_head(z))[0]


class AEHACritic(nn.Module):
    def __init__(self, site_dim, glob_dim, n_sites, n_cont, hidden):
        super().__init__()
        self.enc = SiteEncoder(site_dim, glob_dim, n_sites, hidden)
        self.head = rx.mlp(2 * hidden + n_cont, hidden, 1)

    def forward(self, state, site, a):
        e, _ = self.enc(state)
        chosen = (site[..., None] * e).sum(1)
        return self.head(torch.cat([chosen, e.mean(1), a], -1))


class AEHASAC:
    def __init__(self, cfg, opts: AEHAOptions):
        self.cfg, self.opts = cfg, opts
        K, L = cfg.n_users, cfg.n_sites
        sd, gd = core.token_dims(cfg, opts.rho_aware)
        self.n_cont = (K if opts.learn_w else 0) + (1 if opts.learn_m and opts.power_mode != "softmax" else 0) + (
            K if opts.power_mode == "softmax" else 0
        )
        self.cmodel = None  # ConformalGainModel, fitted on the training-seed stream
        self.n_updates = 0
        self.decode_phase_bits = None  # test-time: quantization-aware decoding
        self.phi = 0.0  # test-time: fairness floor knob
        assert self.n_cont > 0, "ablation leaves no continuous action"
        self.state_dim = L * sd + gd
        score_idx = (K + 1) * K  # first "extra" slot of a token
        h = cfg.hidden
        self.actor = AEHAActor(sd, gd, L, self.n_cont, h, opts, score_idx).to(DEVICE)
        self.q1, self.q2, self.tq1, self.tq2 = (AEHACritic(sd, gd, L, self.n_cont, h).to(DEVICE) for _ in range(4))
        self.tq1.load_state_dict(self.q1.state_dict())
        self.tq2.load_state_dict(self.q2.state_dict())
        self.actor_opt = torch.optim.Adam(self.actor.parameters(), lr=cfg.lr)
        self.q_opt = torch.optim.Adam(list(self.q1.parameters()) + list(self.q2.parameters()), lr=cfg.lr)
        self.log_alpha = torch.tensor(math.log(0.05), dtype=DTYPE, device=DEVICE, requires_grad=True)
        self.alpha_opt = torch.optim.Adam([self.log_alpha], lr=cfg.lr)
        self.target_entropy = -(self.n_cont + (math.log(L) if opts.learn_site else 0.0)) * 0.25

    # --- action interpretation --------------------------------------------
    def interpret(self, a: np.ndarray, env):
        """Continuous vector in [-1,1]^n_cont -> (w, risk, power_logits).

        risk = conformal delta (log-uniform map onto [delta_min, delta_max])
        or rate margin m, depending on power_mode.
        """
        o, K, i = self.opts, self.cfg.n_users, 0
        w_agg = core.aggregate_weights(env._channels["direct_est"])
        if o.learn_w:
            u = o.w_scale * a[:K] + (np.log(w_agg) if o.residual else 0.0)
            w = np.exp(u - u.max())
            w /= w.sum()
            i = K
        else:
            w = w_agg
        if o.power_mode == "conformal":
            risk = o.delta0 if o.residual else o.fixed_delta
        else:
            risk = o.fixed_m
        pl = None
        if o.power_mode != "softmax" and o.learn_m:
            x = (float(a[i]) + 1.0) / 2.0
            if o.power_mode == "conformal" and o.residual:
                risk = o.delta0 * o.delta_span ** float(a[i])
            elif o.power_mode == "conformal":
                risk = math.exp(math.log(o.delta_min) + x * (math.log(o.delta_max) - math.log(o.delta_min)))
            else:
                risk = o.m_max * x
            i += 1
        if o.power_mode == "softmax":
            pl = a[i : i + K]
        return w, risk, pl

    def decode(self, env, site_idx, a):
        w, risk, pl = self.interpret(a, env)
        action = core.decode_action(env, site_idx, w, risk, self.opts.power_mode, pl, self.cmodel,
                                    phase_bits=self.decode_phase_bits, phi=self.phi)
        return action, w, risk

    def tokens(self, env):
        return core.site_tokens(env, self.opts.rho_aware)

    def act(self, env, deterministic=True):
        tokens, glob = self.tokens(env)
        s = core.flat_state(tokens, glob)
        if deterministic:
            site_idx, a = self.actor.act_deterministic(torch.as_tensor(s[None]))
            a = a.numpy()
            site_oh = np.eye(self.cfg.n_sites, dtype=np.float32)[site_idx]
        else:
            with torch.no_grad():
                site, a, _ = self.actor.sample(torch.as_tensor(s[None]), self.cfg.gumbel_tau, deterministic)
            site_oh = site.numpy()[0]
            a = a.numpy()[0]
            site_idx = int(site_oh.argmax())
        action, w, risk = self.decode(env, site_idx, a)
        return site_idx, action, dict(state=s, site_oh=site_oh, a=a, w=w, risk=risk)

    def update(self, batch):
        s, site, a, r, ns, done = batch
        c = self.cfg
        with torch.no_grad():
            nsite, na, nlogp = self.actor.sample(ns, c.gumbel_tau, False)
            tq = torch.minimum(self.tq1(ns, nsite, na), self.tq2(ns, nsite, na))
            y = r + c.gamma * (1.0 - done) * (tq - self.alpha.detach() * nlogp)
        qloss = F.mse_loss(self.q1(s, site, a), y) + F.mse_loss(self.q2(s, site, a), y)
        self.q_opt.zero_grad(set_to_none=True)
        qloss.backward()
        nn.utils.clip_grad_norm_(list(self.q1.parameters()) + list(self.q2.parameters()), 5.0)
        self.q_opt.step()
        self.n_updates += 1
        if self.n_updates <= self.opts.actor_delay:
            self._soft_update()
            return

        psite, pa, logp = self.actor.sample(s, c.gumbel_tau, False)
        qpi = torch.minimum(self.q1(s, psite, pa), self.q2(s, psite, pa))
        aloss = (self.alpha.detach() * logp - qpi).mean()
        self.actor_opt.zero_grad(set_to_none=True)
        aloss.backward()
        nn.utils.clip_grad_norm_(self.actor.parameters(), 5.0)
        self.actor_opt.step()

        tloss = -(self.log_alpha * (logp.detach() + self.target_entropy)).mean()
        self.alpha_opt.zero_grad(set_to_none=True)
        tloss.backward()
        self.alpha_opt.step()
        self._soft_update()

    def _soft_update(self):
        tau = self.cfg.tau
        with torch.no_grad():
            for t, src in ((self.tq1, self.q1), (self.tq2, self.q2)):
                for tp, sp in zip(t.parameters(), src.parameters()):
                    tp.mul_(1.0 - tau).add_(sp, alpha=tau)

    @property
    def alpha(self):
        return self.log_alpha.exp()


# --------------------------------------------------------------------------
# Replay with deferred (Lagrangian) reward
# --------------------------------------------------------------------------
class ConstrainedReplay:
    def __init__(self, capacity, state_dim, n_sites, action_dim):
        self.cap, self.pos, self.size = capacity, 0, 0
        self.s = np.zeros((capacity, state_dim), np.float32)
        self.ns = np.zeros((capacity, state_dim), np.float32)
        self.site = np.zeros((capacity, n_sites), np.float32)
        self.a = np.zeros((capacity, action_dim), np.float32)
        self.sum = np.zeros((capacity, 1), np.float32)
        self.viol = np.zeros((capacity, 1), np.float32)
        self.done = np.zeros((capacity, 1), np.float32)

    def add(self, s, site, a, sum_rate, viol, ns, done):
        i = self.pos
        self.s[i], self.site[i], self.a[i], self.sum[i], self.viol[i], self.ns[i], self.done[i] = (
            s, site, a, sum_rate, viol, ns, done)
        self.pos = (i + 1) % self.cap
        self.size = min(self.size + 1, self.cap)

    def sample(self, n, lam):
        idx = np.random.randint(0, self.size, size=n)
        r = (self.sum[idx] - lam * self.viol[idx]) / 20.0
        t = lambda x: torch.as_tensor(x, dtype=DTYPE, device=DEVICE)  # noqa: E731
        return t(self.s[idx]), t(self.site[idx]), t(self.a[idx]), t(r), t(self.ns[idx]), t(self.done[idx])


# --------------------------------------------------------------------------
# Training
# --------------------------------------------------------------------------
def train_aeha(cfg, seed, opts: AEHAOptions, lo: LagrangeOptions, log_every=100):
    rx.seed_everything(seed)
    agent = AEHASAC(cfg, opts)
    if opts.power_mode == "conformal":
        agent.cmodel = core.ConformalGainModel(cfg, seed)  # training-seed stream only
    rx.seed_everything(seed)
    env = rx.RISNOMAEnv(cfg, seed)
    rb = ConstrainedReplay(cfg.replay_size, agent.state_dim, cfg.n_sites, agent.n_cont)
    rho_rng = np.random.default_rng(seed + 7)  # separate stream: rho draws never perturb the others

    def new_episode():
        if opts.rho_train:
            env.cfg = replace(cfg, residual_sic=float(rho_rng.choice(opts.rho_train)))
        env.reset()

    new_episode()
    dual = DualController(lo, cfg.n_users, opts.rho_train)
    sums, viols, curve, lam_curve, risks = [], [], [], [], []
    t0 = time.perf_counter()
    for step in range(cfg.train_steps):
        # Residual agents explore around their own (heuristic-equal) initial
        # policy from step 0; uniform warm-up would discard that prior.
        if step < cfg.warmup_steps and not opts.residual:
            tokens, glob = agent.tokens(env)
            s = core.flat_state(tokens, glob)
            site_idx = int(np.random.randint(cfg.n_sites)) if opts.learn_site else int(tokens[:, (cfg.n_users + 1) * cfg.n_users].argmax())
            site_oh = np.eye(cfg.n_sites, dtype=np.float32)[site_idx]
            a = np.random.uniform(-1.0, 1.0, agent.n_cont).astype(np.float32)
            action, _, risk = agent.decode(env, site_idx, a)
        else:
            site_idx, action, aux = agent.act(env, deterministic=False)
            s, site_oh, a, risk = aux["state"], aux["site_oh"], aux["a"], aux["risk"]
        risks.append(risk)
        _, _, done, info = env.step(site_idx, action)
        viol = cfg.n_users * (1.0 - info["qos"])
        if done:
            new_episode()
        ntok, nglob = agent.tokens(env)
        rb.add(s, site_oh, a, info["sum_rate"], viol, core.flat_state(ntok, nglob), float(done))
        dual.on_step(viol)
        dual.maybe_validate(step, cfg, seed, aeha_policy(agent))
        sums.append(info["sum_rate"])
        viols.append(viol)
        if rb.size >= cfg.batch_size and step >= cfg.warmup_steps:
            agent.update(rb.sample(cfg.batch_size, dual.lam))
        if (step + 1) % log_every == 0:
            curve.append(float(np.mean(sums[-log_every:])))
            lam_curve.append(dual.lam)
    return agent, dict(seed=seed, training_seconds=time.perf_counter() - t0, sum_rate_curve=curve,
                       lambda_curve=lam_curve, final_lambda=dual.lam, dual_history=dual.history,
                       train_viol_frac_last500=float(np.mean(viols[-500:]) / cfg.n_users),
                       risk_median_last500=float(np.median(risks[-500:])))


def train_published(cfg, seed, algo, log_every=100):
    """Exact replica of rx.train_sac / rx.train_ddpg (same seeding, same RNG
    call order, same scalar reward) that additionally records per-step
    sum-rate and violations for convergence plots."""
    if algo == "sac":
        rx.seed_everything(seed)
        env = rx.RISNOMAEnv(cfg, seed)
        agent = rx.HybridSAC(env, cfg)
    else:
        rx.seed_everything(seed + 50_000)
        env = rx.RISNOMAEnv(cfg, seed + 50_000)
        agent = rx.HybridDDPG(env, cfg)
    rb = rx.ReplayBuffer(cfg.replay_size, env.state_dim, env.action_dim, cfg.n_sites)
    state = env.reset()
    rewards, sums, viols = [], [], []
    rcurve, scurve, vcurve = [], [], []
    t0 = time.perf_counter()
    for step in range(cfg.train_steps):
        if step < cfg.warmup_steps:
            site_idx = int(np.random.randint(cfg.n_sites))
            site_onehot = np.eye(cfg.n_sites, dtype=np.float32)[site_idx]
            action = np.random.uniform(-1.0, 1.0, env.action_dim).astype(np.float32)
        elif algo == "sac":
            site_idx, action, site_onehot = agent.act(state, deterministic=False)
        else:
            site_idx, action, site_onehot = agent.act(
                state, deterministic=False, noise_std=max(0.03, 0.15 * (1.0 - step / cfg.train_steps)))
        next_state, reward, done, info = env.step(site_idx, action)
        rb.add(state, site_onehot, action, reward / 20.0, next_state, float(done))
        state = env.reset() if done else next_state
        rewards.append(reward)
        sums.append(info["sum_rate"])
        viols.append(cfg.n_users * (1.0 - info["qos"]))
        if rb.size >= cfg.batch_size and step >= cfg.warmup_steps:
            agent.update(rb.sample(cfg.batch_size))
        if (step + 1) % log_every == 0:
            rcurve.append(float(np.mean(rewards[-log_every:])))
            scurve.append(float(np.mean(sums[-log_every:])))
            vcurve.append(float(np.mean(viols[-log_every:]) / cfg.n_users))
    return agent, dict(seed=seed, training_seconds=time.perf_counter() - t0, reward_curve=rcurve,
                       sum_rate_curve=scurve, viol_curve=vcurve)


def convergence_step(curve, log_every=100):
    """Baseline paper's rule: first 5-window block whose mean reaches 95% of the
    final 5-window mean (curve = per-100-step rolling means)."""
    if not curve or len(curve) < 5:
        return float("nan")
    final = float(np.mean(curve[-5:]))
    for i in range(len(curve) - 4):
        if np.mean(curve[i:i + 5]) >= 0.95 * final:
            return (i + 5) * log_every
    return len(curve) * log_every


def train_hybrid_sac_constrained(cfg, seed, lo: LagrangeOptions, log_every=100):
    """Published Hybrid-SAC actor/critic, trained on the same constrained objective."""
    rx.seed_everything(seed)
    env = rx.RISNOMAEnv(cfg, seed)
    agent = rx.HybridSAC(env, cfg)
    rb = ConstrainedReplay(cfg.replay_size, env.state_dim, cfg.n_sites, env.action_dim)
    state = env.reset()
    dual = DualController(lo, cfg.n_users)
    sums, curve = [], []
    t0 = time.perf_counter()
    for step in range(cfg.train_steps):
        if step < cfg.warmup_steps:
            site_idx = int(np.random.randint(cfg.n_sites))
            site_oh = np.eye(cfg.n_sites, dtype=np.float32)[site_idx]
            action = np.random.uniform(-1.0, 1.0, env.action_dim).astype(np.float32)
        else:
            site_idx, action, site_oh = agent.act(state, deterministic=False)
        nstate, _, done, info = env.step(site_idx, action)
        viol = cfg.n_users * (1.0 - info["qos"])
        rb.add(state, site_oh, action, info["sum_rate"], viol, nstate, float(done))
        state = env.reset() if done else nstate
        dual.on_step(viol)
        dual.maybe_validate(step, cfg, seed, sac_policy(agent))
        sums.append(info["sum_rate"])
        if rb.size >= cfg.batch_size and step >= cfg.warmup_steps:
            agent.update(rb.sample(cfg.batch_size, dual.lam))
        if (step + 1) % log_every == 0:
            curve.append(float(np.mean(sums[-log_every:])))
    return agent, dict(seed=seed, training_seconds=time.perf_counter() - t0, sum_rate_curve=curve,
                       final_lambda=dual.lam, dual_history=dual.history)


# --------------------------------------------------------------------------
# Evaluation (mirrors rx.evaluate_policy; policy gets the env)
# --------------------------------------------------------------------------
def evaluate(cfg, seed, policy: Callable, phase_bits=None, include_pilot=True, residual_sic=None, env_seed=None):
    env = rx.RISNOMAEnv(cfg, seed + 100_000 if env_seed is None else env_seed)
    env.reset()
    sums, fairs, qos, lat, loop = [], [], [], [], []
    handovers, prev = 0, None
    for _ in range(cfg.eval_steps):
        t0 = time.perf_counter_ns()
        site, action = policy(env)
        t1 = time.perf_counter_ns()
        lat.append((t1 - t0) / 1e6)
        if prev is not None and site != prev:
            handovers += 1
        prev = site
        _, _, done, info = env.step(site, action, phase_bits=phase_bits, include_pilot=include_pilot,
                                    residual_sic=residual_sic)
        loop.append((time.perf_counter_ns() - t0) / 1e6)
        sums.append(info["sum_rate"])
        fairs.append(info["fairness"])
        qos.append(info["qos"])
        if done:
            env.reset()
    arr = np.asarray(sums)
    return dict(
        sum_rate_mean=float(arr.mean()),
        sum_rate_p05=float(np.quantile(arr, 0.05)),
        fairness=float(np.mean(fairs)),
        qos_percent=100.0 * float(np.mean(qos)),
        inference_ms_median=float(np.median(lat)),
        inference_ms_p95=float(np.quantile(lat, 0.95)),
        software_loop_ms_median=float(np.median(loop)),
        software_loop_ms_p95=float(np.quantile(loop, 0.95)),
        handover_percent=100.0 * handovers / max(1, cfg.eval_steps - 1),
    )


def evaluate_geometries(cfg, seed, policy, n_envs=200, steps=20, **eval_kw):
    """Reliable supplementary metric: n_envs independent geometries x steps.

    The manuscript's 500-step stream spans only ~3 geometries (mobility period
    100 steps, episode 200 steps), which is too few to verify a 1% QoS target.
    Env seeds seed + 200000 + 1000 k are disjoint from all other streams.
    """
    c = replace(cfg, eval_steps=steps)
    ms = [evaluate(c, seed, policy, env_seed=seed + 200_000 + 1000 * k, **eval_kw) for k in range(n_envs)]
    return dict(sum_rate_geo=float(np.mean([m["sum_rate_mean"] for m in ms])),
                qos_geo=float(np.mean([m["qos_percent"] for m in ms])),
                fairness_geo=float(np.mean([m["fairness"] for m in ms])))


def heuristic_policy(name):
    return lambda env: env.heuristic_action(name)


def agg_target_policy(env):
    """Simulator's own weighted target phase + heuristic power (unreported baseline)."""
    ch = env._channels
    site = int(np.argmax(ch["site_score"]))
    _, ref = env.heuristic_action("decoupled")  # reuse its power logits
    phase = ch["target_phase"][site].astype(np.float64) / math.pi - 1.0
    return site, np.concatenate([phase, ref[env.cfg.n_ris :]])


def mrr_floor_policy(risk, cmodel=None):
    """MRR site/anchor (w = strongest direct-link user) + conformal QoS floor."""
    def pol(env):
        ch = env._channels
        k = int(np.argmax(np.abs(ch["direct_est"])))
        site, _ = env.heuristic_action("decoupled")
        w = np.eye(env.cfg.n_users)[k]
        return site, core.decode_action(env, site, w, risk, "conformal", None, cmodel)
    return pol


def agg_floor_policy(risk, power_mode="conformal", cmodel=None, phase_bits=None, phi=0.0):
    """Non-learned physics-layer baseline: aggregate anchor + floor power at a fixed risk."""
    def pol(env):
        ch = env._channels
        site = int(np.argmax(ch["site_score"]))
        w = core.aggregate_weights(ch["direct_est"])
        return site, core.decode_action(env, site, w, risk, power_mode, None, cmodel, phase_bits=phase_bits, phi=phi)
    return pol


def sac_policy(agent):
    def pol(env):
        site, action, _ = agent.act(env._state(), deterministic=True)
        return site, action
    return pol


def aeha_policy(agent):
    def pol(env):
        site, action, _ = agent.act(env, deterministic=True)
        return site, action
    return pol


# --------------------------------------------------------------------------
# Suite
# --------------------------------------------------------------------------
AEHA_VARIANTS = {
    "AEHA-SAC": AEHAOptions(),
    "AEHA-fixed-delta": AEHAOptions(learn_m=False),  # delta fixed at 0.01
    "AEHA-margin-floor": AEHAOptions(power_mode="floor"),  # rate-margin floor, learned m
    "AEHA-no-adaptive-w": AEHAOptions(learn_w=False),
    "AEHA-softmax-power": AEHAOptions(power_mode="softmax", learn_m=False),
    "AEHA-no-pointer": AEHAOptions(learn_site=False),
    # Residual family (actor initialised exactly at Agg-conf-d0.01)
    "AEHA-res": AEHAOptions(residual=True, actor_delay=1000),
    "AEHA-res-no-delay": AEHAOptions(residual=True, actor_delay=0),
    "AEHA-res-fixed-delta": AEHAOptions(residual=True, actor_delay=1000, learn_m=False),
    "AEHA-res-fixed-w": AEHAOptions(residual=True, actor_delay=1000, learn_w=False),
    "AEHA-res-no-pointer": AEHAOptions(residual=True, actor_delay=1000, learn_site=False),
    # Final-comparison ablations of the main method (AEHA-res-fixed-delta)
    "AEHA-main-no-pointer": AEHAOptions(residual=True, actor_delay=1000, learn_m=False, learn_site=False),
    "AEHA-main-margin-floor": AEHAOptions(residual=True, actor_delay=1000, learn_m=False, power_mode="floor", fixed_m=1.0),
    # rho-aware main method: one policy for the whole residual-SIC range
    "AEHA-rho-aware": AEHAOptions(residual=True, actor_delay=1000, learn_m=False, rho_aware=True,
                                  rho_train=(0.0, 0.02, 0.04, 0.08, 0.15)),
}


def mean_ci(v):
    v = np.asarray(v, float)
    if len(v) < 2:
        return float(v.mean()), 0.0
    return float(v.mean()), float(stats.t.ppf(0.975, len(v) - 1) * v.std(ddof=1) / math.sqrt(len(v)))


def run(profile, seeds, methods, outdir: Path, gamma: Optional[float], train_steps: Optional[int] = None,
        overrides: Optional[Dict] = None):
    cfg = rx.Config(**rx.PROFILES[profile])
    if gamma is not None:
        cfg = replace(cfg, gamma=gamma)
    if train_steps is not None:
        cfg = replace(cfg, train_steps=train_steps)
    if overrides:
        cfg = replace(cfg, **overrides)
    lo = LagrangeOptions()
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "models").mkdir(exist_ok=True)
    rows, logs = [], []
    for seed in seeds:
        for name in methods:
            extra = dict(training_seconds=0.0, model_parameters=0)
            if name == "Decoupled-MRR":
                pol = heuristic_policy("decoupled")
            elif name == "Fixed-site":
                pol = heuristic_policy("fixed_site")
            elif name == "Agg-target":
                pol = agg_target_policy
            elif name.startswith("Agg-floor-m"):
                pol = agg_floor_policy(float(name.split("-m")[1]), "floor")
            elif name.startswith("MRR-conf-d"):
                pol = mrr_floor_policy(float(name.split("-d")[1]), core.ConformalGainModel(cfg, seed))
            elif name.startswith("Agg-conf-d"):
                pol = agg_floor_policy(float(name.split("-d")[1]), "conformal", core.ConformalGainModel(cfg, seed))
            elif name in ("Hybrid-SAC", "DDPG-Hybrid"):  # published objective and settings
                agent, log = train_published(cfg, seed, "sac" if name == "Hybrid-SAC" else "ddpg")
                pol = sac_policy(agent)  # both expose act(state, deterministic) -> (site, action, onehot)
                extra = dict(training_seconds=log["training_seconds"],
                             model_parameters=sum(p.numel() for p in agent.actor.parameters()),
                             convergence_steps=convergence_step(log["sum_rate_curve"]))
                logs.append(dict(method=name, **log))
                torch.save(agent.actor.state_dict(), outdir / "models" / f"{name}_seed{seed}.pt")
            elif name == "Hybrid-SAC-Lagr":
                agent, log = train_hybrid_sac_constrained(cfg, seed, lo)
                pol = sac_policy(agent)
                extra = dict(training_seconds=log["training_seconds"],
                             model_parameters=sum(p.numel() for p in agent.actor.parameters()),
                             convergence_steps=convergence_step(log["sum_rate_curve"]))
                logs.append(dict(method=name, **log))
                torch.save(agent.actor.state_dict(), outdir / "models" / f"{name}_seed{seed}.pt")
            elif name in AEHA_VARIANTS:
                agent, log = train_aeha(cfg, seed, AEHA_VARIANTS[name], lo)
                pol = aeha_policy(agent)
                extra = dict(training_seconds=log["training_seconds"],
                             model_parameters=sum(p.numel() for p in agent.actor.parameters()),
                             convergence_steps=convergence_step(log["sum_rate_curve"]))
                logs.append(dict(method=name, **log))
                torch.save(agent.actor.state_dict(), outdir / "models" / f"{name}_seed{seed}.pt")
            else:
                raise ValueError(name)
            m = evaluate(cfg, seed, pol)
            m.update(evaluate_geometries(cfg, seed, pol))
            rows.append(dict(method=name, seed=seed, n_sites=cfg.n_sites, **extra, **m))
            print(f"seed {seed} {name:22s} sum {m['sum_rate_mean']:6.3f}  QoS {m['qos_percent']:6.2f}  "
                  f"| geo sum {m['sum_rate_geo']:6.3f} QoS {m['qos_geo']:6.2f}  "
                  f"Jain {m['fairness']:.3f}  inf {m['inference_ms_median']:.3f} ms", flush=True)
    raw = pd.DataFrame(rows)
    here = Path(__file__).resolve().parent
    manifest = dict(
        profile=profile, seeds=list(seeds), methods=list(methods), config=asdict(cfg),
        lagrange=asdict(lo), variants={k: asdict(v) for k, v in AEHA_VARIANTS.items()},
        python=platform.python_version(), torch=torch.__version__, numpy=np.__version__, platform=platform.platform(),
        sha256={f: hashlib.sha256((here / f).read_bytes()).hexdigest() for f in ("aeha.py", "aeha_core.py")},
        simulator_sha256=hashlib.sha256((core.REPO / "ris_noma_experiments.py").read_bytes()).hexdigest(),
        training_logs=logs,
    )
    (outdir / "run_manifest.json").write_text(json.dumps(manifest, indent=2, default=float), encoding="utf-8")
    summarize(raw, outdir)
    return raw


def summarize(raw: pd.DataFrame, outdir: Path):
    methods = list(dict.fromkeys(raw.method))
    raw.to_csv(outdir / "metrics_raw.csv", index=False)
    geo = [k for k in ("sum_rate_geo", "qos_geo", "fairness_geo") if k in raw]
    keys = ["sum_rate_mean", "sum_rate_p05", "fairness", "qos_percent", "inference_ms_median", "inference_ms_p95",
            "software_loop_ms_median", "software_loop_ms_p95", "handover_percent", "training_seconds",
            "model_parameters"] + geo + (["convergence_steps"] if "convergence_steps" in raw else [])
    summ = []
    for name, g in raw.groupby("method", sort=False):
        row = dict(method=name, n_seeds=len(g))
        for k in keys:
            vals = g[k].dropna()
            row[k], row[k + "_ci95"] = mean_ci(vals) if len(vals) else (float("nan"), float("nan"))
        summ.append(row)
    pd.DataFrame(summ).to_csv(outdir / "metrics_summary.csv", index=False)

    paired = []
    for ref in ("Decoupled-MRR", "Agg-target", "Agg-conf-d0.01", "Hybrid-SAC", "DDPG-Hybrid", "Hybrid-SAC-Lagr"):
        if ref not in methods:
            continue
        base = raw[raw.method == ref].set_index("seed")
        for name in methods:
            if name == ref:
                continue
            cur = raw[raw.method == name].set_index("seed")
            for k in ["sum_rate_mean", "qos_percent", "fairness"] + geo:
                d = (cur[k] - base[k]).dropna().values
                mu, ci = mean_ci(d)
                p = float(stats.ttest_1samp(d, 0.0).pvalue) if len(d) > 1 else float("nan")
                paired.append(dict(method=name, comparator=ref, metric=k, n_pairs=len(d), diff_mean=mu, diff_ci95=ci, p_value=p))
    pd.DataFrame(paired).to_csv(outdir / "paired_comparisons.csv", index=False)
    pd.set_option("display.width", 200)
    cols = ["method", "n_seeds", "sum_rate_mean", "sum_rate_mean_ci95", "qos_percent", "qos_percent_ci95", "fairness",
            "inference_ms_median", "model_parameters"] + [k for k in ("sum_rate_geo", "qos_geo") if k in geo]
    print(pd.DataFrame(summ)[cols].round(3).to_string(index=False))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default="quick")
    ap.add_argument("--seeds", default="11,22,33,44,55")
    ap.add_argument("--methods", default="Decoupled-MRR,Fixed-site,Agg-target,Agg-conf-d0.01,Hybrid-SAC,Hybrid-SAC-Lagr,AEHA-SAC")
    ap.add_argument("--gamma", type=float, default=None, help="override discount (default: profile value 0.99)")
    ap.add_argument("--outdir", default="results_aeha")
    ap.add_argument("--merge", default=None, help="comma-separated result dirs to merge into --outdir")
    ap.add_argument("--train-steps", type=int, default=None, help="override profile train_steps (eval protocol unchanged)")
    ap.add_argument("--n-sites", type=int, default=None)
    ap.add_argument("--n-ris", type=int, default=None)
    ap.add_argument("--n-vehicles", type=int, default=None)
    ap.add_argument("--residual-sic", type=float, default=None)
    a = ap.parse_args()
    base = Path(__file__).resolve().parent
    if a.merge:
        out = base / a.outdir
        out.mkdir(parents=True, exist_ok=True)
        raw = pd.concat([pd.read_csv(base / d / "metrics_raw.csv") for d in a.merge.split(",")], ignore_index=True)
        summarize(raw, out)
        return
    run(a.profile, [int(s) for s in a.seeds.split(",")], a.methods.split(","),
        Path(__file__).resolve().parent / a.outdir, a.gamma, a.train_steps,
        {k: v for k, v in dict(n_sites=a.n_sites, n_ris=a.n_ris, n_vehicles=a.n_vehicles,
                               residual_sic=a.residual_sic).items() if v is not None})


if __name__ == "__main__":
    main()
