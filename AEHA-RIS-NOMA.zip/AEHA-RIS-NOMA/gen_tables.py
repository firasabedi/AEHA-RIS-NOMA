"""Generate every results table of the manuscript directly from the result CSVs
and splice them into sn-article.tex between %%BEGIN-AUTO:<name> / %%END-AUTO:<name>.

No number in an auto table is typed by hand.  Cells are mean over seeds; the
violation rate is 100 - QoS on the 200-geometry metric (lower is better,
target <= 1%).
"""

import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

HERE = Path(__file__).resolve().parent
TEX = HERE / "manuscript" / "sn-article.tex"
INTERNAL = {"AEHA-res-fixed-delta": "AEHA", "Agg-conf-d0.01": "Physics layer", "Agg-target": "Weighted target",
            "Hybrid-SAC-Lagr": "Hybrid-SAC (constrained)"}
ORDER = ["AEHA", "Hybrid-SAC", "DDPG-Hybrid", "Hybrid-SAC (constrained)", "Physics layer", "Weighted target",
         "Decoupled-MRR", "Fixed-site"]
SEEDS5 = (11, 22, 33, 44, 55)


def ci(v):
    v = np.asarray(v, float)
    v = v[np.isfinite(v)]
    return float(stats.t.ppf(0.975, len(v) - 1) * v.std(ddof=1) / np.sqrt(len(v))) if len(v) > 1 else float("nan")


def prep(df):
    df = df.copy()
    df["method"] = df["method"].map(lambda m: INTERNAL.get(m, m))
    df["viol_geo"] = 100.0 - df["qos_geo"]
    return df


def holm(ps):
    """Holm step-down adjusted p-values (same order as input)."""
    ps = np.asarray(ps, float)
    order = np.argsort(ps)
    adj = np.empty_like(ps)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (len(ps) - rank) * ps[i]))
        adj[i] = running
    return adj


def fmtp(p):
    return f"{p:.1e}" if p < 0.001 else f"{p:.3f}"


def pm(v, d=2):
    return f"${np.mean(v):.{d}f}\\pm{ci(v):.{d}f}$"


def cell(g, bold=False):
    """rate (violations %) cell."""
    if not len(g):
        return "--"
    s = f"{g.sum_rate_geo.mean():.2f} ({g.viol_geo.mean():.2f})"
    return f"\\textbf{{{s}}}" if bold else s


def table(name, caption, colspec, header, rows, star=True, note=None, size="\\footnotesize"):
    env = "table*" if star else "table"
    width = "\\textwidth" if star else "\\linewidth"
    out = [f"\\begin{{{env}}}[t]", "\\centering", f"\\caption{{{caption}}}", f"\\label{{tab:{name}}}",
           f"{{{size}\\begin{{adjustbox}}{{max width={width}}}", f"\\begin{{tabular}}{{{colspec}}}", "\\toprule",
           header + "\\\\", "\\midrule"]
    out += [r + "\\\\" for r in rows]
    out += ["\\bottomrule", "\\end{tabular}\\end{adjustbox}}"]
    if note:
        out.append(f"\\par\\smallskip{{\\scriptsize {note}}}")
    out.append(f"\\end{{{env}}}")
    return "\n".join(out)


T = {}
main = prep(pd.read_csv(HERE / "results_final" / "merged_all" / "metrics_raw.csv"))
scen = prep(pd.read_csv(HERE / "results_scen_eval" / "merged" / "scen_raw.csv"))

# ---------------------------------------------------------------- main
rows = []
for m in ORDER:
    g = main[main.method == m]
    b = m == "AEHA"
    name = f"\\textbf{{{m}}}" if b else m
    params = f"{int(g.model_parameters.mean()):,}".replace(",", "{,}") if g.model_parameters.mean() > 0 else "--"
    train = f"{g.training_seconds.mean():.0f}" if g.training_seconds.mean() > 0 else "--"
    rows.append(" & ".join([name, pm(g.sum_rate_geo), pm(g.qos_geo), pm(g.fairness_geo, 3),
                            f"{int((g.qos_geo >= 99).sum())}/{len(g)}", pm(g.sum_rate_mean), pm(g.qos_percent),
                            params, train]))
T["main"] = table(
    "main", "Main comparison at the baseline profile ($L=3$, $N_r=64$, $K=10$, $\\rho=0.08$; ten paired seeds; "
            "mean $\\pm$ Student-$t$ 95\\% half-width). ``Seeds'' counts seeds with 200-geometry QoS $\\ge99$\\%.",
    "@{}lcccccccc@{}",
    "& \\multicolumn{4}{c}{\\textbf{200-geometry (primary)}} & \\multicolumn{2}{c}{\\textbf{500-interval}} & & \\\\"
    "\\cmidrule(lr){2-5}\\cmidrule(lr){6-7}\n\\textbf{Method} & \\textbf{Rate (Mbps)} & \\textbf{QoS (\\%)} & "
    "\\textbf{Jain} & \\textbf{Seeds} & \\textbf{Rate (Mbps)} & \\textbf{QoS (\\%)} & \\textbf{Actor params} & "
    "\\textbf{Train (s)}", rows)

# ---------------------------------------------------------------- paired vs AEHA (main)
a = main[main.method == "AEHA"].set_index("seed")
metrics3 = (("sum_rate_geo", 2), ("qos_geo", 2), ("fairness_geo", 3))
diffs = {m: {k: (a[k] - main[main.method == m].set_index("seed")[k]).dropna() for k, _ in metrics3} for m in ORDER[1:]}
padj = {k: dict(zip(ORDER[1:], holm([stats.ttest_1samp(diffs[m][k], 0).pvalue for m in ORDER[1:]])))
        for k, _ in metrics3}
rows = []
for m in ORDER[1:]:
    r = [m]
    for k, dgt in metrics3:
        d = diffs[m][k]
        r.append(f"${d.mean():+.{dgt}f}\\pm{ci(d):.{dgt}f}$")
        r.append(fmtp(padj[k][m]))
    rows.append(" & ".join(r))
T["paired"] = table(
    "paired", "AEHA minus comparator, paired over ten seeds (200-geometry metric). $p$: two-sided paired $t$-test, "
              "Holm-adjusted across the seven comparators within each metric.",
    "@{}lcccccc@{}",
    "\\textbf{Comparator} & $\\Delta$\\textbf{Rate (Mbps)} & $p$ & $\\Delta$\\textbf{QoS (pts)} & $p$ & "
    "$\\Delta$\\textbf{Jain} & $p$", rows)

# ---------------------------------------------------------------- ablations (main-profile ablation variants)
abl = [("No learning (physics layer)", "Physics layer"), ("Rate-margin floor", "AEHA-main-margin-floor"),
       ("Random initialization", "AEHA-fixed-delta"), ("Learned risk $\\delta$", "AEHA-res"),
       ("No site pointer ($L=3$)", "AEHA-main-no-pointer")]
rows = []
adiff = {lab: {k: (a[k] - main[main.method == m].set_index("seed")[k]).dropna() for k in ("sum_rate_geo", "qos_geo")}
         for lab, m in abl}
aadj = {k: dict(zip([l for l, _ in abl], holm([stats.ttest_1samp(adiff[l][k], 0).pvalue for l, _ in abl])))
        for k in ("sum_rate_geo", "qos_geo")}
for lab, m in abl:
    b = main[main.method == m].set_index("seed")
    r = [lab]
    for k in ("sum_rate_geo", "qos_geo"):
        d = adiff[lab][k]
        r.append(f"${d.mean():+.2f}\\pm{ci(d):.2f}$ ({fmtp(aadj[k][lab])})")
    r.append(f"{int((b.qos_geo >= 99).sum())}/{len(b)}")
    rows.append(" & ".join(r))
T["ablation"] = table(
    "ablation", "Ablations: AEHA minus ablated variant (200-geometry, ten paired seeds; paired $t$-test $p$, "
                "Holm-adjusted across the five ablations within each metric). "
                "The last column counts seeds on which the \\emph{ablated} variant meets the 1\\% target (AEHA: 8/10).",
    "@{}lccc@{}", "\\textbf{Ablated element} & $\\Delta$\\textbf{Rate (Mbps)} & $\\Delta$\\textbf{QoS (pts)} & "
                  "\\textbf{Seeds}", rows, star=False)


# ---------------------------------------------------------------- scenario grids (rate (viol))
def grid(name, caption, settings, labels, methods, extra_rows=None, note=None):
    rows = []
    for m in methods:
        r = [f"\\textbf{{{m}}}" if m == "AEHA" else m]
        for st in settings:
            g = scen[(scen.setting == st) & (scen.method == m)]
            r.append(cell(g, bold=m == "AEHA"))
        rows.append(" & ".join(r))
    T[name] = table(name, caption, "@{}l" + "c" * len(settings) + "@{}",
                    "\\textbf{Method} & " + " & ".join(f"\\textbf{{{x}}}" for x in labels), rows, note=note)


CELLNOTE = "Cells: net sum-rate in Mbps (rate-target violations in \\% of user-intervals; target $\\le1$\\%), 200-geometry metric, ten seeds."
grid("quant", "Phase-resolution sensitivity (same trained policies, no retraining).", ["base", "2-bit", "1-bit"],
     ["Continuous", "2-bit", "1-bit"], ["AEHA", "AEHA (quant-aware)"] + ORDER[1:], note=CELLNOTE)
grid("impair", "Impairment accounting: the same executed actions evaluated without pilot overhead and with perfect "
               "SIC (ideal), with pilot overhead and perfect SIC (pilot only), and with both (baseline).",
     ["ideal", "pilot-only", "base"], ["Ideal", "Pilot only", "Pilot + residual SIC"], ORDER, note=CELLNOTE)
rho_sets = ["rho=0", "rho=0.01", "rho=0.02", "rho=0.04", "rho=0.06", "base", "rho=0.11", "rho=0.15"]
grid("rho", "Residual-SIC sweep (the controller knows $\\rho$; learned policies trained at $\\rho=0.08$ except the "
            "$\\rho$-aware AEHA). $^\\dagger$Not used to train the $\\rho$-aware policy. $\\rho$-aware results use "
            "seeds 11--55.", rho_sets,
     ["$\\rho=0$", "0.01$^\\dagger$", "0.02", "0.04", "0.06$^\\dagger$", "0.08", "0.11$^\\dagger$", "0.15"],
     ["AEHA", "AEHA (rho-aware)"] + ORDER[1:], note=CELLNOTE)
grid("csi", "CSI-error sensitivity (policies trained at $\\sigma_e^2=0.05$; conformal bins refitted).",
     ["csi=0.02", "base", "csi=0.1"], ["$\\sigma_e^2=0.02$", "0.05 (training)", "0.10"], ORDER, note=CELLNOTE)


# ---------------------------------------------------------------- size scaling (trained per size, 5 seeds)
def size_table(name, caption, tags, labels):
    rows = []
    for m in ORDER + ["AEHA (zero-shot)"]:
        r = [f"\\textbf{{{m}}}" if m == "AEHA" else m]
        for tag in tags:
            if m == "AEHA (zero-shot)":
                st = {"L20": "L=20", "L50": "L=50", "K20": "K=20", "K50": "K=50", "N32": "N=32", "N128": "N=128"}.get(tag, "base")
                g = scen[(scen.setting == st) & (scen.method == "AEHA") & (scen.seed.isin(SEEDS5))]
            elif tag is None:
                g = main[(main.method == m) & (main.seed.isin(SEEDS5))]
            else:
                d = prep(pd.read_csv(HERE / "results_scen" / f"{tag}_merged" / "metrics_raw.csv"))
                g = d[d.method == m]
            r.append(cell(g, bold=m == "AEHA"))
        rows.append(" & ".join(r))
    T[name] = table(name, caption, "@{}l" + "c" * len(tags) + "@{}",
                    "\\textbf{Method} & " + " & ".join(f"\\textbf{{{x}}}" for x in labels), rows,
                    note="Cells: net sum-rate in Mbps (rate-target violations in \\%), 200-geometry metric, seeds "
                         "11--55; every learned method is retrained at each size, except ``AEHA (zero-shot)'', which "
                         "executes the $L=3$, $N_r=64$, $K=10$ policy unchanged.")


size_table("sites", "Candidate-site scaling.", [None, "L20", "L50"], ["$L=3$", "$L=20$", "$L=50$"])
size_table("vehicles", "Vehicle-pool scaling ($U=3$ scheduled users).", [None, "K20", "K50"],
           ["$K=10$", "$K=20$", "$K=50$"])
size_table("elements", "RIS-element scaling (pilot overhead $\\tau_{\\rm CSI}=8+N_r/2$ grows with $N_r$).",
           ["N32", None, "N128"], ["$N_r=32$", "$N_r=64$", "$N_r=128$"])


# ---------------------------------------------------------------- convergence + training cost per L
def conv_step(curve, every=100):
    if not curve or len(curve) < 5:
        return np.nan
    final = np.mean(curve[-5:])
    for i in range(len(curve) - 4):
        if np.mean(curve[i:i + 5]) >= 0.95 * final:
            return (i + 5) * every
    return len(curve) * every


rows = []
learned = ["AEHA", "Hybrid-SAC", "DDPG-Hybrid", "Hybrid-SAC (constrained)"]
for m in learned:
    r = [f"\\textbf{{{m}}}" if m == "AEHA" else m]
    for tag in (None, "L20", "L50"):
        cs, ts = [], []
        for s in SEEDS5:
            for d in ("B", "P"):
                path = (HERE / "results_final" / f"{d}_seed{s}") if tag is None else (HERE / "results_scen" / f"{tag}_{d}_seed{s}")
                for lg in json.loads((path / "run_manifest.json").read_text(encoding="utf-8"))["training_logs"]:
                    if INTERNAL.get(lg["method"], lg["method"]) == m and "sum_rate_curve" in lg:
                        cs.append(conv_step(lg["sum_rate_curve"]))
                        ts.append(lg["training_seconds"])
        r.append(f"{np.mean(cs):.0f} / {np.mean(ts):.0f}")
    rows.append(" & ".join(r))
T["conv"] = table("conv", "Training convergence step (first five-window block reaching 95\\% of the final training "
                          "sum-rate; the baseline study's definition) and training time in seconds, mean of seeds 11--55. "
                          "AEHA and Hybrid-SAC (constrained) train for 8000 steps including validation, the published "
                          "learners for 3000. Training times were measured with six runs sharing the CPU and are indicative "
                          "only.", "@{}lccc@{}",
                  "\\textbf{Method} & $L=3$ & $L=20$ & $L=50$", rows, star=False)

# ---------------------------------------------------------------- timing
t = pd.read_csv(HERE / "results_timing_all.csv")
rows = []
for m in ORDER:
    r = [f"\\textbf{{{m}}}" if m == "AEHA" else m]
    for L in (3, 20, 50):
        g = t[(t.method == m) & (t.L == L)].iloc[0]
        r.append(f"{g.decision_median:.2f} / {g.decision_p95:.2f}")
        r.append(f"{g.loop_median:.2f} / {g.loop_p95:.2f}")
    rows.append(" & ".join(r))
T["timing"] = table("timing", "Computation time, median / p95 in ms (single process, one PyTorch thread, Intel Core "
                              "i7-13650HX, 1400 intervals). Decision: observation/feature construction and action "
                              "(including AEHA's anchor and floor). Loop: decision plus the simulator step. The published "
                              "learners' phase-target features are computed inside the simulator step, so their decision "
                              "time excludes that work.", "@{}lcccccc@{}",
                    "& \\multicolumn{2}{c}{$L=3$} & \\multicolumn{2}{c}{$L=20$} & \\multicolumn{2}{c}{$L=50$}\\\\"
                    "\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}\n\\textbf{Method} & Decision & Loop & "
                    "Decision & Loop & Decision & Loop", rows)

# ---------------------------------------------------------------- splice
if not TEX.exists():  # released code package: no manuscript, write standalone tables
    out = HERE / "tables"
    out.mkdir(exist_ok=True)
    for name, body in T.items():
        (out / f"{name}.tex").write_text(body + "\n", encoding="utf-8")
    print("tables written to", out, ":", ", ".join(T))
    raise SystemExit
tex = TEX.read_text(encoding="utf-8")
for name, body in T.items():
    pat = re.compile(rf"%%BEGIN-AUTO:{name}\n.*?%%END-AUTO:{name}", re.S)
    if not pat.search(tex):
        print("marker missing:", name)
        continue
    tex = pat.sub(lambda _: f"%%BEGIN-AUTO:{name}\n{body}\n%%END-AUTO:{name}", tex)
TEX.write_text(tex, encoding="utf-8")
print("tables generated:", ", ".join(T))
