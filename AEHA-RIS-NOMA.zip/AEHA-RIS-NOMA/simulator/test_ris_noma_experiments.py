"""Deterministic checks for the clean-room RIS--NOMA simulator."""

import math
import unittest

import numpy as np

from ris_noma_experiments import Config, RISNOMAEnv


class EnvironmentContractTests(unittest.TestCase):
    def setUp(self):
        self.cfg = Config(n_ris=8, n_sites=3, n_vehicles=10, n_users=3)
        self.env = RISNOMAEnv(self.cfg, seed=123)
        self.site, self.action = self.env.heuristic_action("decoupled")

    def test_state_and_action_dimensions(self):
        expected = (
            2 * self.cfg.n_vehicles
            + self.cfg.n_users
            + self.cfg.n_sites
            + 2 * self.cfg.n_sites * self.cfg.n_ris
            + self.cfg.n_sites
        )
        self.assertEqual(self.env.state_dim, expected)
        self.assertEqual(self.env.action_dim, self.cfg.n_ris + self.cfg.n_users)
        self.assertEqual(self.env._state().shape, (expected,))

    def test_power_simplex_and_phase_quantization(self):
        one_bit = self.env.evaluate_action(self.site, self.action, phase_bits=1)
        two_bit = self.env.evaluate_action(self.site, self.action, phase_bits=2)
        self.assertAlmostEqual(float(one_bit["powers"].sum()), self.cfg.p_max, places=12)
        self.assertLessEqual(len(np.unique(np.round(one_bit["phases"], 12))), 2)
        self.assertLessEqual(len(np.unique(np.round(two_bit["phases"], 12))), 4)
        self.assertTrue(np.all(one_bit["phases"] >= 0.0))
        self.assertTrue(np.all(one_bit["phases"] < 2.0 * math.pi))

    def test_pilot_and_residual_sic_are_nonoptimistic(self):
        ideal = self.env.evaluate_action(
            self.site, self.action, include_pilot=False, residual_sic=0.0
        )
        pilot = self.env.evaluate_action(
            self.site, self.action, include_pilot=True, residual_sic=0.0
        )
        impaired = self.env.evaluate_action(
            self.site, self.action, include_pilot=True, residual_sic=self.cfg.residual_sic
        )
        self.assertTrue(np.all(pilot["rates"] <= ideal["rates"] + 1e-12))
        self.assertTrue(np.all(impaired["rates"] <= pilot["rates"] + 1e-12))
        self.assertAlmostEqual(
            float(pilot["rates"].sum() / ideal["rates"].sum()),
            self.cfg.payload_fraction,
            places=12,
        )

    def test_sic_order_uses_executed_phase_and_estimated_channels(self):
        out = self.env.evaluate_action(self.site, self.action)
        phase = out["phases"]
        ch = self.env._channels
        h_est = ch["direct_est"] + np.sum(
            ch["casc_est"][self.site] * np.exp(1j * phase)[None, :], axis=1
        )
        expected = np.argsort(np.abs(h_est) ** 2)
        np.testing.assert_array_equal(out["sic_order"], expected)

    def test_rate_uses_minimum_sinr_across_required_decoders(self):
        out = self.env.evaluate_action(self.site, self.action)
        ch = self.env._channels
        phase = out["phases"]
        h_true = ch["direct_true"] + np.sum(
            ch["cascaded"][self.site] * np.exp(1j * phase)[None, :], axis=1
        )
        gains = np.abs(h_true) ** 2
        order = out["sic_order"]
        powers = out["powers"]
        expected = np.zeros(self.cfg.n_users)
        for rank, user in enumerate(order):
            uncancelled = float(np.sum(powers[order[rank + 1 :]]))
            cancelled = float(np.sum(powers[order[:rank]]))
            candidates = []
            for decoder in order[rank:]:
                denominator = gains[decoder] * (
                    uncancelled + self.cfg.residual_sic * cancelled
                ) + self.cfg.noise_power
                candidates.append(gains[decoder] * powers[user] / denominator)
            expected[user] = min(candidates)
        np.testing.assert_allclose(out["sinr"], expected, rtol=1e-12, atol=1e-12)

    def test_seed_reproduces_initial_state_and_action_metrics(self):
        env2 = RISNOMAEnv(self.cfg, seed=123)
        site2, action2 = env2.heuristic_action("decoupled")
        out1 = self.env.evaluate_action(self.site, self.action)
        out2 = env2.evaluate_action(site2, action2)
        self.assertEqual(self.site, site2)
        np.testing.assert_array_equal(self.action, action2)
        np.testing.assert_array_equal(out1["rates"], out2["rates"])

    def test_mobility_updates_after_exactly_one_hundred_actions(self):
        initial = self.env.positions.copy()
        for _ in range(self.cfg.mobility_period_steps - 1):
            site, action = self.env.heuristic_action("decoupled")
            self.env.step(site, action)
        np.testing.assert_array_equal(self.env.positions, initial)
        site, action = self.env.heuristic_action("decoupled")
        self.env.step(site, action)
        self.assertFalse(np.array_equal(self.env.positions, initial))


if __name__ == "__main__":
    unittest.main()
