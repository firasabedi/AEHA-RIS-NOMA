"""Reproducible RIS-NOMA hybrid-action experiments.

This is a clean-room reimplementation from the procedure described in
``sn-article.tex``.  It does not claim to recover the unavailable original
code or random streams.  Runtime dependencies are listed in
``requirements.txt``.

The experiment fixes the review-identified modeling problems:

* the action interval equals the 1 ms coherence interval;
* mobility is updated every 100 ms;
* rates include a pilot-overhead pre-log factor;
* SINR includes residual interference and minimum-over-decoder SIC feasibility;
* phase actions can be projected to continuous, 2-bit, or 1-bit hardware;
* candidate-site studies include L=3, 20, and 50;
* scheduling-pool studies include K=10, 20, and 50 with U=3;
* the DDPG hybrid adapter is stated explicitly (straight-through Gumbel-softmax).

The default ``smoke`` profile is for CI and method validation.  ``paper`` is
the manuscript profile.  Every output records the exact profile and seed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import random
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal
from scipy import stats


DEVICE = torch.device("cpu")
DTYPE = torch.float32


@dataclass(frozen=True)
class Config:
    road_length_m: float = 500.0
    n_vehicles: int = 10
    n_users: int = 3
    n_sites: int = 3
    n_ris: int = 64
    pathloss_exp: float = 3.0
    bandwidth_mhz: float = 5.0
    p_max: float = 1.0
    noise_power: float = 0.02
    csi_error_var: float = 0.05
    residual_sic: float = 0.08
    coherence_ms: int = 1
    mobility_update_ms: int = 100
    coherence_symbols: int = 512
    pilot_symbols_base: int = 8
    pilot_symbols_per_ris_element: float = 0.5
    min_rate_mbps: float = 1.0
    speed_min_kmh: float = 40.0
    speed_max_kmh: float = 80.0
    episode_steps: int = 250
    hidden: int = 256
    batch_size: int = 128
    replay_size: int = 20_000
    warmup_steps: int = 512
    train_steps: int = 8_000
    eval_steps: int = 1_000
    gamma: float = 0.99
    tau: float = 0.005
    lr: float = 3e-4
    gumbel_tau: float = 0.8
    robust_perturb_std: float = 0.03
    reward_rate: float = 1.0
    reward_fair: float = 2.0
    reward_qos: float = 1.0

    @property
    def pilot_symbols(self) -> int:
        return int(round(self.pilot_symbols_base + self.pilot_symbols_per_ris_element * self.n_ris))

    @property
    def payload_fraction(self) -> float:
        return max(0.0, 1.0 - self.pilot_symbols / self.coherence_symbols)

    @property
    def mobility_period_steps(self) -> int:
        ratio = self.mobility_update_ms / self.coherence_ms
        if ratio < 1 or not float(ratio).is_integer():
            raise ValueError("mobility_update_ms must be an integer multiple of coherence_ms")
        return int(ratio)


PROFILES = {
    "smoke": dict(train_steps=700, eval_steps=120, warmup_steps=128, batch_size=64, episode_steps=100, hidden=96),
    "quick": dict(train_steps=3_000, eval_steps=500, warmup_steps=256, batch_size=128, episode_steps=200, hidden=128),
    "paper": dict(train_steps=8_000, eval_steps=1_000, warmup_steps=512, batch_size=128, episode_steps=250, hidden=256),
}


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(max(1, min(4, torch.get_num_threads())))


def dbm_to_linear(dbm: float) -> float:
    return 10.0 ** ((dbm - 30.0) / 10.0)


class RISNOMAEnv:
    """Coherence-time physical-layer environment.

    The state contains compressed estimated CSI: vehicle kinematics, estimated
    direct gains, site quality scores, and the cosine/sine of an aggregate
    phase target for every site and RIS element.  The latter retains the
    information required for a policy to learn phase alignment without storing
    every BS-RIS-user tensor in the replay buffer.
    """

    def __init__(self, cfg: Config, seed: int = 0):
        self.cfg = cfg
        self.rng = np.random.default_rng(seed)
        self.steps = 0
        self.positions = np.zeros(cfg.n_vehicles, dtype=np.float32)
        self.velocities = np.zeros(cfg.n_vehicles, dtype=np.float32)
        self.site_x = np.linspace(0.12, 0.88, cfg.n_sites, dtype=np.float32) * cfg.road_length_m
        self.previous_site = 0
        self._channels = None
        self.reset()

    @property
    def state_dim(self) -> int:
        c = self.cfg
        return 2 * c.n_vehicles + c.n_users + c.n_sites + 2 * c.n_sites * c.n_ris + c.n_sites

    @property
    def action_dim(self) -> int:
        return self.cfg.n_ris + self.cfg.n_users

    def reset(self) -> np.ndarray:
        c = self.cfg
        self.steps = 0
        self.positions = self.rng.uniform(0.0, c.road_length_m, c.n_vehicles).astype(np.float32)
        self.velocities = self.rng.uniform(c.speed_min_kmh, c.speed_max_kmh, c.n_vehicles).astype(np.float32)
        self.previous_site = int(self.rng.integers(c.n_sites))
        self._sample_channels()
        return self._state()

    def _update_mobility(self) -> None:
        c = self.cfg
        if self.steps % c.mobility_period_steps != 0:
            return
        dt_s = c.mobility_update_ms / 1000.0
        acceleration_mps2 = self.rng.normal(0.0, 0.8, c.n_vehicles)
        velocity_mps = self.velocities / 3.6 + acceleration_mps2 * dt_s
        self.velocities = np.clip(velocity_mps * 3.6, 15.0, 130.0).astype(np.float32)
        distance = self.velocities / 3.6 * dt_s
        self.positions = np.mod(self.positions + distance, c.road_length_m).astype(np.float32)

    def _sample_channels(self) -> None:
        c = self.cfg
        # Vehicles with the strongest large-scale direct gains are scheduled.
        d_bs = np.abs(self.positions - c.road_length_m / 2.0) + 25.0
        direct_scale_all = (75.0 / d_bs) ** (c.pathloss_exp / 2.0)
        scheduled = np.argsort(direct_scale_all)[-c.n_users :]
        scheduled = scheduled[np.argsort(self.positions[scheduled])]
        pos = self.positions[scheduled]
        direct_scale = direct_scale_all[scheduled]

        direct_small = (self.rng.normal(size=c.n_users) + 1j * self.rng.normal(size=c.n_users)) / math.sqrt(2.0)
        direct_true = direct_scale * direct_small

        # Cascaded coefficients include both BS-RIS and RIS-user distance loss.
        cascaded = np.empty((c.n_sites, c.n_users, c.n_ris), dtype=np.complex64)
        for ell, sx in enumerate(self.site_x):
            # Candidate mounting sites are assumed to have engineered,
            # line-of-sight BS-RIS feeder links of comparable strength.  The
            # site decision is therefore driven primarily by the mobile
            # RIS-user leg rather than being trivially fixed to the site
            # nearest the centrally located BS.
            bs_ris = 1.0
            d_ru = np.abs(pos - sx) + 10.0
            ris_user = (45.0 / d_ru) ** (c.pathloss_exp / 2.0)
            small = (self.rng.normal(size=(c.n_users, c.n_ris)) + 1j * self.rng.normal(size=(c.n_users, c.n_ris))) / math.sqrt(2.0 * c.n_ris)
            cascaded[ell] = (0.32 * bs_ris * ris_user[:, None] * small).astype(np.complex64)

        err_scale = math.sqrt(max(c.csi_error_var, 0.0) / 2.0)
        direct_est = direct_true + err_scale * (
            self.rng.normal(size=c.n_users) + 1j * self.rng.normal(size=c.n_users)
        )
        casc_est = cascaded + err_scale / math.sqrt(c.n_ris) * (
            self.rng.normal(size=cascaded.shape) + 1j * self.rng.normal(size=cascaded.shape)
        )

        # Weighted aggregate target: align each reflected contribution with
        # its user's estimated direct-link phase while giving weaker direct
        # users slightly greater weight.  This retains the phase reference
        # that is needed to make phase control identifiable from the state.
        weights = 1.0 / np.maximum(np.abs(direct_est), 0.1)
        weights /= weights.sum()
        aggregate = np.sum(
            casc_est * np.conj(direct_est)[None, :, None] * weights[None, :, None],
            axis=1,
        )
        target_phase = np.mod(-np.angle(aggregate), 2.0 * math.pi)
        site_score = np.mean(np.abs(aggregate), axis=1) * c.n_ris

        self._channels = dict(
            scheduled=scheduled,
            direct_true=direct_true.astype(np.complex64),
            direct_est=direct_est.astype(np.complex64),
            cascaded=cascaded,
            casc_est=casc_est.astype(np.complex64),
            target_phase=target_phase.astype(np.float32),
            site_score=site_score.astype(np.float32),
        )

    def _state(self) -> np.ndarray:
        c = self.cfg
        ch = self._channels
        kin_pos = self.positions / c.road_length_m
        kin_vel = self.velocities / 130.0
        direct_gain = np.log1p(np.abs(ch["direct_est"]) ** 2)
        direct_gain = direct_gain / max(float(direct_gain.max()), 1e-6)
        site_score = ch["site_score"] / max(float(ch["site_score"].max()), 1e-6)
        phase = ch["target_phase"]
        prev = np.zeros(c.n_sites, dtype=np.float32)
        prev[self.previous_site] = 1.0
        state = np.concatenate(
            [kin_pos, kin_vel, direct_gain.astype(np.float32), site_score, np.cos(phase).ravel(), np.sin(phase).ravel(), prev]
        ).astype(np.float32)
        return state

    @staticmethod
    def _jain(rates: np.ndarray) -> float:
        denom = len(rates) * float(np.sum(rates**2))
        return float(np.sum(rates) ** 2 / denom) if denom > 0 else 0.0

    def evaluate_action(
        self,
        site: int,
        continuous: np.ndarray,
        phase_bits: Optional[int] = None,
        include_pilot: bool = True,
        residual_sic: Optional[float] = None,
    ) -> Dict[str, object]:
        c = self.cfg
        ch = self._channels
        site = int(np.clip(site, 0, c.n_sites - 1))
        phase_raw = np.asarray(continuous[: c.n_ris], dtype=np.float64)
        phase = math.pi * (phase_raw + 1.0)
        if phase_bits is not None:
            levels = 2**phase_bits
            scaled = levels * phase / (2.0 * math.pi)
            phase = (2.0 * math.pi / levels) * np.mod(np.floor(scaled + 0.5), levels)
        power_logits = np.asarray(continuous[c.n_ris : c.n_ris + c.n_users], dtype=np.float64)
        power_logits -= power_logits.max()
        powers = np.exp(power_logits)
        powers = c.p_max * powers / powers.sum()

        reflected = np.sum(ch["cascaded"][site] * np.exp(1j * phase)[None, :], axis=1)
        h_true = ch["direct_true"] + reflected
        # Estimated order is what the receiver/controller can actually use.
        h_est = ch["direct_est"] + np.sum(
            ch["casc_est"][site] * np.exp(1j * phase)[None, :], axis=1
        )
        order = np.argsort(np.abs(h_est) ** 2)  # weak to strong
        gains = np.abs(h_true) ** 2
        rho = c.residual_sic if residual_sic is None else residual_sic
        sinr = np.zeros(c.n_users, dtype=np.float64)
        for rank, user in enumerate(order):
            # Message ``user`` must be decodable at its own receiver and at
            # every estimated-stronger receiver that cancels it.  The
            # achievable message SINR is therefore the minimum across those
            # decoders, not merely the intended receiver's own-message SINR.
            uncancelled = float(np.sum(powers[order[rank + 1 :]]))
            cancelled = float(np.sum(powers[order[:rank]]))
            decoder_sinr = []
            for decoder in order[rank:]:
                interference = gains[decoder] * (uncancelled + rho * cancelled)
                decoder_sinr.append(
                    gains[decoder] * powers[user] / (interference + c.noise_power)
                )
            sinr[user] = float(np.min(decoder_sinr))
        payload = c.payload_fraction if include_pilot else 1.0
        rates = payload * c.bandwidth_mhz * np.log2(1.0 + sinr)
        sum_rate = float(np.sum(rates))
        fairness = self._jain(rates)
        qos = float(np.mean(rates >= c.min_rate_mbps))
        reward = c.reward_rate * sum_rate + c.reward_fair * fairness - c.reward_qos * float(np.sum(rates < c.min_rate_mbps))
        return dict(
            rates=rates,
            sum_rate=sum_rate,
            fairness=fairness,
            qos=qos,
            reward=reward,
            powers=powers,
            phases=phase,
            sinr=sinr,
            sic_order=order,
            site=site,
            payload_fraction=payload,
        )

    def step(self, site: int, continuous: np.ndarray, **kwargs) -> Tuple[np.ndarray, float, bool, Dict[str, object]]:
        info = self.evaluate_action(site, continuous, **kwargs)
        self.previous_site = int(site)
        self.steps += 1
        done = self.steps >= self.cfg.episode_steps
        self._update_mobility()
        self._sample_channels()
        return self._state(), float(info["reward"]), done, info

    def heuristic_action(self, method: str = "decoupled") -> Tuple[int, np.ndarray]:
        c = self.cfg
        ch = self._channels
        if method == "no_ris":
            site = 0
            phase = np.zeros(c.n_ris)
        elif method == "fixed_site":
            site = c.n_sites // 2
            strongest = int(np.argmax(np.abs(ch["direct_est"])))
            phase = np.mod(
                np.angle(ch["direct_est"][strongest]) - np.angle(ch["casc_est"][site, strongest]),
                2.0 * math.pi,
            ) / math.pi - 1.0
        else:
            # Conventional maximum-ratio reflection is deliberately
            # single-user: it selects and aligns the RIS for the strongest
            # estimated direct-link user.  It does not jointly optimize the
            # multi-user NOMA objective.
            strongest = int(np.argmax(np.abs(ch["direct_est"])))
            single_user_score = np.sum(np.abs(ch["casc_est"][:, strongest, :]), axis=1)
            site = int(np.argmax(single_user_score))
            phase = np.mod(
                np.angle(ch["direct_est"][strongest]) - np.angle(ch["casc_est"][site, strongest]),
                2.0 * math.pi,
            ) / math.pi - 1.0
        direct = np.maximum(np.abs(ch["direct_est"]), 0.05)
        # Weak estimated users receive more power.
        alloc = 1.0 / direct
        power_logits = np.log(alloc / alloc.sum() + 1e-9)
        action = np.concatenate([np.clip(phase, -1.0, 1.0), np.clip(power_logits, -1.0, 1.0)])
        return site, action.astype(np.float32)


class ReplayBuffer:
    def __init__(self, capacity: int, state_dim: int, action_dim: int, n_sites: int):
        self.capacity = capacity
        self.state = np.zeros((capacity, state_dim), dtype=np.float32)
        self.site = np.zeros((capacity, n_sites), dtype=np.float32)
        self.action = np.zeros((capacity, action_dim), dtype=np.float32)
        self.reward = np.zeros((capacity, 1), dtype=np.float32)
        self.next_state = np.zeros((capacity, state_dim), dtype=np.float32)
        self.done = np.zeros((capacity, 1), dtype=np.float32)
        self.pos = 0
        self.size = 0

    def add(self, s, site, a, r, ns, done):
        i = self.pos
        self.state[i] = s
        self.site[i] = site
        self.action[i] = a
        self.reward[i] = r
        self.next_state[i] = ns
        self.done[i] = done
        self.pos = (self.pos + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, n: int):
        idx = np.random.randint(0, self.size, size=n)
        return tuple(
            torch.as_tensor(x[idx], device=DEVICE, dtype=DTYPE)
            for x in (self.state, self.site, self.action, self.reward, self.next_state, self.done)
        )


def mlp(in_dim: int, hidden: int, out_dim: int) -> nn.Sequential:
    return nn.Sequential(
        nn.Linear(in_dim, hidden),
        nn.ReLU(),
        nn.Linear(hidden, hidden),
        nn.ReLU(),
        nn.Linear(hidden, out_dim),
    )


class HybridActor(nn.Module):
    def __init__(self, state_dim: int, n_sites: int, action_dim: int, hidden: int):
        super().__init__()
        self.body = nn.Sequential(nn.Linear(state_dim, hidden), nn.ReLU(), nn.Linear(hidden, hidden), nn.ReLU())
        self.site_head = nn.Linear(hidden, n_sites)
        self.mean_head = nn.Linear(hidden, action_dim)
        self.logstd_head = nn.Linear(hidden, action_dim)

    def forward(self, state):
        z = self.body(state)
        return self.site_head(z), self.mean_head(z), self.logstd_head(z).clamp(-5.0, 1.0)

    def sample(self, state, tau: float = 0.8, deterministic: bool = False):
        logits, mean, logstd = self(state)
        if deterministic:
            site_idx = logits.argmax(dim=-1)
            site = F.one_hot(site_idx, logits.shape[-1]).to(DTYPE)
            pre = mean
        else:
            site = F.gumbel_softmax(logits, tau=tau, hard=True)
            pre = Normal(mean, logstd.exp()).rsample()
        action = torch.tanh(pre)
        normal = Normal(mean, logstd.exp())
        logp_cont = normal.log_prob(pre) - torch.log(1.0 - action.pow(2) + 1e-6)
        logp_cont = logp_cont.sum(dim=-1, keepdim=True)
        logp_site = (site * F.log_softmax(logits, dim=-1)).sum(dim=-1, keepdim=True)
        return site, action, logp_site + logp_cont


class Critic(nn.Module):
    def __init__(self, state_dim: int, n_sites: int, action_dim: int, hidden: int):
        super().__init__()
        self.net = mlp(state_dim + n_sites + action_dim, hidden, 1)

    def forward(self, state, site, action):
        return self.net(torch.cat([state, site, action], dim=-1))


class HybridSAC:
    def __init__(self, env: RISNOMAEnv, cfg: Config):
        self.cfg = cfg
        self.actor = HybridActor(env.state_dim, cfg.n_sites, env.action_dim, cfg.hidden).to(DEVICE)
        self.q1 = Critic(env.state_dim, cfg.n_sites, env.action_dim, cfg.hidden).to(DEVICE)
        self.q2 = Critic(env.state_dim, cfg.n_sites, env.action_dim, cfg.hidden).to(DEVICE)
        self.tq1 = Critic(env.state_dim, cfg.n_sites, env.action_dim, cfg.hidden).to(DEVICE)
        self.tq2 = Critic(env.state_dim, cfg.n_sites, env.action_dim, cfg.hidden).to(DEVICE)
        self.tq1.load_state_dict(self.q1.state_dict())
        self.tq2.load_state_dict(self.q2.state_dict())
        self.actor_opt = torch.optim.Adam(self.actor.parameters(), lr=cfg.lr)
        self.q_opt = torch.optim.Adam(list(self.q1.parameters()) + list(self.q2.parameters()), lr=cfg.lr)
        self.log_alpha = torch.tensor(math.log(0.05), dtype=DTYPE, device=DEVICE, requires_grad=True)
        self.alpha_opt = torch.optim.Adam([self.log_alpha], lr=cfg.lr)
        self.target_entropy = -(env.action_dim + math.log(cfg.n_sites)) * 0.25

    @property
    def alpha(self):
        return self.log_alpha.exp()

    def act(self, state: np.ndarray, deterministic: bool = True):
        with torch.no_grad():
            s = torch.as_tensor(state[None, :], dtype=DTYPE, device=DEVICE)
            site, action, _ = self.actor.sample(s, self.cfg.gumbel_tau, deterministic)
        return int(site.argmax(dim=-1).item()), action.cpu().numpy()[0], site.cpu().numpy()[0]

    def update(self, batch):
        s, site, a, r, ns, done = batch
        c = self.cfg
        # Robust perturbation applies only to channel-derived state features;
        # normalized kinematics and the previous-site one-hot vector are kept
        # intact.
        if c.robust_perturb_std > 0:
            s_train, ns_train = s.clone(), ns.clone()
            lo, hi = 2 * c.n_vehicles, s.shape[1] - c.n_sites
            s_train[:, lo:hi] += c.robust_perturb_std * torch.randn_like(s_train[:, lo:hi])
            ns_train[:, lo:hi] += c.robust_perturb_std * torch.randn_like(ns_train[:, lo:hi])
        else:
            s_train, ns_train = s, ns
        with torch.no_grad():
            nsite, na, nlogp = self.actor.sample(ns_train, c.gumbel_tau, False)
            target_q = torch.minimum(self.tq1(ns_train, nsite, na), self.tq2(ns_train, nsite, na))
            y = r + c.gamma * (1.0 - done) * (target_q - self.alpha.detach() * nlogp)
        q1 = self.q1(s_train, site, a)
        q2 = self.q2(s_train, site, a)
        qloss = F.mse_loss(q1, y) + F.mse_loss(q2, y)
        self.q_opt.zero_grad(set_to_none=True)
        qloss.backward()
        nn.utils.clip_grad_norm_(list(self.q1.parameters()) + list(self.q2.parameters()), 5.0)
        self.q_opt.step()

        psite, pa, logp = self.actor.sample(s_train, c.gumbel_tau, False)
        qpi = torch.minimum(self.q1(s_train, psite, pa), self.q2(s_train, psite, pa))
        aloss = (self.alpha.detach() * logp - qpi).mean()
        self.actor_opt.zero_grad(set_to_none=True)
        aloss.backward()
        nn.utils.clip_grad_norm_(self.actor.parameters(), 5.0)
        self.actor_opt.step()

        temp_loss = -(self.log_alpha * (logp.detach() + self.target_entropy)).mean()
        self.alpha_opt.zero_grad(set_to_none=True)
        temp_loss.backward()
        self.alpha_opt.step()

        with torch.no_grad():
            for target, source in [(self.tq1, self.q1), (self.tq2, self.q2)]:
                for tp, sp in zip(target.parameters(), source.parameters()):
                    tp.mul_(1.0 - c.tau).add_(sp, alpha=c.tau)
        return float(qloss.item()), float(aloss.item())


class DeterministicHybridActor(nn.Module):
    """DDPG actor with a disclosed straight-through categorical adapter."""

    def __init__(self, state_dim: int, n_sites: int, action_dim: int, hidden: int):
        super().__init__()
        self.body = nn.Sequential(nn.Linear(state_dim, hidden), nn.ReLU(), nn.Linear(hidden, hidden), nn.ReLU())
        self.site_head = nn.Linear(hidden, n_sites)
        self.action_head = nn.Linear(hidden, action_dim)

    def forward(self, state, tau: float = 0.8, hard: bool = True, stochastic_site: bool = True):
        z = self.body(state)
        logits = self.site_head(z)
        if stochastic_site:
            site = F.gumbel_softmax(logits, tau=tau, hard=hard)
        else:
            idx = logits.argmax(dim=-1)
            site = F.one_hot(idx, logits.shape[-1]).to(DTYPE)
        return site, torch.tanh(self.action_head(z))


class HybridDDPG:
    """DDPG comparator for the hybrid action space.

    Site logits use straight-through Gumbel-softmax in actor updates, while
    execution uses argmax. Continuous exploration uses clipped Gaussian noise.
    The critic consumes state, one-hot/relaxed site, and continuous action.
    """

    def __init__(self, env: RISNOMAEnv, cfg: Config):
        self.cfg = cfg
        self.actor = DeterministicHybridActor(env.state_dim, cfg.n_sites, env.action_dim, cfg.hidden).to(DEVICE)
        self.target_actor = DeterministicHybridActor(env.state_dim, cfg.n_sites, env.action_dim, cfg.hidden).to(DEVICE)
        self.critic = Critic(env.state_dim, cfg.n_sites, env.action_dim, cfg.hidden).to(DEVICE)
        self.target_critic = Critic(env.state_dim, cfg.n_sites, env.action_dim, cfg.hidden).to(DEVICE)
        self.target_actor.load_state_dict(self.actor.state_dict())
        self.target_critic.load_state_dict(self.critic.state_dict())
        self.actor_opt = torch.optim.Adam(self.actor.parameters(), lr=cfg.lr)
        self.critic_opt = torch.optim.Adam(self.critic.parameters(), lr=cfg.lr)

    def act(self, state: np.ndarray, deterministic: bool = True, noise_std: float = 0.10):
        with torch.no_grad():
            s = torch.as_tensor(state[None, :], dtype=DTYPE, device=DEVICE)
            site, action = self.actor(s, self.cfg.gumbel_tau, True, stochastic_site=not deterministic)
            if not deterministic:
                action = (action + noise_std * torch.randn_like(action)).clamp(-1.0, 1.0)
        return int(site.argmax(dim=-1).item()), action.cpu().numpy()[0], site.cpu().numpy()[0]

    def update(self, batch):
        s, site, a, r, ns, done = batch
        c = self.cfg
        if c.robust_perturb_std > 0:
            s_train, ns_train = s.clone(), ns.clone()
            lo, hi = 2 * c.n_vehicles, s.shape[1] - c.n_sites
            s_train[:, lo:hi] += c.robust_perturb_std * torch.randn_like(s_train[:, lo:hi])
            ns_train[:, lo:hi] += c.robust_perturb_std * torch.randn_like(ns_train[:, lo:hi])
        else:
            s_train, ns_train = s, ns
        with torch.no_grad():
            nsite, na = self.target_actor(ns_train, c.gumbel_tau, True, stochastic_site=True)
            y = r + c.gamma * (1.0 - done) * self.target_critic(ns_train, nsite, na)
        q = self.critic(s_train, site, a)
        qloss = F.mse_loss(q, y)
        self.critic_opt.zero_grad(set_to_none=True)
        qloss.backward()
        nn.utils.clip_grad_norm_(self.critic.parameters(), 5.0)
        self.critic_opt.step()

        psite, pa = self.actor(s_train, c.gumbel_tau, True, stochastic_site=True)
        aloss = -self.critic(s_train, psite, pa).mean()
        self.actor_opt.zero_grad(set_to_none=True)
        aloss.backward()
        nn.utils.clip_grad_norm_(self.actor.parameters(), 5.0)
        self.actor_opt.step()
        with torch.no_grad():
            for target, source in [(self.target_actor, self.actor), (self.target_critic, self.critic)]:
                for tp, sp in zip(target.parameters(), source.parameters()):
                    tp.mul_(1.0 - c.tau).add_(sp, alpha=c.tau)
        return float(qloss.item()), float(aloss.item())


def train_sac(cfg: Config, seed: int, log_every: int = 100) -> Tuple[HybridSAC, Dict[str, object]]:
    seed_everything(seed)
    env = RISNOMAEnv(cfg, seed)
    agent = HybridSAC(env, cfg)
    rb = ReplayBuffer(cfg.replay_size, env.state_dim, env.action_dim, cfg.n_sites)
    state = env.reset()
    rewards: List[float] = []
    rolling: List[float] = []
    start = time.perf_counter()
    for step in range(cfg.train_steps):
        if step < cfg.warmup_steps:
            site_idx = int(np.random.randint(cfg.n_sites))
            site_onehot = np.eye(cfg.n_sites, dtype=np.float32)[site_idx]
            action = np.random.uniform(-1.0, 1.0, env.action_dim).astype(np.float32)
        else:
            site_idx, action, site_onehot = agent.act(state, deterministic=False)
        next_state, reward, done, _ = env.step(site_idx, action)
        rb.add(state, site_onehot, action, reward / 20.0, next_state, float(done))
        state = env.reset() if done else next_state
        rewards.append(reward)
        if rb.size >= cfg.batch_size and step >= cfg.warmup_steps:
            agent.update(rb.sample(cfg.batch_size))
        if (step + 1) % log_every == 0:
            rolling.append(float(np.mean(rewards[-log_every:])))
    elapsed = time.perf_counter() - start
    return agent, dict(seed=seed, training_seconds=elapsed, reward_curve=rolling, steps=cfg.train_steps)


def train_ddpg(cfg: Config, seed: int, log_every: int = 100) -> Tuple[HybridDDPG, Dict[str, object]]:
    seed_everything(seed + 50_000)
    env = RISNOMAEnv(cfg, seed + 50_000)
    agent = HybridDDPG(env, cfg)
    rb = ReplayBuffer(cfg.replay_size, env.state_dim, env.action_dim, cfg.n_sites)
    state = env.reset()
    rewards: List[float] = []
    rolling: List[float] = []
    start = time.perf_counter()
    for step in range(cfg.train_steps):
        if step < cfg.warmup_steps:
            site_idx = int(np.random.randint(cfg.n_sites))
            site_onehot = np.eye(cfg.n_sites, dtype=np.float32)[site_idx]
            action = np.random.uniform(-1.0, 1.0, env.action_dim).astype(np.float32)
        else:
            site_idx, action, site_onehot = agent.act(state, deterministic=False, noise_std=max(0.03, 0.15 * (1.0 - step / cfg.train_steps)))
        next_state, reward, done, _ = env.step(site_idx, action)
        rb.add(state, site_onehot, action, reward / 20.0, next_state, float(done))
        state = env.reset() if done else next_state
        rewards.append(reward)
        if rb.size >= cfg.batch_size and step >= cfg.warmup_steps:
            agent.update(rb.sample(cfg.batch_size))
        if (step + 1) % log_every == 0:
            rolling.append(float(np.mean(rewards[-log_every:])))
    elapsed = time.perf_counter() - start
    return agent, dict(seed=seed, training_seconds=elapsed, reward_curve=rolling, steps=cfg.train_steps)


def evaluate_policy(
    cfg: Config,
    seed: int,
    agent: Optional[object] = None,
    heuristic: Optional[str] = None,
    phase_bits: Optional[int] = None,
    include_pilot: bool = True,
    residual_sic: Optional[float] = None,
) -> Dict[str, float]:
    env = RISNOMAEnv(cfg, seed + 100_000)
    state = env.reset()
    sums, fairs, qos_values, latencies, loop_latencies = [], [], [], [], []
    handovers = 0
    prev_site = None
    for _ in range(cfg.eval_steps):
        t0 = time.perf_counter_ns()
        if agent is not None:
            site, action, _ = agent.act(state, deterministic=True)
        else:
            site, action = env.heuristic_action(heuristic or "decoupled")
        actor_done = time.perf_counter_ns()
        latencies.append((actor_done - t0) / 1e6)
        if prev_site is not None and site != prev_site:
            handovers += 1
        prev_site = site
        state, _, done, info = env.step(
            site,
            action,
            phase_bits=phase_bits,
            include_pilot=include_pilot,
            residual_sic=residual_sic,
        )
        loop_latencies.append((time.perf_counter_ns() - t0) / 1e6)
        sums.append(float(info["sum_rate"]))
        fairs.append(float(info["fairness"]))
        qos_values.append(float(info["qos"]))
        if done:
            state = env.reset()
    arr = np.asarray(sums)
    return dict(
        sum_rate_mean=float(arr.mean()),
        sum_rate_std=float(arr.std(ddof=1)),
        sum_rate_p05=float(np.quantile(arr, 0.05)),
        sum_rate_p95=float(np.quantile(arr, 0.95)),
        fairness=float(np.mean(fairs)),
        qos_percent=100.0 * float(np.mean(qos_values)),
        inference_ms_median=float(np.median(latencies)),
        inference_ms_p95=float(np.quantile(latencies, 0.95)),
        software_loop_ms_median=float(np.median(loop_latencies)),
        software_loop_ms_p95=float(np.quantile(loop_latencies, 0.95)),
        handover_percent=100.0 * handovers / max(1, cfg.eval_steps - 1),
        payload_fraction=cfg.payload_fraction if include_pilot else 1.0,
    )


def mean_ci(values: Sequence[float]) -> Tuple[float, float]:
    a = np.asarray(values, dtype=float)
    if len(a) < 2:
        return float(a.mean()), 0.0
    critical = float(stats.t.ppf(0.975, df=len(a) - 1))
    return float(a.mean()), float(critical * a.std(ddof=1) / math.sqrt(len(a)))


def aggregate_rows(rows: List[Dict[str, object]], group_keys: Sequence[str]) -> List[Dict[str, object]]:
    frame = pd.DataFrame(rows)
    metrics = [
        "sum_rate_mean",
        "fairness",
        "qos_percent",
        "inference_ms_median",
        "inference_ms_p95",
        "software_loop_ms_median",
        "software_loop_ms_p95",
        "handover_percent",
        "training_seconds",
        "model_parameters",
    ]
    out = []
    for key, group in frame.groupby(list(group_keys), dropna=False):
        if not isinstance(key, tuple):
            key = (key,)
        row = dict(zip(group_keys, key))
        for metric in metrics:
            if metric not in group:
                continue
            values = group[metric].dropna().values
            if len(values) == 0:
                continue
            mean, ci = mean_ci(values)
            row[metric] = mean
            row[metric + "_ci95"] = ci
        row["n_seeds"] = len(group)
        out.append(row)
    return out


def save_json(path: Path, obj) -> None:
    def convert(value):
        if isinstance(value, np.integer):
            return int(value)
        if isinstance(value, np.floating):
            return float(value)
        if isinstance(value, np.ndarray):
            return value.tolist()
        raise TypeError(f"Unsupported JSON value: {type(value)!r}")

    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=convert), encoding="utf-8")


def run_suite(profile: str, seeds: Sequence[int], outdir: Path) -> Dict[str, object]:
    cfg = Config(**PROFILES[profile])
    outdir.mkdir(parents=True, exist_ok=True)
    models = outdir / "models"
    models.mkdir(exist_ok=True)
    raw_rows: List[Dict[str, object]] = []
    train_logs: List[Dict[str, object]] = []
    ddpg_logs: List[Dict[str, object]] = []
    agents: Dict[int, HybridSAC] = {}

    for seed in seeds:
        agent, log = train_sac(cfg, seed)
        agents[seed] = agent
        torch.save(agent.actor.state_dict(), models / f"hybrid_sac_L{cfg.n_sites}_seed{seed}.pt")
        train_logs.append(log)
        ddpg, dlog = train_ddpg(cfg, seed)
        ddpg_logs.append(dlog)
        torch.save(ddpg.actor.state_dict(), models / f"hybrid_ddpg_L{cfg.n_sites}_seed{seed}.pt")
        for name, kwargs, extra in [
            (
                "Hybrid-SAC",
                dict(agent=agent),
                dict(
                    training_seconds=float(log["training_seconds"]),
                    model_parameters=sum(p.numel() for p in agent.actor.parameters()),
                ),
            ),
            (
                "DDPG-Hybrid",
                dict(agent=ddpg),
                dict(
                    training_seconds=float(dlog["training_seconds"]),
                    model_parameters=sum(p.numel() for p in ddpg.actor.parameters()),
                ),
            ),
            ("Decoupled-MRR", dict(heuristic="decoupled"), dict(training_seconds=0.0, model_parameters=0)),
            ("Fixed-site-RIS-NOMA", dict(heuristic="fixed_site"), dict(training_seconds=0.0, model_parameters=0)),
        ]:
            metrics = evaluate_policy(cfg, seed, **kwargs)
            raw_rows.append(
                dict(
                    experiment="main",
                    method=name,
                    seed=seed,
                    n_sites=cfg.n_sites,
                    phase_bits="continuous",
                    **extra,
                    **metrics,
                )
            )

        # Hardware phase-resolution sensitivity uses the same trained policy.
        for label, bits in [("continuous", None), ("2-bit", 2), ("1-bit", 1)]:
            metrics = evaluate_policy(cfg, seed, agent=agent, phase_bits=bits)
            raw_rows.append(dict(experiment="quantization", method="Hybrid-SAC", seed=seed, n_sites=cfg.n_sites, phase_bits=label, **metrics))

        # Isolate pilot and imperfect-SIC penalties.
        for label, pilot, rho in [
            ("ideal", False, 0.0),
            ("pilot-only", True, 0.0),
            ("pilot+imperfect-SIC", True, cfg.residual_sic),
        ]:
            metrics = evaluate_policy(cfg, seed, agent=agent, include_pilot=pilot, residual_sic=rho)
            raw_rows.append(dict(experiment="physical_impairments", method=label, seed=seed, n_sites=cfg.n_sites, phase_bits="continuous", **metrics))

    # Candidate-site scaling.  Each L is independently trained because the
    # categorical head and state dimension change with L.
    for n_sites in [3, 20, 50]:
        scale_cfg = replace(cfg, n_sites=n_sites)
        for seed in seeds:
            if n_sites == cfg.n_sites:
                agent = agents[seed]
                train_sec = float(next(x["training_seconds"] for x in train_logs if x["seed"] == seed))
                curve = next(x["reward_curve"] for x in train_logs if x["seed"] == seed)
            else:
                agent, slog = train_sac(scale_cfg, seed)
                train_sec = float(slog["training_seconds"])
                curve = slog["reward_curve"]
                torch.save(agent.actor.state_dict(), models / f"hybrid_sac_L{n_sites}_seed{seed}.pt")
            metrics = evaluate_policy(scale_cfg, seed, agent=agent)
            # Convergence is the first logged point reaching 95% of the final
            # 5-point mean, with log interval fixed at 100 steps.
            final = float(np.mean(curve[-5:])) if curve else float("nan")
            conv = scale_cfg.train_steps
            if curve and np.isfinite(final):
                threshold = 0.95 * final
                for i in range(max(1, len(curve) - 4)):
                    if np.mean(curve[i : i + 5]) >= threshold:
                        conv = (i + 5) * 100
                        break
            raw_rows.append(
                dict(
                    experiment="site_scaling",
                    method="Hybrid-SAC",
                    seed=seed,
                    n_sites=n_sites,
                    phase_bits="continuous",
                    training_seconds=train_sec,
                    convergence_steps=conv,
                    **metrics,
                )
            )

    # Vehicle-pool sensitivity requested by Reviewer 1.  U stays fixed so the
    # experiment isolates the scheduling-pool/density effect.
    for n_vehicles in [10, 20, 50]:
        vehicle_cfg = replace(
            cfg,
            n_vehicles=n_vehicles,
        )
        for seed in seeds:
            if n_vehicles == cfg.n_vehicles:
                agent = agents[seed]
            else:
                agent, vlog = train_sac(vehicle_cfg, seed + n_vehicles * 100)
                torch.save(agent.actor.state_dict(), models / f"hybrid_sac_K{n_vehicles}_seed{seed}.pt")
            metrics = evaluate_policy(vehicle_cfg, seed, agent=agent)
            raw_rows.append(
                dict(
                    experiment="vehicle_scaling",
                    method="Hybrid-SAC",
                    seed=seed,
                    n_sites=vehicle_cfg.n_sites,
                    n_vehicles=n_vehicles,
                    phase_bits="continuous",
                    **metrics,
                )
            )

    raw = pd.DataFrame(raw_rows)
    raw.to_csv(outdir / "metrics_raw.csv", index=False)
    aggregated = aggregate_rows(raw_rows, ["experiment", "method", "n_sites", "n_vehicles", "phase_bits"])
    pd.DataFrame(aggregated).to_csv(outdir / "metrics_summary.csv", index=False)

    # Paired seed-wise differences support direct, non-independent method
    # comparisons without inferring significance from overlapping marginal
    # confidence intervals.
    paired_rows: List[Dict[str, object]] = []
    main_raw = raw[raw.experiment == "main"]
    for comparator in ["DDPG-Hybrid", "Decoupled-MRR", "Fixed-site-RIS-NOMA"]:
        for metric in ["sum_rate_mean", "fairness", "qos_percent"]:
            pivot = main_raw.pivot(index="seed", columns="method", values=metric).dropna(
                subset=["Hybrid-SAC", comparator]
            )
            differences = pivot["Hybrid-SAC"] - pivot[comparator]
            relative = 100.0 * differences / pivot[comparator].replace(0.0, np.nan)
            diff_mean, diff_ci = mean_ci(differences.values)
            rel_mean, rel_ci = mean_ci(relative.dropna().values)
            paired_rows.append(
                dict(
                    method="Hybrid-SAC",
                    comparator=comparator,
                    metric=metric,
                    n_pairs=len(differences),
                    difference_mean=diff_mean,
                    difference_ci95=diff_ci,
                    relative_percent_mean=rel_mean,
                    relative_percent_ci95=rel_ci,
                )
            )
    pd.DataFrame(paired_rows).to_csv(outdir / "paired_main_comparisons.csv", index=False)

    # Figures used by the revised manuscript.
    _make_figures(raw, outdir)
    result = dict(
        profile=profile,
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        config=asdict(cfg),
        seeds=list(seeds),
        runtime=dict(
            python=platform.python_version(),
            platform=platform.platform(),
            processor=platform.processor(),
            numpy=np.__version__,
            pandas=pd.__version__,
            torch=torch.__version__,
            scipy=stats.__version__ if hasattr(stats, "__version__") else __import__("scipy").__version__,
            matplotlib=matplotlib.__version__,
            device=str(DEVICE),
        ),
        training=train_logs,
        ddpg_training=ddpg_logs,
        summary=aggregated,
        paired_main_comparisons=paired_rows,
        integrity_notes=[
            "Clean-room reimplementation from manuscript procedure; original code unavailable.",
            "All reported values in metrics files are generated by this script.",
            "Candidate-site models are independently trained because input/head dimensions vary with L.",
        ],
    )
    save_json(outdir / "run_manifest.json", result)
    return result


def _make_figures(raw: pd.DataFrame, outdir: Path) -> None:
    plt.rcParams.update({"font.size": 9, "font.family": "DejaVu Sans"})

    main = raw[raw.experiment == "main"].groupby("method").agg(
        sum_rate=("sum_rate_mean", "mean"),
        sum_rate_ci=("sum_rate_mean", lambda x: mean_ci(x)[1]),
        fairness=("fairness", "mean"),
        fairness_ci=("fairness", lambda x: mean_ci(x)[1]),
        qos=("qos_percent", "mean"),
        qos_ci=("qos_percent", lambda x: mean_ci(x)[1]),
    )
    order = [x for x in ["Fixed-site-RIS-NOMA", "DDPG-Hybrid", "Decoupled-MRR", "Hybrid-SAC"] if x in main.index]
    fig, axes = plt.subplots(1, 3, figsize=(9.0, 2.7))
    for ax, metric, title in zip(axes, ["sum_rate", "fairness", "qos"], ["Net sum-rate (Mbps)", "Jain fairness", "QoS satisfaction (%)"]):
        vals = main.loc[order, metric]
        colors = {"Fixed-site-RIS-NOMA": "#9E9E9E", "DDPG-Hybrid": "#CC79A7", "Decoupled-MRR": "#E69F00", "Hybrid-SAC": "#0072B2"}
        labels = {"Fixed-site-RIS-NOMA": "Fixed", "DDPG-Hybrid": "DDPG", "Decoupled-MRR": "Decoupled", "Hybrid-SAC": "Hybrid-SAC"}
        ax.bar(
            range(len(order)),
            vals,
            yerr=main.loc[order, metric + "_ci"],
            capsize=3,
            color=[colors[x] for x in order],
        )
        ax.set_xticks(range(len(order)), [labels[x] for x in order], rotation=20)
        ax.set_title(title)
        ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(outdir / "res_main_verified.png", dpi=220)
    plt.close(fig)

    q = raw[raw.experiment == "quantization"].groupby("phase_bits")["sum_rate_mean"].agg(
        mean="mean", ci=lambda x: mean_ci(x)[1]
    )
    q = q.reindex([x for x in ["continuous", "2-bit", "1-bit"] if x in q.index])
    fig, ax = plt.subplots(figsize=(4.8, 3.1))
    ax.bar(q.index, q["mean"], yerr=q["ci"], capsize=4, color=["#0072B2", "#56B4E9", "#CC79A7"])
    ax.set_ylabel("Net sum-rate (Mbps)")
    ax.set_title("RIS phase-resolution sensitivity")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(outdir / "res_quantization_verified.png", dpi=220)
    plt.close(fig)

    s = raw[raw.experiment == "site_scaling"].groupby("n_sites").agg(
        rate=("sum_rate_mean", "mean"),
        rate_ci=("sum_rate_mean", lambda x: mean_ci(x)[1]),
        latency=("inference_ms_median", "mean"),
        latency_ci=("inference_ms_median", lambda x: mean_ci(x)[1]),
        conv=("convergence_steps", "mean"),
        conv_ci=("convergence_steps", lambda x: mean_ci(x)[1]),
    )
    fig, axes = plt.subplots(1, 3, figsize=(9.0, 2.7))
    axes[0].errorbar(s.index, s.rate, yerr=s.rate_ci, fmt="o-", capsize=3, color="#0072B2")
    axes[0].set_ylabel("Net sum-rate (Mbps)")
    axes[1].errorbar(s.index, s.latency, yerr=s.latency_ci, fmt="o-", capsize=3, color="#D55E00")
    axes[1].set_ylabel("Median inference (ms)")
    axes[2].errorbar(s.index, s.conv, yerr=s.conv_ci, fmt="o-", capsize=3, color="#009E73")
    axes[2].set_ylabel("Convergence steps")
    for ax in axes:
        ax.set_xlabel("Candidate RIS sites, L")
        ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(outdir / "res_sites_verified.png", dpi=220)
    plt.close(fig)

    v = raw[raw.experiment == "vehicle_scaling"].groupby("n_vehicles").agg(
        rate=("sum_rate_mean", "mean"),
        rate_ci=("sum_rate_mean", lambda x: mean_ci(x)[1]),
        fairness=("fairness", "mean"),
        fairness_ci=("fairness", lambda x: mean_ci(x)[1]),
        qos=("qos_percent", "mean"),
        qos_ci=("qos_percent", lambda x: mean_ci(x)[1]),
    )
    fig, axes = plt.subplots(1, 3, figsize=(9.0, 2.7))
    axes[0].errorbar(v.index, v.rate, yerr=v.rate_ci, fmt="o-", capsize=3, color="#0072B2")
    axes[0].set_ylabel("Net sum-rate (Mbps)")
    axes[1].errorbar(v.index, v.fairness, yerr=v.fairness_ci, fmt="o-", capsize=3, color="#009E73")
    axes[1].set_ylabel("Jain fairness")
    axes[2].errorbar(v.index, v.qos, yerr=v.qos_ci, fmt="o-", capsize=3, color="#D55E00")
    axes[2].set_ylabel("QoS satisfaction (%)")
    for ax in axes:
        ax.set_xlabel("Vehicle pool, K (U=3)")
        ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(outdir / "res_vehicles_verified.png", dpi=220)
    plt.close(fig)

    p = raw[raw.experiment == "physical_impairments"].groupby("method")["sum_rate_mean"].agg(
        mean="mean", ci=lambda x: mean_ci(x)[1]
    )
    labels = [x for x in ["ideal", "pilot-only", "pilot+imperfect-SIC"] if x in p.index]
    p = p.reindex(labels)
    fig, ax = plt.subplots(figsize=(5.2, 3.1))
    ax.bar(range(len(labels)), p["mean"], yerr=p["ci"], capsize=4, color=["#999999", "#E69F00", "#D55E00"])
    ax.set_xticks(range(len(labels)), ["Ideal", "Pilot overhead", "Pilot + imperfect SIC"], rotation=15)
    ax.set_ylabel("Sum-rate (Mbps)")
    ax.set_title("Physical-impairment accounting")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(outdir / "res_impairments_verified.png", dpi=220)
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--profile", choices=PROFILES, default="smoke")
    p.add_argument("--seeds", default="11", help="Comma-separated integer seeds")
    p.add_argument("--outdir", type=Path, default=Path("results"))
    return p.parse_args()


def main() -> None:
    args = parse_args()
    seeds = [int(x) for x in args.seeds.split(",") if x.strip()]
    result = run_suite(args.profile, seeds, args.outdir)
    print(json.dumps({"profile": args.profile, "seeds": seeds, "rows": len(result["summary"])}, indent=2))


if __name__ == "__main__":
    main()
