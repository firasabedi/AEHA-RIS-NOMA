# Phase 3.  Part 1: test-time generalization / impairments / fairness (10 seeds,
# models from results_final).  Part 2: per-L retraining at L = 20, 50 (5 seeds).
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$env:KMP_DUPLICATE_LIB_OK = "TRUE"

# ---- Part 1 -------------------------------------------------------------
$pairs = @("11,22", "33,44", "55,66", "77,88", "99,110")
$jobs = foreach ($p in $pairs) {
    Start-Job -ArgumentList $p, $PSScriptRoot -ScriptBlock {
        param($p, $root)
        Set-Location $root
        $env:KMP_DUPLICATE_LIB_OK = "TRUE"
        python phase3.py --seeds $p --out ("results_phase3/s" + $p.Replace(",", "_")) 2>&1 | Out-String
    }
}
$jobs | Wait-Job | Out-Null
foreach ($j in $jobs) { Receive-Job $j | Select-String -Pattern 'Error|error|Traceback' }
python phase3.py --summarize (($pairs | ForEach-Object { "results_phase3/s" + $_.Replace(",", "_") }) -join ",")

# ---- Part 2 -------------------------------------------------------------
$seeds = 11, 22, 33, 44, 55
foreach ($L in 20, 50) {
    $jobs = foreach ($s in $seeds) {
        Start-Job -ArgumentList $s, $L, $PSScriptRoot -ScriptBlock {
            param($s, $L, $root)
            Set-Location $root
            $env:KMP_DUPLICATE_LIB_OK = "TRUE"
            python aeha.py --profile quick --gamma 0 --train-steps 8000 --n-sites $L --seeds $s `
                --methods "Decoupled-MRR,Agg-conf-d0.01,AEHA-res-fixed-delta,AEHA-main-no-pointer" `
                --outdir "results_phase3_L/L${L}_B_seed$s" 2>&1 | Out-String
            python aeha.py --profile quick --n-sites $L --seeds $s --methods "Hybrid-SAC" `
                --outdir "results_phase3_L/L${L}_A_seed$s" 2>&1 | Out-String
        }
    }
    $jobs | Wait-Job | Out-Null
    foreach ($j in $jobs) { Receive-Job $j | Select-String -Pattern 'Error|error|Traceback' }
    $dirs = ($seeds | ForEach-Object { "results_phase3_L/L${L}_B_seed$_,results_phase3_L/L${L}_A_seed$_" }) -join ","
    python aeha.py --merge $dirs --outdir "results_phase3_L/L${L}_merged"
}
