"""Manuscript figures for the AEHA revision (static, print, light mode).

Palette: reference categorical slots in fixed order (dataviz skill palette.md);
entity colours are constant across figures.  MRR is a neutral reference.
Secondary encoding (markers + dashes) on every series for greyscale print.
"""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

HERE = Path(__file__).resolve().parent
OUT = HERE / "manuscript" / "figs"
OUT.mkdir(parents=True, exist_ok=True)

INK, INK2, MUTED, GRID, AXIS, SURF = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7", "#fcfcfb"
C = {  # entity -> colour (fixed across figures)
    "AEHA": "#2a78d6",          # slot 1
    "spec008": "#eb6834",       # slot 2
    "spec0": "#1baf7a",         # slot 3
    "layer": "#eda100",         # slot 4
    "MRR": MUTED,               # neutral reference
}
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8.5, "axes.edgecolor": AXIS, "axes.linewidth": 0.8,
    "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "axes.titlesize": 9,
    "axes.titlecolor": INK, "figure.facecolor": "white", "axes.facecolor": "white",
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True,
    "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
    "savefig.dpi": 300, "savefig.bbox": "tight",
})


def save(fig, name):
    for ext in ("pdf", "png"):
        fig.savefig(OUT / f"{name}.{ext}")
    plt.close(fig)


# ---------------------------------------------------------------- Fig. A: main comparison
s = pd.read_csv(HERE / "results_final" / "merged" / "metrics_summary.csv").set_index("method")
order = [("AEHA-res-fixed-delta", "AEHA"), ("Agg-conf-d0.01", "Physics layer (no learning)"),
         ("Agg-target", "Weighted target"), ("Decoupled-MRR", "Decoupled-MRR"),
         ("Hybrid-SAC-Lagr", "Hybrid-SAC (constrained)"), ("Hybrid-SAC", "Hybrid-SAC (published)")]
fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.5), sharey=True, gridspec_kw=dict(wspace=0.08))
y = np.arange(len(order))[::-1]
for ax, (col, lab, lim) in zip(axes, [("sum_rate_geo", "Net sum-rate (Mbps)", (0, 25.5)),
                                      ("qos_geo", "QoS satisfaction (%)", (90, 100))]):
    vals = np.array([s.loc[m, col] for m, _ in order])
    cis = np.array([s.loc[m, col + "_ci95"] for m, _ in order])
    colors = [C["AEHA"] if m == "AEHA-res-fixed-delta" else "#b9b8b1" for m, _ in order]
    ax.barh(y, vals - lim[0], left=lim[0], height=0.62, color=colors, edgecolor="white", linewidth=1.0)
    ax.errorbar(vals, y, xerr=cis, fmt="none", ecolor=INK, elinewidth=0.9, capsize=2.2)
    for yi, v, c_ in zip(y, vals, cis):
        ax.annotate(f"{v:.2f}", (v + c_, yi), xytext=(3, 0), textcoords="offset points",
                    ha="left", va="center", fontsize=6.8, color=INK2, zorder=4,
                    bbox=dict(boxstyle="square,pad=0.1", facecolor="white", edgecolor="none"))
    if col == "qos_geo":
        ax.axvline(99.0, color=INK2, linestyle=(0, (3, 2)), linewidth=0.9)
        ax.text(99.0, len(order) - 0.35, "target", ha="center", va="bottom", fontsize=6.8, color=INK2)
    ax.set_xlim(lim[0], lim[1] + (2.6 if col == "sum_rate_geo" else 0.9))
    ax.set_xlabel(lab)
    ax.grid(axis="y", visible=False)
    ax.tick_params(axis="y", length=0)
axes[0].set_yticks(y, [m[1] for m in order], fontsize=7.5)
save(fig, "fig_main_comparison")

# ---------------------------------------------------------------- Fig. B: rho sweep
r = pd.read_csv(HERE / "results_rho_aware" / "eval" / "rho_summary.csv")
series = [("Decoupled-MRR", "Decoupled-MRR", C["MRR"], "s", (0, (4, 2))),
          ("Agg-conf-d0.01", "Physics layer (no learning)", C["layer"], "D", (0, (1, 1.5))),
          ("AEHA spec. rho=0", r"AEHA trained at $\rho=0$", C["spec0"], "v", (0, (5, 1.5, 1, 1.5))),
          ("AEHA spec. rho=0.08", r"AEHA trained at $\rho=0.08$", C["spec008"], "^", (0, (2.5, 1.5))),
          ("AEHA rho-aware", r"$\rho$-aware AEHA (one model)", C["AEHA"], "o", "solid")]
held_out = [0.01, 0.06, 0.11]
fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9))
for ax, (col, lab) in zip(axes, [("sum_rate_geo", "Net sum-rate (Mbps)"), ("qos_geo", "QoS satisfaction (%)")]):
    for key, name, colr, mk, ls in series:
        g = r[r.method == key].sort_values("rho")
        lw = 2.0 if key == "AEHA rho-aware" else 1.4
        ax.plot(g.rho, g[col], color=colr, linestyle=ls, linewidth=lw, marker=mk, markersize=5.2,
                markeredgecolor="white", markeredgewidth=0.8, label=name, zorder=3 if key == "AEHA rho-aware" else 2)
    for h in held_out:
        ax.axvline(h, color=GRID, linewidth=4, zorder=0)
    ax.set_xlabel(r"Residual-SIC factor $\rho$")
    ax.set_ylabel(lab)
    ax.set_xticks([0, 0.02, 0.04, 0.06, 0.08, 0.11, 0.15])
    if col == "qos_geo":
        ax.axhline(99.0, color=INK2, linestyle=(0, (3, 2)), linewidth=0.9)
        ax.set_ylim(98.2, 99.8)
        ax.text(0.15, 99.03, "target", ha="right", va="bottom", fontsize=7, color=INK2)
axes[0].text(0.06, axes[0].get_ylim()[1] * 0.985, "shaded: held-out $\\rho$", ha="center", va="top", fontsize=6.8, color=INK2)
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc="upper center", ncol=3, fontsize=7.2, bbox_to_anchor=(0.5, -0.02))
save(fig, "fig_rho_sweep")

# ---------------------------------------------------------------- Fig. C: fairness trade-off
p = pd.read_csv(HERE / "results_phase3" / "merged" / "phase3_summary.csv")
phis = [("base", 0.0), ("phi=0.5", 0.5), ("phi=1", 1.0), ("phi=2", 2.0), ("phi=4", 4.0)]
fig, ax = plt.subplots(figsize=(3.6, 2.9))
for key, name, colr, mk, ls in [("AEHA", "AEHA", C["AEHA"], "o", "solid"),
                                 ("Agg-conf-d0.01", "Physics layer", C["layer"], "D", (0, (1, 1.5)))]:
    pts = [(p[(p.setting == st) & (p.method == key)].iloc[0], ph) for st, ph in phis]
    xs = [q.fairness_geo for q, _ in pts]
    ys = [q.sum_rate_geo for q, _ in pts]
    ax.plot(xs, ys, color=colr, linestyle=ls, linewidth=2.0 if key == "AEHA" else 1.4, marker=mk, markersize=5.5,
            markeredgecolor="white", markeredgewidth=0.8, label=name, zorder=3)
    if key == "AEHA":
        for (q, ph), x_, y_ in zip(pts, xs, ys):
            ax.annotate(rf"$\varphi={ph:g}$", (x_, y_), xytext=(5, 2), textcoords="offset points", fontsize=6.8, color=INK2)
m = p[(p.setting == "base") & (p.method == "Decoupled-MRR")].iloc[0]
ax.plot(m.fairness_geo, m.sum_rate_geo, marker="s", markersize=6, color=C["MRR"], linestyle="none", label="Decoupled-MRR")
ax.annotate("MRR", (m.fairness_geo, m.sum_rate_geo), xytext=(-4, -11), textcoords="offset points", fontsize=7, color=INK2, ha="right")
wt = p[(p.setting == "base") & (p.method == "Agg-target")].iloc[0]
ax.plot(wt.fairness_geo, wt.sum_rate_geo, marker="P", markersize=7, color=INK2, linestyle="none", label="Weighted target")
ax.annotate("weighted\ntarget", (wt.fairness_geo, wt.sum_rate_geo), xytext=(4, 4), textcoords="offset points",
            fontsize=6.8, color=INK2, ha="left")
ax.set_xlabel("Jain fairness index")
ax.set_ylabel("Net sum-rate (Mbps)")
ax.legend(loc="upper right", fontsize=7)
save(fig, "fig_fairness_tradeoff")
print("figures written to", OUT)
