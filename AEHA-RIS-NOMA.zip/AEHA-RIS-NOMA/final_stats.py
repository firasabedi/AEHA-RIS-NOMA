"""Paired comparisons of the main method against every other method (final run)."""

import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

out = Path(__file__).resolve().parent / "results_final" / "merged"
raw = pd.read_csv(out / "metrics_raw.csv")
MAIN = sys.argv[1] if len(sys.argv) > 1 else "AEHA-res-fixed-delta"
metrics = ["sum_rate_geo", "qos_geo", "fairness_geo", "sum_rate_mean", "qos_percent"]
main = raw[raw.method == MAIN].set_index("seed")
rows = []
for cmp in dict.fromkeys(raw.method):
    if cmp == MAIN:
        continue
    other = raw[raw.method == cmp].set_index("seed")
    for k in metrics:
        d = (main[k] - other[k]).dropna().values
        n = len(d)
        ci = stats.t.ppf(0.975, n - 1) * d.std(ddof=1) / math.sqrt(n)
        p = stats.ttest_1samp(d, 0.0).pvalue
        w = stats.wilcoxon(d).pvalue if np.any(d != 0) else 1.0
        rows.append(dict(main=MAIN, comparator=cmp, metric=k, n=n, diff=d.mean(), ci95=ci, p_t=p, p_wilcoxon=w))
res = pd.DataFrame(rows)
# Holm correction within each metric across comparators
for k in metrics:
    m = res.metric == k
    order = res[m].p_t.sort_values().index
    adj, running = {}, 0.0
    for i, idx in enumerate(order):
        running = max(running, min(1.0, (len(order) - i) * res.loc[idx, "p_t"]))
        adj[idx] = running
    res.loc[list(adj), "p_holm"] = pd.Series(adj)
res.to_csv(out / f"paired_vs_{MAIN}.csv", index=False)
pd.set_option("display.width", 220)
for k in ("sum_rate_geo", "qos_geo", "fairness_geo"):
    print(f"\n{MAIN} minus comparator, {k}")
    print(res[res.metric == k][["comparator", "diff", "ci95", "p_t", "p_holm", "p_wilcoxon"]].round(4).to_string(index=False))
q = raw[raw.method == MAIN][["seed", "sum_rate_geo", "qos_geo"]]
print(f"\nper-seed {MAIN}: QoS_geo min {q.qos_geo.min():.2f}, seeds >= 99%: {(q.qos_geo >= 99).sum()}/{len(q)}")
for name in ("AEHA-res", "Agg-conf-d0.01", "Decoupled-MRR"):
    g = raw[raw.method == name]
    print(f"per-seed {name}: QoS_geo min {g.qos_geo.min():.2f}, seeds >= 99%: {(g.qos_geo >= 99).sum()}/{len(g)}")
