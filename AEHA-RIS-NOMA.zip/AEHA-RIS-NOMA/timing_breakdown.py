"""Single-process timing breakdown of the AEHA action pipeline (L = 3, 20, 50).

Stages: feature construction (site tokens), actor forward pass, physical
decoder (anchor + conformal QoS-floor power).  Same host/thread cap as the
manuscript (torch threads <= 4).  Run alone for clean numbers.
"""

import sys
import time
from dataclasses import replace
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import aeha  # noqa: E402
import aeha_core as core  # noqa: E402

HERE = Path(__file__).resolve().parent
rx = core.rx
rx.seed_everything(0)
if len(sys.argv) > 1:
    torch.set_num_threads(int(sys.argv[1]))
base = rx.Config(**rx.PROFILES["quick"])
print(f"torch threads: {torch.get_num_threads()}")
for L, path in ((3, "results_rho_aware/seed11/models/AEHA-rho-aware_seed11.pt"),
                (20, "results_rho_aware/seed11/models/AEHA-rho-aware_seed11.pt"),
                (50, "results_rho_aware/seed11/models/AEHA-rho-aware_seed11.pt")):
    cfg = replace(base, n_sites=L)
    agent = aeha.AEHASAC(cfg, aeha.AEHA_VARIANTS["AEHA-rho-aware"])
    agent.actor.load_state_dict(torch.load(HERE / path))
    agent.actor.eval()
    agent.cmodel = core.ConformalGainModel(cfg, 11)
    env = rx.RISNOMAEnv(cfg, 100_011)
    env.reset()
    t_feat, t_actor, t_dec, t_total = [], [], [], []
    for i in range(1500):
        t0 = time.perf_counter_ns()
        tokens, glob = agent.tokens(env)
        s = core.flat_state(tokens, glob)
        t1 = time.perf_counter_ns()
        site_idx, a = agent.actor.act_deterministic(torch.as_tensor(s[None]))
        t2 = time.perf_counter_ns()
        action, _, _ = agent.decode(env, site_idx, a.numpy())
        t3 = time.perf_counter_ns()
        if i >= 100:  # warm-up excluded
            t_feat.append((t1 - t0) / 1e6)
            t_actor.append((t2 - t1) / 1e6)
            t_dec.append((t3 - t2) / 1e6)
            t_total.append((t3 - t0) / 1e6)
        _, _, done, _ = env.step(site_idx, action)
        if done:
            env.reset()
    f = lambda x: f"{np.median(x):.3f} / {np.quantile(x, 0.95):.3f}"  # noqa: E731
    print(f"L={L:2d}  AEHA        median / p95 ms   features {f(t_feat)}   actor {f(t_actor)}   "
          f"decoder {f(t_dec)}   total {f(t_total)}")

    # Published Hybrid-SAC, same scope: observation construction + actor + action mapping.
    sac_path = (HERE / "results_final/A_seed11/models/Hybrid-SAC_seed11.pt" if L == 3 else
                HERE / f"results_phase3_L/L{L}_A_seed11/models/Hybrid-SAC_seed11.pt")
    env = rx.RISNOMAEnv(cfg, 100_011)
    env.reset()
    sac = rx.HybridSAC(env, cfg)
    sac.actor.load_state_dict(torch.load(sac_path))
    sac.actor.eval()
    t_obs, t_act = [], []
    for i in range(1500):
        t0 = time.perf_counter_ns()
        s = env._state()
        t1 = time.perf_counter_ns()
        site_idx, action, _ = sac.act(s, deterministic=True)
        t2 = time.perf_counter_ns()
        if i >= 100:
            t_obs.append((t1 - t0) / 1e6)
            t_act.append((t2 - t1) / 1e6)
        _, _, done, _ = env.step(site_idx, action)
        if done:
            env.reset()
    tot = np.array(t_obs) + np.array(t_act)
    print(f"L={L:2d}  Hybrid-SAC  median / p95 ms   features {f(t_obs)}   actor {f(t_act)}   "
          f"decoder   (in actor)      total {f(tot)}")
