"""How many independent geometries does a reliable violation estimate need?

Reference = 200 independent geometries x 20 steps (4000 steps).  Compared with
the manuscript's evaluation stream (500 consecutive steps, ~3 geometries) and
with candidate validation designs.
"""

import sys
from dataclasses import replace
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import aeha  # noqa: E402
import aeha_core as core  # noqa: E402

cfg = core.rx.Config(**core.rx.PROFILES["quick"])


def multi(pol, seed, base, n_envs, steps):
    c = replace(cfg, eval_steps=steps)
    return float(np.mean([1 - aeha.evaluate(c, seed, pol, env_seed=base + 1000 * k)["qos_percent"] / 100 for k in range(n_envs)]))


for delta in (0.01, 0.08):
    print(f"policy: non-learned layer, delta={delta}   (violation %)")
    print("  seed   eval(500 consec.)   val 5x100   val 25x20   reference 200x20")
    for seed in (11, 22, 33, 44, 55):
        pol = aeha.agg_floor_policy(delta, "conformal", core.ConformalGainModel(cfg, seed))
        ev = 1 - aeha.evaluate(cfg, seed, pol)["qos_percent"] / 100
        v5 = multi(pol, seed, seed + 50_000, 5, 100)
        v25 = multi(pol, seed, seed + 50_000, 25, 20)
        ref = multi(pol, seed, seed + 200_000, 200, 20)
        print(f"  {seed}     {100*ev:6.2f}             {100*v5:6.2f}      {100*v25:6.2f}       {100*ref:6.2f}")
