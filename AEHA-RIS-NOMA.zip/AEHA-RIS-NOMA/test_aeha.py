import math
import unittest
from dataclasses import replace

import numpy as np
import torch

import aeha
import aeha_core as core
from aeha_core import rx
from headroom import metrics, nomarates

CFG = rx.Config(**rx.PROFILES["smoke"])


class AnchorTests(unittest.TestCase):
    def test_vertex_weight_reproduces_decoupled_mrr(self):
        env = rx.RISNOMAEnv(CFG, 3)
        for _ in range(20):
            site, ref = env.heuristic_action("decoupled")
            ch = env._channels
            k = int(np.argmax(np.abs(ch["direct_est"])))
            w = np.eye(CFG.n_users)[k]
            theta = core.anchor_phases(ch["casc_est"][site].astype(np.complex128),
                                       ch["direct_est"].astype(np.complex128), w)
            ref_theta = math.pi * (ref[: CFG.n_ris].astype(np.float64) + 1.0)
            diff = np.angle(np.exp(1j * (theta - ref_theta)))
            self.assertLess(np.abs(diff).max(), 1e-5)
            env.step(site, ref)

    def test_aggregate_weight_reproduces_env_target(self):
        env = rx.RISNOMAEnv(CFG, 4)
        ch = env._channels
        w = core.aggregate_weights(ch["direct_est"].astype(np.complex128))
        for ell in range(CFG.n_sites):
            theta = core.anchor_phases(ch["casc_est"][ell].astype(np.complex128),
                                       ch["direct_est"].astype(np.complex128), w)
            diff = np.angle(np.exp(1j * (theta - ch["target_phase"][ell])))
            self.assertLess(np.abs(diff).max(), 1e-4)


class PowerLayerTests(unittest.TestCase):
    def test_floor_met_on_estimated_channel_when_feasible(self):
        rng = np.random.default_rng(0)
        met = 0
        for _ in range(500):
            g = rng.exponential(2.0, CFG.n_users)
            for m in (0.0, 0.5, 2.0):
                p = core.qos_floor_power(g, CFG, m)
                self.assertTrue(np.all(p >= -1e-12))
                self.assertLessEqual(p.sum(), CFG.p_max + 1e-9)
                r = nomarates(g, g, p, CFG)
                served = p > 0
                # nomarates returns rates in estimated weak->strong order.
                # Contract: served users always meet r_min; they meet r_min*(1+m)
                # whenever that margin is feasible (otherwise it is relaxed).
                served_sorted = served[np.argsort(g)]
                self.assertTrue(np.all(r[served_sorted] >= CFG.min_rate_mbps - 1e-6), (g, m, p, r))
                if served.all() and r.min() < CFG.min_rate_mbps * (1 + m) - 1e-6:
                    self.assertGreater(m, 0.0)
                met += int(served.all())
        self.assertGreater(met, 0)

    def test_budget_fully_used_when_feasible(self):
        g = np.array([0.5, 2.0, 8.0])
        p = core.qos_floor_power(g, CFG, 0.5)
        self.assertAlmostEqual(p.sum(), CFG.p_max, places=9)
        # Floor users: the weaker one needs more power; the strongest takes the remainder.
        self.assertGreater(p[0], p[1])
        self.assertEqual(int(np.argmax(p)), 2)


class ConformalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cfg = rx.Config(**rx.PROFILES["quick"])
        cls.cm = core.ConformalGainModel(cls.cfg, seed=7, steps=800)

    def test_lower_bound_monotone_in_delta(self):
        g = np.array([0.3, 3.0, 40.0])
        prev = np.zeros(3)
        for d in (0.005, 0.01, 0.05, 0.1, 0.3, 0.5):
            cur = self.cm.lower(g, d)
            self.assertTrue(np.all(cur >= prev - 1e-12))
            prev = cur

    def test_heldout_coverage_reasonable(self):
        cm2 = core.ConformalGainModel(self.cfg, seed=8, steps=400, rng_seed=5)  # held-out stream
        ratios = np.concatenate(cm2.ratios)
        # build (g_est, g_true) pairs from the held-out ratios using bin-representative g_est
        reps = 10 ** np.concatenate([[cm2.edges[0] - 0.1], (cm2.edges[:-1] + cm2.edges[1:]) / 2, [cm2.edges[-1] + 0.1]])
        g_est = np.concatenate([np.full(len(r), reps[i]) for i, r in enumerate(cm2.ratios)])
        g_true = g_est * ratios
        miss = np.mean(g_true < self.cm.lower(g_est, 0.05))
        self.assertLess(miss, 0.15)

    def test_conformal_floor_valid(self):
        rng = np.random.default_rng(1)
        for _ in range(100):
            g = rng.exponential(5.0, self.cfg.n_users)
            p = core.conformal_floor_power(g, self.cfg, 0.01, self.cm)
            self.assertTrue(np.all(p >= -1e-12))
            self.assertAlmostEqual(p.sum(), self.cfg.p_max, places=6)


class DualControllerTests(unittest.TestCase):
    def test_pi_controller_rises_and_has_antiwindup(self):
        lo = aeha.LagrangeOptions()
        d = aeha.DualController(lo, 3)
        lams = []
        for i in range(10):
            d.on_validation(0.05, i)  # persistent 5% violations > 1% target
            lams.append(d.lam)
        self.assertTrue(all(b > a for a, b in zip(lams, lams[1:])))
        for i in range(100):
            d.on_validation(0.0, i)  # constraint over-satisfied for a long time
        self.assertEqual(d.integral, 0.0)
        self.assertGreaterEqual(d.lam, 0.0)
        self.assertLessEqual(d.lam, lo.lam_max)

    def test_step_mode_unchanged(self):
        d = aeha.DualController(aeha.LagrangeOptions(mode="step"), 3)
        d.on_step(3.0)
        self.assertAlmostEqual(d.lam, 2.0 + 0.05 * (1.0 - 0.01))


class Phase3KnobTests(unittest.TestCase):
    def test_quantization_matches_simulator(self):
        env = rx.RISNOMAEnv(CFG, 12)
        w = np.array([0.3, 0.3, 0.4])
        for bits in (1, 2):
            action = core.decode_action(env, 0, w, 0.7, power_mode="floor", phase_bits=bits)
            info = env.evaluate_action(0, action, phase_bits=bits)
            theta_dec = math.pi * (action[: CFG.n_ris] + 1.0)
            np.testing.assert_allclose(np.angle(np.exp(1j * (info["phases"] - theta_dec))), 0.0, atol=1e-6)

    def test_fairness_floor_raises_weakest_rate(self):
        cfg = rx.Config(**rx.PROFILES["quick"])
        cm = core.ConformalGainModel(cfg, seed=7, steps=400)
        # Contract: where the raised floor is feasible on the lower-bound gains,
        # every user's rate on those gains is >= R_min (1 + phi) and the budget is used.
        # (Where it is infeasible, phi is lowered to the largest feasible value;
        # the strongest user then sits exactly at its own floor.)
        checked = 0
        for g in (np.array([3.0, 8.0, 40.0]), np.array([5.0, 20.0, 60.0])):
            order = np.argsort(g)
            g_lo = cm.lower(g, 0.01)
            for phi in (0.0, 0.5, 1.0):
                if core.qos_floor_power(g_lo, cfg, phi, order=order, allow_relax=False) is None:
                    continue
                p = core.conformal_floor_power(g, cfg, 0.01, cm, phi=phi)
                self.assertAlmostEqual(p.sum(), cfg.p_max, places=6)
                r = nomarates(g_lo, g, p, cfg)  # gains = lower bounds, SIC order = estimated
                self.assertGreaterEqual(r.min(), cfg.min_rate_mbps * (1 + phi) - 1e-6, (g, phi, p, r))
                checked += 1
        self.assertGreater(checked, 0)


class PublishedReplicaTests(unittest.TestCase):
    def test_replica_matches_original_trainers(self):
        cfg = replace(CFG, train_steps=250, warmup_steps=64, batch_size=32)
        for algo, orig in (("sac", rx.train_sac), ("ddpg", rx.train_ddpg)):
            a1, l1 = orig(cfg, 3)
            a2, l2 = aeha.train_published(cfg, 3, algo)
            for p1, p2 in zip(a1.actor.parameters(), a2.actor.parameters()):
                torch.testing.assert_close(p1, p2, rtol=0, atol=0)
            self.assertEqual(l1["reward_curve"], l2["reward_curve"])
            self.assertEqual(len(l2["sum_rate_curve"]), 2)


class SeedLayoutTests(unittest.TestCase):
    def test_calibration_streams_disjoint_from_all_evaluation_streams(self):
        for seed in (11, 55, 110):
            calib = {seed + core.ConformalGainModel.CALIB_OFFSET + 1000 * k for k in range(100)}
            evals = {seed + 200_000 + 1000 * k for k in range(200)} | {seed + 100_000}
            val = {seed + 50_000 + 1000 * k for k in range(25)} | {seed}
            self.assertFalse(calib & evals)
            self.assertFalse(calib & val)
            self.assertFalse(evals & val)


class FastPathTests(unittest.TestCase):
    def test_vectorized_tokens_match_per_site_reference(self):
        for L in (3, 20):
            cfg = replace(CFG, n_sites=L)
            env = rx.RISNOMAEnv(cfg, 4)
            env.previous_site = L - 1
            tokens, _ = core.site_tokens(env)
            ch = env._channels
            d = ch["direct_est"].astype(np.complex128)
            W = np.vstack([np.eye(cfg.n_users), core.aggregate_weights(d)[None]])
            for ell in range(L):
                ce = ch["casc_est"][ell].astype(np.complex128)
                g = core.anchored_gains(d, ce, core.anchor_phases(ce, d, W))
                ref = (np.log1p(g / cfg.noise_power) / 10.0).ravel()
                np.testing.assert_allclose(tokens[ell, : ref.size], ref, rtol=1e-5, atol=1e-6)
            self.assertEqual(tokens[L - 1, ref.size + 1], 1.0)

    def test_lean_actor_matches_sample_deterministic(self):
        for opts in (aeha.AEHAOptions(residual=True), aeha.AEHAOptions(), aeha.AEHAOptions(learn_site=False)):
            cfg = replace(CFG, n_sites=5)
            agent = aeha.AEHASAC(cfg, opts)
            for p in agent.actor.parameters():  # non-trivial weights even for zero-init heads
                torch.nn.init.normal_(p, std=0.3)
            s = torch.randn(1, agent.state_dim)
            site, a, _ = agent.actor.sample(s, 0.8, deterministic=True)
            idx, a2 = agent.actor.act_deterministic(s)
            self.assertEqual(idx, int(site[0].argmax()))
            torch.testing.assert_close(a2, a[0])


class RhoAwareTests(unittest.TestCase):
    def test_rho_feature_appended(self):
        cfg = replace(CFG, residual_sic=0.06)
        env = rx.RISNOMAEnv(cfg, 3)
        t0, g0 = core.site_tokens(env)
        t1, g1 = core.site_tokens(env, rho_feature=True)
        np.testing.assert_array_equal(t0, t1)
        self.assertEqual(len(g1), len(g0) + 1)
        self.assertAlmostEqual(float(g1[-1]), 0.06 / core.RHO_SCALE, places=6)
        self.assertEqual(core.token_dims(cfg, True)[1], len(g1))

    def test_rho_sampled_training_runs(self):
        cfg = replace(CFG, train_steps=300, warmup_steps=64, batch_size=32, eval_steps=40)
        opts = aeha.AEHAOptions(residual=True, learn_m=False, rho_aware=True, rho_train=(0.0, 0.15))
        lo = aeha.LagrangeOptions(val_every=100, val_envs=4, val_steps=10)
        agent, log = aeha.train_aeha(cfg, 2, opts, lo)
        self.assertEqual(len(log["dual_history"]), 3)
        for rho in (0.0, 0.15):
            m = aeha.evaluate(replace(cfg, residual_sic=rho), 2, aeha.aeha_policy(agent))
            self.assertTrue(np.isfinite(m["sum_rate_mean"]))


class DecodeTests(unittest.TestCase):
    def test_action_roundtrip_through_simulator(self):
        env = rx.RISNOMAEnv(CFG, 5)
        w = np.array([0.2, 0.5, 0.3])
        action = core.decode_action(env, 1, w, 0.7, power_mode="floor")
        info = env.evaluate_action(1, action)
        ch = env._channels
        theta = core.anchor_phases(ch["casc_est"][1].astype(np.complex128), ch["direct_est"].astype(np.complex128), w)
        g = core.anchored_gains(ch["direct_est"].astype(np.complex128), ch["casc_est"][1].astype(np.complex128), theta)
        p = core.qos_floor_power(g, CFG, 0.7)
        np.testing.assert_allclose(info["powers"], p / p.sum() * CFG.p_max, atol=1e-9)
        np.testing.assert_allclose(np.angle(np.exp(1j * (info["phases"] - theta))), 0.0, atol=1e-9)


class ScalingTests(unittest.TestCase):
    def test_actor_parameters_independent_of_L_and_N(self):
        counts = set()
        for L in (3, 20, 50):
            for N in (32, 64, 128):
                cfg = replace(CFG, n_sites=L, n_ris=N)
                agent = aeha.AEHASAC(cfg, aeha.AEHAOptions())
                counts.add(sum(p.numel() for p in agent.actor.parameters()))
        self.assertEqual(len(counts), 1)

    def test_site_permutation_equivariance(self):
        cfg = replace(CFG, n_sites=5)
        agent = aeha.AEHASAC(cfg, aeha.AEHAOptions())
        sd, gd = core.token_dims(cfg)
        s = torch.randn(4, 5 * sd + gd)
        perm = torch.tensor([3, 0, 4, 1, 2])
        tok = s[:, : 5 * sd].view(4, 5, sd)
        sp = torch.cat([tok[:, perm].reshape(4, -1), s[:, 5 * sd :]], -1)
        e, _ = agent.actor.enc(s)
        ep, _ = agent.actor.enc(sp)
        lg = agent.actor.site_head(e).squeeze(-1)
        lgp = agent.actor.site_head(ep).squeeze(-1)
        torch.testing.assert_close(lg[:, perm], lgp)

    def test_residual_init_equals_nonlearned_layer(self):
        cfg = rx.Config(**rx.PROFILES["quick"])
        agent = aeha.AEHASAC(cfg, aeha.AEHAOptions(residual=True))
        agent.cmodel = core.ConformalGainModel(cfg, seed=7, steps=400)
        ref = aeha.agg_floor_policy(0.01, "conformal", agent.cmodel)
        env = rx.RISNOMAEnv(cfg, 9)
        for _ in range(30):
            s_a, a_a, _ = agent.act(env, deterministic=True)
            s_r, a_r = ref(env)
            self.assertEqual(s_a, s_r)
            np.testing.assert_allclose(a_a, a_r, atol=1e-6)  # softmax(log w) round-off only
            env.step(s_r, a_r)

    def test_smoke_training_runs(self):
        cfg = replace(CFG, train_steps=200, warmup_steps=64, batch_size=32, eval_steps=50)
        agent, log = aeha.train_aeha(cfg, 1, aeha.AEHAOptions(), aeha.LagrangeOptions())
        m = aeha.evaluate(cfg, 1, aeha.aeha_policy(agent))
        self.assertTrue(np.isfinite(m["sum_rate_mean"]))


if __name__ == "__main__":
    unittest.main()
