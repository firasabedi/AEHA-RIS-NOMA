"""Re-evaluate conformal-floor methods after the calibration-seed fix.

The conformal calibration streams previously overlapped half of the
200-geometry evaluation streams.  Trained models are unaffected (training
never touched evaluation streams), so each saved model is re-loaded, the
conformal model is re-fitted on the now-disjoint calibration seeds, and both
metrics are recomputed.  Rows of non-conformal methods are left unchanged.

Usage: python reeval_conformal.py results_final/B_seed11 [more dirs ...]
"""

import json
import sys
from pathlib import Path

import pandas as pd
import torch

import aeha
import aeha_core as core
from aeha_core import rx

HERE = Path(__file__).resolve().parent


def policy_for(name, cfg, seed, d: Path):
    cm = core.ConformalGainModel(cfg, seed)
    if name.startswith("Agg-conf-d"):
        return aeha.agg_floor_policy(float(name.split("-d")[1]), "conformal", cm)
    opts = aeha.AEHA_VARIANTS.get(name)
    if opts is None or opts.power_mode != "conformal":
        return None
    agent = aeha.AEHASAC(cfg, opts)
    agent.actor.load_state_dict(torch.load(d / "models" / f"{name}_seed{seed}.pt"))
    agent.actor.eval()
    agent.cmodel = cm
    return aeha.aeha_policy(agent)


def reeval(d: Path):
    man = json.loads((d / "run_manifest.json").read_text(encoding="utf-8"))
    cfg = rx.Config(**man["config"])
    raw = pd.read_csv(d / "metrics_raw.csv")
    changed = 0
    for i, row in raw.iterrows():
        pol = policy_for(row.method, cfg, int(row.seed), d)
        if pol is None:
            continue
        m = aeha.evaluate(cfg, int(row.seed), pol)
        m.update(aeha.evaluate_geometries(cfg, int(row.seed), pol))
        for k, v in m.items():
            raw.at[i, k] = v
        changed += 1
        print(f"{d.name} {row.method:22s} geo sum {m['sum_rate_geo']:.3f} QoS {m['qos_geo']:.2f}", flush=True)
    raw.to_csv(d / "metrics_raw.csv", index=False)
    (d / "REEVAL_NOTE.txt").write_text(
        f"{changed} conformal rows re-evaluated with calibration offset "
        f"{core.ConformalGainModel.CALIB_OFFSET} (disjoint from evaluation streams).\n", encoding="utf-8")


if __name__ == "__main__":
    for arg in sys.argv[1:]:
        reeval(HERE / arg)
