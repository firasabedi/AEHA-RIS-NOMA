"""Physics layers of the Anchored Equivariant Hybrid Actor (AEHA).

Three pieces, all computed from *estimated* CSI only:

* ``site_tokens``      -- per-site features that are independent of the number
                          of RIS elements N (the sum over elements is done by
                          the closed-form anchor, not by the network);
* ``anchor_phases``    -- learnable-weight MRR anchor
                          theta_n = -arg(sum_k w_k g_{l,k,n} conj(h_{d,k}));
                          w = e_strongest reproduces Decoupled-MRR exactly;
* ``qos_floor_power``  -- CSI-robust QoS-floor NOMA power layer: every user is
                          given the minimum power that meets r_min * (1 + m)
                          on the estimated anchored channel under the
                          simulator's SIC model (residual rho, estimated
                          order); the remaining budget goes to the
                          strongest (last-decoded) user.  Users that cannot be
                          served within P_max are dropped weakest-first.
"""

from __future__ import annotations

import math
import os
import sys
from pathlib import Path

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import numpy as np

REPO = Path(__file__).resolve().parent / "simulator"  # bundled copy (released package)
if not (REPO / "ris_noma_experiments.py").exists():
    REPO = (
        Path(__file__).resolve().parents[1]
        / "Hybrid-SAC-RIS-NOMA-Code-main"
        / "Hybrid-SAC-RIS-NOMA-Code-main"
        / "Hybrid-SAC-RIS-NOMA-Code"
        / "Hybrid-SAC-RIS-NOMA-Code"
    )
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))
import ris_noma_experiments as rx  # noqa: E402,F401

SITE_FEAT_EXTRA = 3  # site score, previous-site flag, (unused slot kept 0 for alignment)


RHO_SCALE = 0.15  # normalisation of the residual-SIC feature (rho-aware policies)


def token_dims(cfg, rho_feature=False):
    K = cfg.n_users
    site_dim = (K + 1) * K + SITE_FEAT_EXTRA + K  # anchored gains, extras, site-user offsets
    global_dim = 3 * K + (1 if rho_feature else 0)
    return site_dim, global_dim


def anchor_phases(casc_l, d_est, w):
    """Learnable-weight MRR anchor.  casc_l (K,N), d_est (K,), w (...,K) -> (...,N) in [0, 2pi)."""
    agg = np.einsum("...k,kn->...n", w, casc_l * np.conj(d_est)[:, None])
    return np.mod(-np.angle(agg), 2.0 * math.pi)


def anchored_gains(d, casc_l, theta):
    """|h_d + sum_n g_n e^{j theta_n}|^2; theta (...,N) -> (...,K)."""
    refl = np.einsum("kn,...n->...k", casc_l, np.exp(1j * theta))
    return np.abs(d + refl) ** 2


def aggregate_weights(d_est):
    """The simulator's own target weighting (w proportional to 1/|h_d|)."""
    w = 1.0 / np.maximum(np.abs(d_est), 0.1)
    return w / w.sum()


def site_tokens(env, rho_feature=False):
    """Per-site tokens (L, site_dim) and global features (global_dim,).

    For every site the token holds the estimated anchored gains of all users
    under the K vertex anchors (one per user) and the aggregate anchor, so the
    network sees the physical consequence of each candidate weighting without
    ever ingesting the N-element phase vector.  With ``rho_feature`` the
    deployment's residual-SIC level (a known receiver parameter) is appended
    to the global features.
    """
    c = env.cfg
    ch = env._channels
    K, L = c.n_users, c.n_sites
    d_est = ch["direct_est"].astype(np.complex128)
    casc_est = ch["casc_est"].astype(np.complex128)  # (L, K, N)
    W = np.vstack([np.eye(K), aggregate_weights(d_est)[None]])  # (K+1, K)
    sched = ch["scheduled"]
    upos = env.positions[sched] / c.road_length_m
    score = ch["site_score"] / max(float(ch["site_score"].max()), 1e-9)
    # All sites at once (identical to applying anchor_phases/anchored_gains per site).
    agg = np.einsum("mk,lkn->lmn", W, casc_est * np.conj(d_est)[None, :, None])  # (L, K+1, N)
    theta = np.mod(-np.angle(agg), 2.0 * math.pi)
    refl = np.einsum("lkn,lmn->lmk", casc_est, np.exp(1j * theta))  # (L, K+1, K)
    g = np.abs(d_est[None, None, :] + refl) ** 2
    feats = (np.log1p(g / c.noise_power) / 10.0).reshape(L, -1)
    prev = np.zeros(L)
    prev[env.previous_site] = 1.0
    extra = np.stack([score, prev, np.zeros(L)], axis=1)
    offs = (env.site_x / c.road_length_m)[:, None] - upos[None, :]
    tokens = np.concatenate([feats, extra, offs], axis=1).astype(np.float32)
    glob = np.concatenate(
        [
            np.log1p(np.abs(d_est) ** 2 / c.noise_power) / 10.0,
            upos,
            env.velocities[sched] / 130.0,
        ]
        + ([[c.residual_sic / RHO_SCALE]] if rho_feature else [])
    ).astype(np.float32)
    return tokens, glob


def flat_state(tokens, glob):
    return np.concatenate([tokens.ravel(), glob]).astype(np.float32)


def sinr_target(cfg, rate_mbps, include_pilot=True):
    payload = cfg.payload_fraction if include_pilot else 1.0
    return 2.0 ** (rate_mbps / (payload * cfg.bandwidth_mhz)) - 1.0


def effective_error_var(cfg):
    """Variance of the anchored effective-channel estimation error.

    Direct link: CN(0, v); each cascaded element: CN(0, v/N); with unit-modulus
    phases the reflected error sums to CN(0, v).  Total 2v (statistical CSI).
    """
    return 2.0 * cfg.csi_error_var


def rician_quantile_gain(g_est, sigma2, delta, beta=1.0):
    """delta-quantile of |h|^2 for h ~ CN(beta * h_est, sigma2), |h_est|^2 = g_est.

    2|h|^2/sigma2 is noncentral chi-square with 2 dof and non-centrality
    2 beta^2 g_est / sigma2, so P(|h|^2 >= returned value) = 1 - delta.
    """
    from scipy.stats import ncx2

    nc = 2.0 * beta**2 * np.asarray(g_est, dtype=np.float64) / sigma2
    return np.maximum(0.5 * sigma2 * ncx2.ppf(delta, 2, nc), 1e-12)


def calibrate_error_model(cfg, seed, steps=400, rng_seed=0):
    """Fit h_true ~ beta * h_est + CN(0, sigma2) for *anchored* channels.

    The anchor aligns with the estimation noise, so the anchored estimate is
    biased upward; a shrinkage beta and the residual variance are fitted
    offline on the training-seed channel stream (never the evaluation stream)
    over random sites and random Dirichlet anchor weights.
    """
    env = rx.RISNOMAEnv(cfg, seed)
    env.reset()
    rng = np.random.default_rng(rng_seed)
    he_all, ht_all = [], []
    for _ in range(steps):
        ch = env._channels
        site = int(rng.integers(cfg.n_sites))
        w = rng.dirichlet(np.ones(cfg.n_users))
        d_est = ch["direct_est"].astype(np.complex128)
        ce = ch["casc_est"][site].astype(np.complex128)
        theta = anchor_phases(ce, d_est, w)
        ph = np.exp(1j * theta)
        he_all.append(d_est + ce @ ph)
        ht_all.append(ch["direct_true"].astype(np.complex128) + ch["cascaded"][site].astype(np.complex128) @ ph)
        site_h, act = env.heuristic_action("decoupled")
        _, _, done, _ = env.step(site_h, act)
        if done:
            env.reset()
    he, ht = np.concatenate(he_all), np.concatenate(ht_all)
    beta = float(np.real(np.vdot(he, ht)) / np.vdot(he, he).real)
    sigma2 = float(np.mean(np.abs(ht - beta * he) ** 2))
    return dict(beta=beta, sigma2=sigma2)


class ConformalGainModel:
    """Split-conformal lower bound on the anchored gain.

    Calibrated on simulator geometries disjoint from validation/evaluation:
    for random sites and Dirichlet anchor weights, the ratios g_true / g_est are binned by log10(g_est)
    (equal-count bins).  ``lower(g, delta)`` returns g times the
    floor((n+1) delta)-th smallest ratio of g's bin, so for exchangeable data
    P(g_true >= lower) >= 1 - delta within each bin (marginal guarantee; it
    does not cover the selection bias of a policy that maximises over
    actions, which the learned risk level must absorb).
    """

    # Env-seed layout (k = stream index, seed < 1000):
    #   training: seed | validation: seed+50000+1000k (k<25) | 500-step eval: seed+100000
    #   200-geometry eval: seed+200000+1000k (k<200, i.e. up to +399000)
    #   calibration: seed+600000+1000k (k<100)  -- disjoint from all of the above.
    # (An earlier offset of +300000 overlapped geometry-eval streams k>=100; fixed 2026-10-11.)
    CALIB_OFFSET = 600_000

    def __init__(self, cfg, seed, steps=2000, n_bins=8, rng_seed=0, n_envs=100):
        # Calibration geometries: n_envs independent simulator streams; geometry
        # is frozen for 100 steps, so many short streams are used instead of one long one.
        rng = np.random.default_rng(rng_seed)
        ge_all, gt_all = [], []
        per_env = max(1, steps // n_envs)
        for k in range(n_envs):
            env = rx.RISNOMAEnv(cfg, seed + self.CALIB_OFFSET + 1000 * k)
            env.reset()
            for _ in range(per_env):
                ch = env._channels
                site = int(rng.integers(cfg.n_sites))
                w = rng.dirichlet(np.ones(cfg.n_users))
                d_est = ch["direct_est"].astype(np.complex128)
                ce = ch["casc_est"][site].astype(np.complex128)
                ph = np.exp(1j * anchor_phases(ce, d_est, w))
                ge_all.append(np.abs(d_est + ce @ ph) ** 2)
                gt_all.append(np.abs(ch["direct_true"].astype(np.complex128) + ch["cascaded"][site].astype(np.complex128) @ ph) ** 2)
                s, a = env.heuristic_action("decoupled")
                env.step(s, a)
        ge, gt = np.concatenate(ge_all), np.concatenate(gt_all)
        lg = np.log10(np.maximum(ge, 1e-12))
        self.edges = np.quantile(lg, np.linspace(0, 1, n_bins + 1))[1:-1]
        b = np.searchsorted(self.edges, lg)
        self.ratios = [np.sort(gt[b == i] / np.maximum(ge[b == i], 1e-12)) for i in range(n_bins)]

    def lower(self, g_est, delta):
        g = np.asarray(g_est, dtype=np.float64)
        b = np.searchsorted(self.edges, np.log10(np.maximum(g, 1e-12)))
        q = np.array([r[k] if k >= 0 else 0.0
                      for r in self.ratios
                      for k in [int(math.floor((len(r) + 1) * delta)) - 1]])
        return np.maximum(g * q[b], 1e-12)


def conformal_floor_power(g_est, cfg, delta, cmodel: ConformalGainModel, rho=None, phi=0.0):
    """QoS-floor power on conformal lower-bound gains at risk level delta.

    ``phi`` raises the common rate floor to r_min * (1 + phi) for every user
    (fairness knob: more of the budget goes to the weaker users; phi -> max
    feasible approaches max-min rate).  If the raised floor is infeasible,
    the largest feasible phi in [0, phi] is used.  Order stays the estimated
    one.  If infeasible at delta, delta is relaxed by bisection (log scale)
    up to 0.5 (the conditional median ratio); if still infeasible the
    nominal floor with user dropping is used.
    """
    order = np.argsort(g_est)

    def at(d, ph=0.0):
        return qos_floor_power(cmodel.lower(g_est, d), cfg, ph, rho, order=order, allow_relax=False)

    if phi > 0:
        p = at(delta, phi)
        if p is not None:
            return p
        if at(delta, 0.0) is not None:
            lo, hi = 0.0, phi  # lo feasible, hi infeasible
            for _ in range(12):
                mid = 0.5 * (lo + hi)
                lo, hi = (mid, hi) if at(delta, mid) is not None else (lo, mid)
            return at(delta, lo)
    p = at(delta)
    if p is not None:
        return p
    if at(0.5) is not None:
        lo, hi = math.log(delta), math.log(0.5)
        for _ in range(10):
            mid = 0.5 * (lo + hi)
            lo, hi = (lo, mid) if at(math.exp(mid)) is not None else (mid, hi)
        return at(math.exp(hi))
    return qos_floor_power(cmodel.lower(g_est, 0.5), cfg, 0.0, rho, order=order)


def chance_floor_power(g_est, cfg, delta, rho=None, model=None):
    """Rician chance-constrained QoS-floor power layer.

    Floors are computed on the delta-quantile gains (each user's own-receiver
    rate >= r_min with probability ~ 1 - delta); the SIC order stays the
    estimated one, which the quantile map preserves.  If infeasible at delta,
    the risk is relaxed by bisection in log-delta up to 0.5, then the nominal
    floor is used, and only then is the weakest user dropped (inside
    ``qos_floor_power``).
    """
    model = model or dict(beta=1.0, sigma2=effective_error_var(cfg))

    def try_delta(d):
        g_rob = rician_quantile_gain(g_est, model["sigma2"], d, model["beta"])
        p = qos_floor_power(g_rob, cfg, 0.0, rho, order=np.argsort(g_est), allow_relax=False)
        return p

    p = try_delta(delta)
    if p is not None:
        return p
    if try_delta(0.5) is not None:
        lo, hi = math.log(delta), math.log(0.5)  # lo infeasible, hi feasible
        for _ in range(10):
            mid = 0.5 * (lo + hi)
            lo, hi = (lo, mid) if try_delta(math.exp(mid)) is not None else (mid, hi)
        return try_delta(math.exp(hi))
    return qos_floor_power(rician_quantile_gain(g_est, model["sigma2"], 0.5, model["beta"]), cfg, 0.0, rho,
                           order=np.argsort(g_est))


def qos_floor_power(g_est, cfg, margin, rho=None, order=None, allow_relax=True):
    """CSI-robust QoS-floor power allocation on estimated anchored gains.

    Returns powers (K,) summing to P_max.  Under the estimated order
    (weak -> strong) the SIC-feasibility minimum over decoders is attained at
    the user's own receiver, so for every active rank r except the last
        p_r - gamma * (sum_{j>r} p_j + rho * sum_{j<r} p_j) = gamma * sigma^2 / g_r
    holds with equality, and the last (strongest) user takes the remainder
    (sum p = P_max).  This is a K x K linear system, solved exactly; the
    allocation is accepted if the strongest user's own floor also holds.
    Graceful degradation: if the floor at margin m is infeasible, the largest
    feasible margin in [0, m] is found by bisection; only if even the plain
    r_min floor is infeasible is the weakest active user dropped.
    """
    rho = cfg.residual_sic if rho is None else rho
    K = len(g_est)
    if order is None:
        order = np.argsort(g_est)  # weak -> strong, same rule as the simulator
    gs = np.maximum(np.asarray(g_est)[order], 1e-12)

    def solve(idx, m):
        gamma = sinr_target(cfg, cfg.min_rate_mbps * (1.0 + m))
        n = len(idx)
        A = np.zeros((n, n))
        b = np.zeros(n)
        for i in range(n - 1):
            A[i, i] = 1.0
            A[i, i + 1 :] = -gamma
            A[i, :i] = -gamma * rho
            b[i] = gamma * cfg.noise_power / gs[idx[i]]
        A[n - 1, :] = 1.0
        b[n - 1] = cfg.p_max
        sol = np.linalg.solve(A, b)
        need_top = gamma * (rho * sol[:-1].sum() + cfg.noise_power / gs[idx[-1]])
        return sol if (np.all(sol >= 0) and sol[-1] >= need_top) else None

    if not allow_relax:  # strict: full user set at this margin, or None
        sol = solve(np.arange(K), margin)
        if sol is None:
            return None
        out = np.zeros(K)
        out[order] = sol
        return out

    active = np.ones(K, dtype=bool)
    p = np.zeros(K)
    while active.any():
        idx = np.flatnonzero(active)
        sol = solve(idx, margin)
        if sol is None and margin > 0 and solve(idx, 0.0) is not None:
            lo, hi = 0.0, margin
            for _ in range(12):
                mid = 0.5 * (lo + hi)
                lo, hi = (mid, hi) if solve(idx, mid) is not None else (lo, mid)
            sol = solve(idx, lo)
        if sol is not None:
            p = np.zeros(K)
            p[idx] = sol
            break
        active[idx[0]] = False  # even the plain floor is infeasible: drop the weakest
    else:
        p = np.zeros(K)
        p[K - 1] = cfg.p_max  # nobody servable: all power to the strongest
    out = np.zeros(K)
    out[order] = p
    return out


def quantize_phases(theta, bits):
    """Same projection as RISNOMAEnv.evaluate_action (round to nearest level)."""
    levels = 2**bits
    return (2.0 * math.pi / levels) * np.mod(np.floor(levels * theta / (2.0 * math.pi) + 0.5), levels)


def decode_action(env, site, w, risk, power_mode="conformal", power_logits=None, cmodel=None,
                  phase_bits=None, phi=0.0):
    """Map (site, w, risk) to the simulator's continuous action vector.

    ``risk`` is the conformal risk level delta (power_mode "conformal") or the
    rate margin m (power_mode "floor").  ``phase_bits`` makes the decoder
    quantization-aware (gains and power floors are computed on the phases
    the hardware will actually apply); ``phi`` is the fairness floor knob.
    """
    c = env.cfg
    ch = env._channels
    d_est = ch["direct_est"].astype(np.complex128)
    casc_l = ch["casc_est"][site].astype(np.complex128)
    theta = anchor_phases(casc_l, d_est, np.asarray(w, dtype=np.float64))
    if phase_bits is not None:
        theta = quantize_phases(theta, phase_bits)
    if power_mode in ("floor", "conformal"):
        g = anchored_gains(d_est, casc_l, theta)
        if power_mode == "floor":
            p = qos_floor_power(g, c, risk)
        else:
            p = conformal_floor_power(g, c, risk, cmodel, phi=phi)
        logits = np.log(np.maximum(p, 1e-12))
    else:  # unconstrained softmax power (ablation)
        logits = np.asarray(power_logits, dtype=np.float64)
    action = np.concatenate([theta / math.pi - 1.0, logits]).astype(np.float64)
    return action
