"""Test-time scenario suite with ALL compared methods (10 seeds, no retraining).

Methods: Decoupled-MRR, Fixed-site, Weighted target (Agg-target), Physics layer
(Agg-conf-d0.01), Hybrid-SAC and DDPG-Hybrid (published settings),
Hybrid-SAC (constrained), AEHA (+ quantization-aware decoder, + rho-aware model).
Models: results_final/B_seed* (AEHA, constrained Hybrid-SAC) and
results_final/P_seed* (published Hybrid-SAC, DDPG-Hybrid); rho-aware models
from results_rho_aware (seeds 11-55).

Scenario groups (mirroring the baseline paper, extended):
  quantization  continuous / 2-bit / 1-bit
  impairments   ideal / pilot-only / pilot+imperfect SIC  (rate accounting, same actions)
  rho           residual-SIC factor known to the controller, 0 ... 0.15
  csi           CSI-error variance 0.02 / 0.05 / 0.10
  size          zero-shot L, N_r, K (only size-independent policies)
  fairness      floor parameter phi (AEHA, physics layer)
Both metrics (500-interval stream, 200-geometry) are recorded.

Usage:  python scenarios.py --seeds 11,22 --out results_scen_eval/s11_22
        python scenarios.py --summarize results_scen_eval/s11_22,...
"""

from __future__ import annotations

import argparse
import time
from dataclasses import replace
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from scipy import stats

import aeha
import aeha_core as core
from aeha_core import rx

HERE = Path(__file__).resolve().parent
FINAL = HERE / "results_final"
RHO_AWARE = HERE / "results_rho_aware"

# name -> (group, cfg overrides, controller knobs, evaluation-accounting kwargs)
SETTINGS = {"base": ("base", {}, {}, {})}
SETTINGS.update({
    "2-bit": ("quantization", {}, dict(phase_bits=2), dict(phase_bits=2)),
    "1-bit": ("quantization", {}, dict(phase_bits=1), dict(phase_bits=1)),
    "ideal": ("impairments", {}, {}, dict(include_pilot=False, residual_sic=0.0)),
    "pilot-only": ("impairments", {}, {}, dict(include_pilot=True, residual_sic=0.0)),
})
for r in (0.0, 0.01, 0.02, 0.04, 0.06, 0.11, 0.15):
    SETTINGS[f"rho={r:g}"] = ("rho", dict(residual_sic=r), {}, {})
for v in (0.02, 0.10):
    SETTINGS[f"csi={v:g}"] = ("csi", dict(csi_error_var=v), {}, {})
for k, ov in (("L=20", dict(n_sites=20)), ("L=50", dict(n_sites=50)), ("N=32", dict(n_ris=32)),
              ("N=128", dict(n_ris=128)), ("K=20", dict(n_vehicles=20)), ("K=50", dict(n_vehicles=50))):
    SETTINGS[k] = ("size", ov, {}, {})
for phi in (0.5, 1.0, 2.0, 4.0):
    SETTINGS[f"phi={phi:g}"] = ("fairness", {}, dict(phi=phi), {})

SIZE_FREE_ONLY = {"size"}  # published/constrained Hybrid-SAC and DDPG have size-dependent inputs


def _load_aeha(cfg, seed, variant, path):
    agent = aeha.AEHASAC(cfg, aeha.AEHA_VARIANTS[variant])
    agent.actor.load_state_dict(torch.load(path))
    agent.actor.eval()
    agent.cmodel = core.ConformalGainModel(cfg, seed)
    return agent


def _load_rx(cfg, seed, cls, path):
    env = rx.RISNOMAEnv(cfg, seed)
    agent = cls(env, cfg)
    agent.actor.load_state_dict(torch.load(path))
    agent.actor.eval()
    return agent


def policies(cfg, seed, group, knobs):
    bits, phi = knobs.get("phase_bits"), knobs.get("phi", 0.0)
    cm = core.ConformalGainModel(cfg, seed)
    pols = {
        "Decoupled-MRR": aeha.heuristic_policy("decoupled"),
        "Fixed-site": aeha.heuristic_policy("fixed_site"),
        "Weighted target": aeha.agg_target_policy,
        "Physics layer": aeha.agg_floor_policy(0.01, "conformal", cm, phase_bits=bits, phi=phi),
    }
    a = _load_aeha(cfg, seed, "AEHA-res-fixed-delta",
                   FINAL / f"B_seed{seed}" / "models" / f"AEHA-res-fixed-delta_seed{seed}.pt")
    a.phi = phi
    pols["AEHA"] = aeha.aeha_policy(a)
    if bits is not None:
        aq = _load_aeha(cfg, seed, "AEHA-res-fixed-delta",
                        FINAL / f"B_seed{seed}" / "models" / f"AEHA-res-fixed-delta_seed{seed}.pt")
        aq.decode_phase_bits = bits
        pols["AEHA (quant-aware)"] = aeha.aeha_policy(aq)
    rho_path = RHO_AWARE / f"seed{seed}" / "models" / f"AEHA-rho-aware_seed{seed}.pt"
    if group in ("rho", "base") and rho_path.exists():
        pols["AEHA (rho-aware)"] = aeha.aeha_policy(_load_aeha(cfg, seed, "AEHA-rho-aware", rho_path))
    if group not in SIZE_FREE_ONLY:
        pols["Hybrid-SAC"] = aeha.sac_policy(_load_rx(cfg, seed, rx.HybridSAC,
                                                      FINAL / f"P_seed{seed}" / "models" / f"Hybrid-SAC_seed{seed}.pt"))
        pols["DDPG-Hybrid"] = aeha.sac_policy(_load_rx(cfg, seed, rx.HybridDDPG,
                                                       FINAL / f"P_seed{seed}" / "models" / f"DDPG-Hybrid_seed{seed}.pt"))
        pols["Hybrid-SAC (constrained)"] = aeha.sac_policy(_load_rx(
            cfg, seed, rx.HybridSAC, FINAL / f"B_seed{seed}" / "models" / f"Hybrid-SAC-Lagr_seed{seed}.pt"))
    if group == "fairness":  # phi only changes the floor-based methods
        pols = {k: v for k, v in pols.items() if k in ("AEHA", "Physics layer")}
    return pols


def run(seeds, out: Path, only=None):
    out.mkdir(parents=True, exist_ok=True)
    base = rx.Config(**rx.PROFILES["quick"])
    rows = []
    for seed in seeds:
        for name, (group, over, knobs, acct) in SETTINGS.items():
            if only and group not in only:
                continue
            cfg = replace(base, **over)
            t0 = time.time()
            for method, pol in policies(cfg, seed, group, knobs).items():
                m = aeha.evaluate(cfg, seed, pol, **acct)
                m.update(aeha.evaluate_geometries(cfg, seed, pol, **acct))
                rows.append(dict(seed=seed, group=group, setting=name, method=method, **m))
            print(f"seed {seed} {name:12s} {time.time() - t0:6.1f}s", flush=True)
            pd.DataFrame(rows).to_csv(out / "scen_raw.csv", index=False)


def summarize(dirs, out: Path):
    raw = pd.concat([pd.read_csv(HERE / d / "scen_raw.csv") for d in dirs], ignore_index=True)
    out.mkdir(parents=True, exist_ok=True)
    raw.to_csv(out / "scen_raw.csv", index=False)
    keys = ["sum_rate_geo", "qos_geo", "fairness_geo", "sum_rate_mean", "qos_percent", "fairness",
            "inference_ms_median", "inference_ms_p95", "software_loop_ms_median", "software_loop_ms_p95"]
    summ, paired = [], []
    for (setting, method), g in raw.groupby(["setting", "method"], sort=False):
        row = dict(group=g.group.iloc[0], setting=setting, method=method, n=len(g),
                   seeds_qos_geo_ge_99=int((g.qos_geo >= 99.0).sum()))
        for k in keys:
            row[k], row[k + "_ci95"] = aeha.mean_ci(g[k])
        summ.append(row)
    for setting, gs in raw.groupby("setting", sort=False):
        if "AEHA" not in set(gs.method):
            continue
        a = gs[gs.method == "AEHA"].set_index("seed")
        for method in gs.method.unique():
            if method == "AEHA":
                continue
            b = gs[gs.method == method].set_index("seed")
            for k in ("sum_rate_geo", "qos_geo", "fairness_geo"):
                d = (a[k] - b[k]).dropna().values
                if len(d) < 2:
                    continue
                mu, ci = aeha.mean_ci(d)
                p = float(stats.ttest_1samp(d, 0.0).pvalue) if np.any(d != d[0]) else float("nan")
                paired.append(dict(setting=setting, comparator=method, metric=k, aeha_minus=mu, ci95=ci, p=p, n=len(d)))
    pd.DataFrame(summ).to_csv(out / "scen_summary.csv", index=False)
    pd.DataFrame(paired).to_csv(out / "scen_paired_aeha_minus.csv", index=False)
    pd.set_option("display.width", 220)
    print(pd.DataFrame(summ)[["setting", "method", "n", "sum_rate_geo", "qos_geo", "fairness_geo",
                               "seeds_qos_geo_ge_99"]].round(3).to_string(index=False))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", default="11")
    ap.add_argument("--out", default="results_scen_eval/tmp")
    ap.add_argument("--only", default=None, help="comma-separated groups")
    ap.add_argument("--summarize", default=None)
    a = ap.parse_args()
    if a.summarize:
        summarize(a.summarize.split(","), HERE / "results_scen_eval" / "merged")
    else:
        run([int(s) for s in a.seeds.split(",")], HERE / a.out, a.only.split(",") if a.only else None)


if __name__ == "__main__":
    main()
