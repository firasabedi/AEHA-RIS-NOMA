"""Single-process timing of every method (run on an otherwise idle machine).

decision = state/feature construction + action (incl. AEHA's anchor + floor);
loop     = decision + simulator step (SIC/rate evaluation, mobility/channel
           transition, next observation).  For the published learners the
           simulator computes their phase-target features inside the step, so
           their *decision* time excludes that work while *loop* includes it.
Median / p95 over 1400 intervals after 100 warm-up intervals; 1 torch thread.
"""

import sys
import time
from dataclasses import replace
from pathlib import Path

import numpy as np
import pandas as pd
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import aeha  # noqa: E402
import aeha_core as core  # noqa: E402

rx = core.rx
HERE = Path(__file__).resolve().parent
torch.set_num_threads(1)
SEED = 11


def model_path(L, name):
    if L == 3:
        d = "B" if name in ("AEHA-res-fixed-delta", "Hybrid-SAC-Lagr") else "P"
        return HERE / "results_final" / f"{d}_seed{SEED}" / "models" / f"{name}_seed{SEED}.pt"
    d = "B" if name in ("AEHA-res-fixed-delta", "Hybrid-SAC-Lagr") else "P"
    return HERE / "results_scen" / f"L{L}_{d}_seed{SEED}" / "models" / f"{name}_seed{SEED}.pt"


def build(cfg, L, name):
    if name == "AEHA":
        agent = aeha.AEHASAC(cfg, aeha.AEHA_VARIANTS["AEHA-res-fixed-delta"])
        agent.actor.load_state_dict(torch.load(model_path(L, "AEHA-res-fixed-delta")))
        agent.actor.eval()
        agent.cmodel = core.ConformalGainModel(cfg, SEED)
        return "env", aeha.aeha_policy(agent)
    if name == "Physics layer":
        return "env", aeha.agg_floor_policy(0.01, "conformal", core.ConformalGainModel(cfg, SEED))
    if name in ("Decoupled-MRR", "Fixed-site"):
        return "env", aeha.heuristic_policy("decoupled" if name == "Decoupled-MRR" else "fixed_site")
    if name == "Weighted target":
        return "env", aeha.agg_target_policy
    cls = rx.HybridDDPG if name == "DDPG-Hybrid" else rx.HybridSAC
    file = {"Hybrid-SAC": "Hybrid-SAC", "DDPG-Hybrid": "DDPG-Hybrid", "Hybrid-SAC (constrained)": "Hybrid-SAC-Lagr"}[name]
    env = rx.RISNOMAEnv(cfg, SEED)
    agent = cls(env, cfg)
    agent.actor.load_state_dict(torch.load(model_path(L, file)))
    agent.actor.eval()
    return "state", agent


METHODS = ["Decoupled-MRR", "Fixed-site", "Weighted target", "Physics layer", "Hybrid-SAC", "DDPG-Hybrid",
           "Hybrid-SAC (constrained)", "AEHA"]
rows = []
for L in (3, 20, 50):
    cfg = replace(rx.Config(**rx.PROFILES["quick"]), n_sites=L)
    for name in METHODS:
        kind, pol = build(cfg, L, name)
        env = rx.RISNOMAEnv(cfg, SEED + 100_000)
        env.reset()
        dec, loop = [], []
        for i in range(1500):
            t0 = time.perf_counter_ns()
            if kind == "env":
                site, action = pol(env)
            else:
                site, action, _ = pol.act(env._state(), deterministic=True)
            t1 = time.perf_counter_ns()
            _, _, done, _ = env.step(site, action)
            if done:
                env.reset()
            t2 = time.perf_counter_ns()
            if i >= 100:
                dec.append((t1 - t0) / 1e6)
                loop.append((t2 - t0) / 1e6)
        rows.append(dict(L=L, method=name, decision_median=np.median(dec), decision_p95=np.quantile(dec, 0.95),
                         loop_median=np.median(loop), loop_p95=np.quantile(loop, 0.95)))
        print(f"L={L:2d} {name:26s} decision {np.median(dec):.3f}/{np.quantile(dec, .95):.3f}  "
              f"loop {np.median(loop):.3f}/{np.quantile(loop, .95):.3f} ms", flush=True)
pd.DataFrame(rows).to_csv(HERE / "results_timing_all.csv", index=False)
