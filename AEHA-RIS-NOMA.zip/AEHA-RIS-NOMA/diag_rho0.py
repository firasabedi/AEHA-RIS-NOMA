"""Why does the QoS-floor power layer lose to MRR under perfect SIC (rho = 0)?

Anchor fixed to MRR (site + phases); only the power rule changes.  Same
evaluation streams as ``aeha.evaluate`` (env seed = seed + 100000).
"""

import sys
from dataclasses import replace
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import aeha_core as core  # noqa: E402
from headroom import nomarates, metrics, simplex_grid  # noqa: E402

rho = float(sys.argv[1]) if len(sys.argv) > 1 else 0.0
cfg = replace(core.rx.Config(**core.rx.PROFILES["quick"]), residual_sic=rho)
P = simplex_grid(cfg.n_users, 20, positive=True) * cfg.p_max
names = ["MRR heuristic power", "equal power", "nominal floor (est)", "genie floor (true)",
         "conformal d=0.01", "conformal d=0.10", "grid max est-sum s.t. est floors", "genie grid (true)"]
acc = {n: [] for n in names}
detail = {n: [] for n in names}
for seed in (11, 22, 33):
    cm = core.ConformalGainModel(cfg, seed)
    env = core.rx.RISNOMAEnv(cfg, seed + 100_000)
    env.reset()
    for _ in range(cfg.eval_steps):
        ch = env._channels
        site, act = env.heuristic_action("decoupled")
        theta = np.pi * (act[: cfg.n_ris].astype(np.float64) + 1.0)
        d_est, d_true = ch["direct_est"].astype(np.complex128), ch["direct_true"].astype(np.complex128)
        ge = core.anchored_gains(d_est, ch["casc_est"][site].astype(np.complex128), theta)
        gt = core.anchored_gains(d_true, ch["cascaded"][site].astype(np.complex128), theta)
        lg = act[cfg.n_ris:].astype(np.float64)
        p_mrr = np.exp(lg - lg.max())
        p_mrr /= p_mrr.sum()

        def true_metrics(p):
            return metrics(nomarates(gt, ge, p, cfg), cfg)

        rew_e = metrics(nomarates(ge[None], ge[None], P, cfg), cfg)
        feas_e = rew_e["qos"] >= 1.0
        sc_e = np.where(feas_e, rew_e["sum_rate"], -1e9 + rew_e["sum_rate"])
        rew_t = metrics(nomarates(gt[None], ge[None], P, cfg), cfg)
        sc_t = np.where(rew_t["qos"] >= 1.0, rew_t["sum_rate"], -1e9 + rew_t["sum_rate"])
        ps = {
            "MRR heuristic power": p_mrr,
            "equal power": np.full(cfg.n_users, cfg.p_max / cfg.n_users),
            "nominal floor (est)": core.qos_floor_power(ge, cfg, 0.0),
            "genie floor (true)": core.qos_floor_power(gt, cfg, 0.0, order=np.argsort(ge)) if
            core.qos_floor_power(gt, cfg, 0.0, order=np.argsort(ge), allow_relax=False) is not None else core.qos_floor_power(ge, cfg, 0.0),
            "conformal d=0.01": core.conformal_floor_power(ge, cfg, 0.01, cm),
            "conformal d=0.10": core.conformal_floor_power(ge, cfg, 0.10, cm),
            "grid max est-sum s.t. est floors": P[np.argmax(sc_e)],
            "genie grid (true)": P[np.argmax(sc_t)],
        }
        for n, p in ps.items():
            m = true_metrics(p)
            acc[n].append((float(m["sum_rate"]), float(m["qos"])))
            r = nomarates(gt, ge, p, cfg)  # weak -> strong (estimated order)
            detail[n].append(np.concatenate([np.sort(p)[::-1][:1], p[np.argsort(ge)], r]))
        _, _, done, _ = env.step(site, act)
        if done:
            env.reset()
print(f"rho = {rho}   (MRR anchor fixed; 3 seeds x {cfg.eval_steps} steps)")
print(f"{'power rule':36s} {'sum':>7s} {'QoS%':>7s}   mean p (weak,mid,strong)   mean rate (weak,mid,strong)")
for n in names:
    a = np.array(acc[n])
    d = np.array(detail[n])
    print(f"{n:36s} {a[:, 0].mean():7.2f} {100 * a[:, 1].mean():7.2f}   "
          f"{np.round(d[:, 1:4].mean(0), 3)}   {np.round(d[:, 4:7].mean(0), 2)}")
